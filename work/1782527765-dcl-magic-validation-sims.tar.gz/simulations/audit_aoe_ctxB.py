#!/usr/bin/env python3
"""
AUDIT: does the SKIPPED AoE axis erase MR-3's CTX-B (and overshoot the single-target G_m* anchor)?

The supremacy sim derives G_m* by calibrating the mage's SINGLE-TARGET battle total to the fighter's,
and finds CTX-B (fighter out-sustains vs a SOFT target past T>=12) as one of the 2 required common
losing contexts. It explicitly SKIPS AoE, calling it "generous to magic / conservative."

But Fira & Firaga ARE AoE (tempo sim SPELLS: aoe=True), and FFT enemies commonly cluster. This script
re-runs CTX-B against a CLUSTER of k soft targets: the mage's charged bursts hit all k; the fighter
hits 1. We measure (a) the attrition crossover T vs cluster size, and (b) how far the mage's real
(AoE) battle-total exceeds the single-target anchor it was calibrated to.

Reuses sim_confront_supremacy machinery (G_m* and the burst economy) unchanged.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_confront_supremacy as S

GM = S.GM_STAR
STAGES = S.STAGES; FSK = S.FIGHTER_SKILL

def mage_group_battle(ma, gm, T, k_cluster, pool=80, trick=2, bolt_sp=0.8):
    """Burst economy, but charged AoE spells (Fira/Firaga) deal their damage to k targets.
    Returns total damage dealt to the GROUP (sum across all targets hit)."""
    mp = pool; charging=None; t=0; total=0.0
    while t < T:
        mp += trick
        if charging is not None:
            # charged spells here are the AoE tier -> hit k targets
            total += S.spell_onhit(ma, S.SP[charging], gm) * k_cluster
            charging=None; t+=1; continue
        if mp >= S.COST["Firaga"] and t < T-1:
            mp -= S.COST["Firaga"]; charging="Firaga"   # AoE
        elif mp >= S.COST["Fira"] and t < T-1:
            mp -= S.COST["Fira"]; charging="Fira"        # AoE
        else:
            total += S.bolt_onhit(ma, gm, bolt_sp)       # bolt is single-target
        t += 1
    return total

if __name__ == "__main__":
    ma = pa = STAGES["mid"]; sk = FSK["mid"]
    f_leu = S.fighter_turn(pa, sk, "leather", "right")    # fighter dmg/turn vs one soft target
    print("="*92)
    print(f"AoE vs CTX-B — group damage to a CLUSTER of k soft (leather) targets.  G_m*={GM:.2f}")
    print("CTX-B (report): fighter cumulative OVERTAKES mage on a soft target at T>=12 (single-target).")
    print("Here the mage's AoE bursts hit all k; the fighter still hits one at a time.")
    print("="*92)
    print(f"{'k':>3} | " + " ".join(f"T{t:<2}".rjust(7) for t in (8,10,12,16,20)) + " | crossover T (fighter overtakes)")
    print("-"*92)
    for k in (1,2,3,4):
        cells=[]; crossover=None
        for T in (8,10,12,16,20):
            mg = mage_group_battle(ma, GM, T, k)
            fg = f_leu * T          # fighter clears the group one target at a time -> same dmg/turn total
            r = mg/fg
            cells.append(f"{r:6.2f}")
        # find crossover
        for T in range(2, 60):
            mg = mage_group_battle(ma, GM, T, k); fg = f_leu*T
            if mg < fg: crossover = T; break
        cs = str(crossover) if crossover else "NEVER (mage always ahead)"
        print(f"{k:>3} | " + " ".join(c.rjust(7) for c in cells) + f" | {cs}")
    print("-"*92)
    print("READ: ratio = mage group-damage / fighter group-damage. >1 = mage ahead. The single-target")
    print("column (k=1) reproduces the report's CTX-B (crossover ~T12). At k>=2 the crossover vanishes")
    print("(or pushes far past battle length) -> CTX-B is NOT a losing context vs clustered enemies.")

    # How far does the mage's REAL (AoE) output exceed the single-target anchor it was calibrated to?
    print("\n" + "="*92)
    print("CALIBRATION OVERSHOOT — G_m* was set so SINGLE-TARGET mage total == fighter total vs leather.")
    print("With AoE on a cluster, the mage's REAL group output exceeds that anchor by:")
    print("="*92)
    anchor = S.mage_burst_battle(ma, GM, T=10)[0]   # single-target mage total == fighter total (by calib)
    print(f"  single-target mage total (== fighter anchor) = {anchor:.0f}")
    for k in (1,2,3):
        g = mage_group_battle(ma, GM, 10, k)
        print(f"  cluster k={k}: group output = {g:.0f}   ({g/anchor:.2f}x the anchor)")
    print("\n  => calibrating G_m* on SINGLE-TARGET while the mage's signature spells are AoE means the")
    print("     'balanced' anchor under-counts real output by the cluster factor on every clustered fight.")

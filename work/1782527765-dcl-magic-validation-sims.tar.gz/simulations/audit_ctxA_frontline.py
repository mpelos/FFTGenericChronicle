#!/usr/bin/env python3
"""
AUDIT: CTX-A robustness — the supremacy sim models a LONE robe mage in a 1v1 vs a rushing thief.
"Bring mages" in a real party means the mage sits BEHIND a frontline. Two independent problems:
  (1) AI-executability (MR-7): the repo's own docs/modding/05-reverse-engineering.md:158 says the
      targeting AI is "out of scope" / unmapped -> the premise "AI rushes the softest" is unverified.
  (2) Even granting a perfect rusher, a FRONTLINE delays it by D turns while the mage keeps casting.
This script re-runs the duel with the thief delayed D extra move-turns (going around / through a
blocker) and finds the D at which the mage survives -> i.e. how little protection flips CTX-A.
Reuses the supremacy spine; thief_duel re-implemented with a frontline-delay knob.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_confront_supremacy as S
from sim_core import injury, p_land, CONFIG

GM = S.GM_STAR
STAGES = S.STAGES; GEN_W = S.GEN_W; TARGETS = S.TARGETS; MP_TRICK = S.MP_TRICK

def duel(start_dist, gm, bolt_sp=0.8, frontline_delay=0, stage="mid",
         mage_hp=110, thief_hp=130, thief_speed=10, mage_speed=7, thief_skill=13):
    pa = ma = STAGES[stage]
    def thief_hit(backstab):
        strike = injury(pa, GEN_W, "cut", "robe", CONFIG)
        pl = p_land(thief_skill, TARGETS["robe"]["dodge"], "back" if backstab else "front")
        return 2*strike*pl
    ct_t=ct_m=0; mp=80; charging=None; dist=start_dist; mhp=mage_hp; thp=thief_hp
    delay_left = frontline_delay     # extra thief move-turns burned before it can reach the mage
    for tick in range(1,300):
        ct_t += thief_speed; ct_m += mage_speed
        if ct_m>=100 and mhp>0:
            ct_m-=100; mp+=MP_TRICK
            if charging is not None:
                thp -= S.spell_onhit(ma, S.SP[charging], gm); charging=None
            elif mp>=S.COST["Firaga"]:
                mp-=S.COST["Firaga"]; charging="Firaga"
            else:
                thp -= S.bolt_onhit(ma, gm, bolt_sp)
            if thp<=0: return "MAGE", tick
        if ct_t>=100 and thp>0:
            ct_t-=100
            if dist>1:
                dist=max(1,dist-4)
            elif delay_left>0:
                delay_left-=1          # blocked by frontline this turn (attacks blocker / repaths)
            else:
                mhp -= thief_hit(backstab=True)
            if mhp<=0: return "THIEF", tick
    return "TIMEOUT", 300

if __name__ == "__main__":
    print("="*84)
    print(f"CTX-A ROBUSTNESS — thief rush vs a mage with a FRONTLINE (delay D turns). G_m*={GM:.2f}")
    print("D=0 reproduces the report's LONE-mage duel. D>0 = the mage is screened by 1+ allies.")
    print("="*84)
    print(f"  {'D (frontline-delay turns)':28} | start_dist=3 | start_dist=5")
    print("  " + "-"*64)
    flip = None
    for D in (0,1,2,3,4):
        w3,t3 = duel(3, GM, frontline_delay=D)
        w5,t5 = duel(5, GM, frontline_delay=D)
        if flip is None and w3=="MAGE" and w5=="MAGE": flip = D
        print(f"  {D:<28} | {w3:>5} (t{t3:<3}) | {w5:>5} (t{t5:<3})")
    print("  " + "-"*64)
    print(f"  -> the mage survives the rush from BOTH distances once the frontline buys D>={flip} turns.")
    print("     CTX-A is a LONE-mage result; modest screening (the normal 'bring mages' party) flips it")
    print("     to the mage even granting a perfect rusher. Combined with the unverified AI-targeting")
    print("     premise (MR-7), CTX-A is not a robust COMMON AI-executable losing context.")

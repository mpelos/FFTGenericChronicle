#!/usr/bin/env python3
"""
AUDIT: joint-lock safe-region test (convergence auditor).

The report claims the magic system HOLDS iff a set of calibration locks hold JOINTLY:
  G_m re-derived to the anchor  AND  charge>=1  AND  bolt_sp in 0.6-0.8  AND
  magic-evade<=50%  AND  soft-cap on whole product  AND  MP-window < battle length.

This script tests whether the JOINT region is non-empty and WIDE (not a knife-edge),
by re-deriving G_m* per (bolt_sp, pool) config (the design's own calibration discipline)
and checking ALL the continuous-coupled verdict conditions at once, plus the G_m drift margin.

Reuses sim_confront_supremacy machinery (imported; its __main__ does not run on import).
thief_duel is re-implemented faithfully (it lives inside the source's __main__).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_core as core
from sim_core import injury, p_land, CONFIG
import sim_confront_supremacy as S

STAGES = S.STAGES
FSK = S.FIGHTER_SKILL
TARGETS = S.TARGETS
GEN_W = S.GEN_W
MP_TRICK = S.MP_TRICK

def fighter_turn(pa, sk, tgt, loadout="right"):
    return S.fighter_turn(pa, sk, tgt, loadout)

def calibrate_gm(bolt_sp, pool, trick=MP_TRICK, stage="mid", T=10):
    """Re-derive G_m* so mage battle-total == fighter total vs leather (anchor 11.49)."""
    ma = pa = STAGES[stage]; sk = FSK[stage]
    ftot = fighter_turn(pa, sk, "leather", "right") * T
    mage1, _, _ = S.mage_burst_battle(ma, gm=1.0, T=T, pool=pool, trick=trick, bolt_sp=bolt_sp)
    return ftot / mage1, ftot

# --- thief_duel re-implemented from sim_confront_supremacy (__main__-local) ---
def thief_duel(start_dist, gm, bolt_sp, stage="mid", mage_hp=110, thief_hp=130,
               thief_speed=10, mage_speed=7, thief_skill=13):
    pa = ma = STAGES[stage]
    def thief_hit_dmg(backstab):
        strike = injury(pa, GEN_W, "cut", "robe", CONFIG)
        pl = p_land(thief_skill, TARGETS["robe"]["dodge"], "back" if backstab else "front")
        return 2*strike*pl
    ct_t = ct_m = 0; mp = 80; charging=None; dist=start_dist; mhp=mage_hp; thp=thief_hp
    for tick in range(1, 200):
        ct_t += thief_speed; ct_m += mage_speed
        if ct_m >= 100 and mhp > 0:
            ct_m -= 100; mp += MP_TRICK
            if charging is not None:
                thp -= S.spell_onhit(ma, S.SP[charging], gm); charging=None
            elif mp >= S.COST["Firaga"]:
                mp -= S.COST["Firaga"]; charging="Firaga"
            else:
                thp -= S.bolt_onhit(ma, gm, bolt_sp)
            if thp <= 0: return "MAGE", tick
        if ct_t >= 100 and thp > 0:
            ct_t -= 100
            if dist > 1:
                dist = max(1, dist - 4)
            else:
                mhp -= thief_hit_dmg(backstab=True)
            if mhp <= 0: return "THIEF", tick
    return "TIMEOUT", 200

def first_soft_break_gm(bolt_sp, ma_slope=1.0, stage="mid"):
    """Smallest G_m at which bolt/turn >= fighter/turn on a SOFT (leather) target (the MR-1 break)."""
    pa = ma = STAGES[stage]; sk = FSK[stage]
    f_leu = fighter_turn(pa, sk, "leather", "right")
    gm = 0.05
    while gm < 8.0:
        b = S.bolt_onhit(ma, gm, bolt_sp, ma_slope=ma_slope)
        if b >= f_leu: return gm
        gm += 0.01
    return None

def check_config(bolt_sp, pool, charge_ok, ma_slope=1.0):
    gm, ftot = calibrate_gm(bolt_sp, pool)
    pa = ma = STAGES["mid"]; sk = FSK["mid"]
    # MR-1: strictly-better == bolt >= fighter on EVERY soft target/stage. NOT-strictly-better == it loses somewhere.
    strictly_better = True
    for st in STAGES:
        p2 = m2 = STAGES[st]; s2 = FSK[st]
        b = S.bolt_onhit(m2, gm, bolt_sp, ma_slope=ma_slope)
        for tg in ("leather","thief","robe"):
            if b < fighter_turn(p2, s2, tg, "right"):
                strictly_better = False   # found a soft losing context for the bolt
    mr1_ok = (not strictly_better)        # MR-1 HOLDS iff the bolt is NOT strictly-better
    # depleted-mage heroic floor: bolt vs soft fighter >= ~30% AND vs plate >= ~100% (the tempo "real action" test)
    b_mid = S.bolt_onhit(ma, gm, bolt_sp, ma_slope=ma_slope)
    f_leu = fighter_turn(pa, sk, "leather", "right"); f_pl = fighter_turn(pa, sk, "plate", "right")
    floor_soft = b_mid / f_leu; floor_plate = b_mid / f_pl
    heroic_ok = (floor_soft >= 0.30)   # not dead weight vs soft
    # MP still matters: full mage output / bolt-only output > ~1.2 (MP buys >20% over the floor)
    mtot,_,_ = S.mage_burst_battle(ma, gm, T=10, pool=pool, bolt_sp=bolt_sp)
    bolt_only = b_mid * 10
    mp_gain = mtot / bolt_only
    mp_ok = (mp_gain >= 1.15)
    # MR-3 CTX-A: thief rush kills lone mage from dist 3 or 5
    wA5,_ = thief_duel(5, gm, bolt_sp); wA3,_ = thief_duel(3, gm, bolt_sp)
    ctxA = (wA5 == "THIEF" or wA3 == "THIEF")
    # MR-3 CTX-B: fighter out-sustains vs leather by T=16
    m16,_,_ = S.mage_burst_battle(ma, gm, T=16, pool=pool, bolt_sp=bolt_sp)
    f16 = fighter_turn(pa, sk, "leather", "right")*16
    ctxB = (m16 < f16)
    # G_m drift margin: how far above gm before the MR-1 soft-break
    gm_break = first_soft_break_gm(bolt_sp, ma_slope)
    margin = (gm_break/gm - 1.0) if gm_break else None
    allpass = mr1_ok and heroic_ok and mp_ok and ctxA and ctxB and charge_ok
    return dict(gm=gm, mr1=mr1_ok, heroic=heroic_ok, floor_soft=floor_soft, floor_plate=floor_plate,
                mp_ok=mp_ok, mp_gain=mp_gain, ctxA=ctxA, ctxB=ctxB, gm_break=gm_break,
                margin=margin, allpass=allpass)

if __name__ == "__main__":
    print("="*108)
    print("JOINT-LOCK SAFE-REGION SWEEP  (re-derive G_m* per config; check all continuous-coupled locks at once)")
    print("="*108)
    print(f"{'bolt_sp':>7} {'pool':>5} {'chg>=1':>6} | {'G_m*':>5} {'MR1ok':>5} {'heroic':>6} "
          f"{'flr_soft':>8} {'flr_plate':>9} {'MPgain':>6} {'MPok':>5} {'ctxA':>5} {'ctxB':>5} "
          f"{'gm_brk':>6} {'margin':>7} | {'JOINT':>5}")
    print("-"*108)
    rows = []
    for bolt_sp in (0.5, 0.6, 0.7, 0.8, 0.9, 1.0):
        for pool in (40, 80, 120, 200):
            for charge in (1,):    # charge>=1 lock satisfied; charge=0 tested separately
                r = check_config(bolt_sp, pool, charge_ok=(charge>=1))
                rows.append((bolt_sp, pool, charge, r))
                mg = f"{r['margin']*100:5.0f}%" if r['margin'] is not None else "  n/a"
                gb = f"{r['gm_break']:.2f}" if r['gm_break'] else " n/a"
                print(f"{bolt_sp:7.2f} {pool:5} {str(charge>=1):>6} | {r['gm']:5.2f} {str(r['mr1']):>5} "
                      f"{str(r['heroic']):>6} {r['floor_soft']:8.0%} {r['floor_plate']:9.0%} "
                      f"{r['mp_gain']:6.2f} {str(r['mp_ok']):>5} {str(r['ctxA']):>5} {str(r['ctxB']):>5} "
                      f"{gb:>6} {mg:>7} | {str(r['allpass']):>5}")
    n_pass = sum(1 for *_, r in rows if r['allpass'])
    print("-"*108)
    print(f"JOINT-PASS configs: {n_pass} / {len(rows)}")
    # Where does it fail and why?
    print("\nFAILURE BREAKDOWN (which lock fails):")
    for bolt_sp, pool, charge, r in rows:
        if not r['allpass']:
            why = []
            if not r['mr1']: why.append("bolt-strictly-better")
            if not r['heroic']: why.append(f"dead-weight(soft {r['floor_soft']:.0%})")
            if not r['mp_ok']: why.append(f"MP-irrelevant(gain {r['mp_gain']:.2f})")
            if not r['ctxA']: why.append("no-thief-rush-loss")
            if not r['ctxB']: why.append("no-attrition-loss")
            print(f"   bolt_sp={bolt_sp} pool={pool}: {', '.join(why)}")
    # G_m margin summary at the recommended window
    print("\nG_m DRIFT MARGIN at the recommended window (bolt_sp 0.6-0.8):")
    for bolt_sp in (0.6, 0.7, 0.8):
        r = check_config(bolt_sp, 80, True)
        print(f"   bolt_sp={bolt_sp}: G_m*={r['gm']:.2f}, soft-break at G_m={r['gm_break']:.2f} "
              f"-> can drift +{r['margin']*100:.0f}% before caster-supremacy (one-sided up)")

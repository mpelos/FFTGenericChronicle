#!/usr/bin/env python3
"""
Round-3 confirmation audit: verify the specific claims Phase H MAKES (not the corners it admits open).
Reuses sim_confront_aoe machinery unchanged.

Tests, each tied to a Phase-H sentence:
  T1  realized-2-cluster-parity G_m drift (Phase H: 'early 0.41 -> mid 0.55 -> late 0.64')
  T2  early crossover at FLAT G_m=0.553, pool=80 (Phase H: 'early k=2 -> T45, k=3 -> NEVER')
  T3  pool=40 early remediation (Phase H: 'pool~40 -> early k=2 crossover T45->T15') + no-new-break checks
  T4  stage-scaled-G_m alt lever: does early G_m=0.41 KILL the early bolt floor? (the 'equivalently' claim)
  T5  mid/late bounded (Phase H: 'mid k=2 T10/k=3 T18, late k=2 T8/k=3 T13')
  T6  k>=4 bounded (Phase H 'What HELD': 'k>=4 T15-25, no runaway')  <-- a claim the base sim never tested
  T7  off-neutral inflation (Phase H: 'neutral 1.18/1.57 inflates to 1.30/1.73')
"""
import sim_confront_aoe as A
from sim_confront_aoe import (mage_group, bolt_floor_ratio, attrition_crossover,
                              calibrate_realized, vs_fighter, mage_ever_leads, cluster_multiple)

GM_SINGLE = A.GM            # 0.652 single-target anchor
def hr(c="="): print(c*92)

FIX = dict(pt_mp=0.5)      # the load-bearing lever
GM_FIX = calibrate_realized(2, stage="mid", **FIX)   # 0.553 mid realized-2-cluster anchor

print(f"GM_single_anchor={GM_SINGLE:.3f}  GM_FIX(mid realized-2cluster)={GM_FIX:.4f}")
hr()

# ---- T1: realized-parity G_m drifts with stage ----
print("T1  realized-2-cluster-parity G_m per stage (Phase H: early 0.41 / mid 0.55 / late 0.64)")
print(f"    {'stage':6} | {'parity G_m':>10} | {'bolt floor@that G_m':>19}")
parity = {}
for stg in ("early", "mid", "late"):
    g = calibrate_realized(2, stage=stg, **FIX); parity[stg] = g
    bf = bolt_floor_ratio(g, stage=stg)
    print(f"    {stg:6} | {g:10.3f} | {bf:19.2f}  {'DEAD-WEIGHT' if bf < 0.50 else 'ok'}")
hr("-")

# ---- T2: early crossover at FLAT shipped G_m=0.553, pool=80 ----
print("T2  early-vs-leather attrition crossover at FLAT G_m=0.553, pool=80 (Phase H: k2->T45, k3->NEVER)")
for k in (2, 3):
    x = attrition_crossover(0.553, k, stage="early", **FIX)
    print(f"    k={k}: crossover T = {x if x else 'NEVER'}   (T10 {vs_fighter(0.553,k,stage='early',T=10,**FIX):.2f}, "
          f"T12 {vs_fighter(0.553,k,stage='early',T=12,**FIX):.2f}, T20 {vs_fighter(0.553,k,stage='early',T=20,**FIX):.2f})")
hr("-")

# ---- T3: pool=40 early remediation + does it introduce a NEW break? ----
print("T3  pool=40 early remediation (Phase H: 'pool~40 -> early k=2 crossover T15')")
for k in (2, 3):
    x40 = attrition_crossover(0.553, k, stage="early", pool=40, **FIX)
    x80 = attrition_crossover(0.553, k, stage="early", pool=80, **FIX)
    leads40 = mage_ever_leads(0.553, k, stage="early", pool=40, **FIX)
    print(f"    k={k}: pool80 xover {x80 if x80 else 'NEVER':>5} -> pool40 xover {str(x40) if x40 else 'NEVER':>5}"
          f"   | early fresh mage still front-loads (has upside)? {leads40}")
print(f"    bolt floor is pool-independent -> stays {bolt_floor_ratio(0.553, stage='early'):.2f} at G_m=0.553 early (heroic, no new break)")
# does shrinking early pool wreck mid/late? (it shouldn't -- pool is stage-scaled, mid keeps 80)
print(f"    mid keeps pool=80 -> mid k2 xover {attrition_crossover(0.553,2,stage='mid',pool=80,**FIX)} (unchanged)")
hr("-")

# ---- T4: the OTHER offered lever -- stage-scaled G_m to 0.41 early. Does it kill the early bolt floor? ----
print("T4  ALT lever 'stage-scale G_m to ~0.41 early' (Phase H calls it EQUIVALENT to pool-scaling)")
g_e = parity["early"]
bf_e = bolt_floor_ratio(g_e, stage="early")
print(f"    early G_m={g_e:.3f} -> early bolt floor {bf_e:.2f}  {'<<< DEAD-WEIGHT (<0.50): NOT equivalent to pool-scaling' if bf_e<0.50 else 'ok (>=0.50)'}")
for k in (2, 3):
    x = attrition_crossover(g_e, k, stage="early", **FIX)
    print(f"    early@G_m={g_e:.3f} k={k}: crossover T = {x if x else 'NEVER'}  (T10 {vs_fighter(g_e,k,stage='early',T=10,**FIX):.2f})")
hr("-")

# ---- T5: mid/late bounded (the central case Phase H AFFIRMS) ----
print("T5  mid/late neutral-cluster crossover at G_m=0.553, pool=80 (Phase H: mid k2 T10/k3 T18, late k2 T8/k3 T13)")
for stg in ("mid", "late"):
    row = []
    for k in (2, 3):
        x = attrition_crossover(0.553, k, stage=stg, **FIX)
        row.append(f"k{k}={x if x else 'NEVER'}")
    print(f"    {stg:5}: " + "  ".join(row))
hr("-")

# ---- T6: k>=4 bounded? (Phase H 'What HELD' claims 'k>=4 T15-25, no runaway') -- base sim never tested this ----
print("T6  HIGHER k bounded? Phase H 'What HELD' asserts 'k>=4 T15-25, no runaway'. mid, G_m=0.553, pool=80.")
print(f"    {'k':>3} | {'xover T':>8} | {'T10':>5} {'T15':>5} {'T20':>5} {'T25':>5} | {'mp/burst mult':>13}")
runaway = []
for k in (2, 3, 4, 5, 6, 8):
    x = attrition_crossover(0.553, k, stage="mid", **FIX)
    cells = [vs_fighter(0.553, k, stage="mid", T=t, **FIX) for t in (10, 15, 20, 25)]
    mpmult = 1 + 0.5*(k-1)
    flag = ""
    if (x is None or x > 30):
        runaway.append(k); flag = "  <-- crossover NOT inside a real battle"
    print(f"    {k:>3} | {str(x) if x else 'NEVER':>8} | " + " ".join(f"{c:5.2f}" for c in cells) + f" | {mpmult:13.2f}{flag}")
print(f"    higher-k with crossover>30/NEVER: {runaway if runaway else 'none -> bounded (per-target MP cost keeps biting)'}")
hr("-")

# ---- T7: off-neutral (uniform +30% element weakness multiplies ALL the mage's magic) ----
print("T7  off-neutral shared-weakness cluster = +30% on bolt+burst == G_m*1.3 (Phase H: 1.30/1.73)")
print(f"    {'k':>3} | {'neutral T10':>11} | {'off-neutral T10 (x1.3)':>22} | {'off-neutral xover T':>19}")
for k in (2, 3):
    neu = vs_fighter(0.553, k, stage="mid", T=10, **FIX)
    off = vs_fighter(0.553*1.3, k, stage="mid", T=10, **FIX)
    xoff = attrition_crossover(0.553*1.3, k, stage="mid", **FIX)
    print(f"    {k:>3} | {neu:11.2f} | {off:22.2f} | {str(xoff) if xoff else 'NEVER':>19}")
print("    (off-neutral erases the attrition crossover -> Phase H accepts this as a 'winning matchup', lever=mixed-affinity/band-tighten)")
hr()
print("DONE — ground truth above.")

#!/usr/bin/env python3
"""
audit_sample.py — Convergence Auditor's seeded re-run + diff (integrity check).

Derives a RECORDED seed deterministically from git HEAD, samples ~3 sims and ~6
load-bearing decisions, RE-RUNS each sampled sim from scratch, and DIFFs a key
extracted number against the value asserted in that sim's _READ.md / report.md.
A stored read that does not match live output = fabricated/stale verdict = blocking.

Run:  python3 audit_sample.py
"""
import random, re, subprocess, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))

# --- recorded seed: deterministic from HEAD ---------------------------------
HEAD = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=HERE).decode().strip()
SEED = int(HEAD, 16) % 1000
print(f"git HEAD = {HEAD}")
print(f"RECORDED SEED = {SEED}  (= int(HEAD,16) % 1000)")
random.seed(SEED)

# --- pools ------------------------------------------------------------------
# Each sim probe: (script, regex over stdout, expected value asserted by its READ/report)
SIM_POOL = {
    "sim_core": [
        (r"open \(skill12 vs Dodge8\) front:\s*(\d+)%", "55", "open-front land% (D04 regime, report §D)"),
        (r"crush/cut ratio = ([\d.]+)x", "1.76", "sharpness crush/cut vs plate (D03-14)"),
    ],
    "sim_speed": [
        (r"Speed 12:\s*(\d+) turns", "72", "turns@Spd12 (B1 row A)"),
        (r"Fast  \(Spd12, Brave mid\)\s+(\d+)\s+(\d+)\s+(\d+)%", "72/14/20", "isolated Fast-neutral turns/Dodge/exposure (B1 row E)"),
    ],
    "sim_brave": [
        (r"best-by-archetype: \{'frontline fighter': 'high', 'protected archer': 'high', 'pure mage': 'low'\}", "MATCH", "mental-OFF: phys->HIGH, mage->LOW (B9)"),
    ],
    "sim_armor_triangle": [
        (r"lowest worst-case damage: (\w+)", "robe", "avoidance mildly best (B10)"),
        (r"vs cut-bruiser\s+: best=(\w+)", "plate", "plate best vs cut (B10)"),
    ],
    "sim_weight": [
        (r"distinct Move values across normal kits: \[([\d, ]+)\]", "1, 2, 3, 4", "graded Move span (D14-62 HOLDS)"),
    ],
    "sim_multihit": [
        (r"skill 16, K=2: P\(>=1 bypass\)/turn = (\d+)%", "18", "crit-bypass/turn skill16 K2 (B6)"),
    ],
    "sim_weapon_matchup_indep": [
        (r"thrust\s+#1=\s*(\d+)\s+win=\s*\d+\s+lose=\s*(\d+)", "9/0", "thrust 9 strict#1 / 0 lose (B2)"),
        (r"cut\s+#1=\s*(\d+)\s+win=\s*(\d+)\s+lose", "0/0", "cut 0 #1 / 0 win (B11)"),
    ],
}

# Load-bearing decisions w/ the verdict-log claim (register Phase D) + my independent expectation.
DECISION_POOL = {
    "D01-5 Speed triple-duty": "REVISE/B1",
    "D02-4 damage pipeline": "HOLDS",
    "D02-8 pen_floor": "HOLDS-chip/REVISE-late",
    "D03-14 sharpness MEDIUM": "HOLDS",
    "D04-1 two-roll hit/defense": "HOLDS",
    "D04-6 crit bypasses defense": "REVISE/B6",
    "D04-14 auto-best+depletion": "REVISE/B1",
    "D05-4 back = no defense": "HOLDS",
    "D05-6 counterplay triangle": "UNVERIFIED-AI",
    "D05-10 no route universal": "HOLDS",
    "D07-4 Brave aggression-dial": "REVISE/B9",
    "D07-14 Brave physical-only": "HOLDS",
    "D08-7 phys->Brave/magic->Faith": "CONTRADICTION-A2",
    "D13-2 3d6 status contest": "HOLDS-mechanism",
    "D13-12 status categories": "CONTRADICTION-A1",
    "D14-2 weapon contextual balance": "BROKEN/B2",
    "D14-61/62 Weight model": "HOLDS",
    "D14-72 mitigation-vs-avoidance": "REVISE/B10",
    "D14-79 armor triangle cyclic": "REVISE/B10",
    "D14-82 Block-only-vs-ranged": "UNVERIFIED",
    "D14-85 shield-lets-tank-advance": "UNVERIFIED",
}

# --- sample -----------------------------------------------------------------
sampled_sims = sorted(random.sample(list(SIM_POOL), 3))
sampled_decisions = sorted(random.sample(list(DECISION_POOL), 6))

print("\nSAMPLED SIMS:", sampled_sims)
print("SAMPLED DECISIONS:")
for d in sampled_decisions:
    print(f"   - {d}  [register verdict: {DECISION_POOL[d]}]")

# --- re-run sampled sims and diff -------------------------------------------
print("\n" + "=" * 72)
print("SIM RE-RUN + DIFF (live stdout vs READ/report assertion)")
print("=" * 72)
all_ok = True
for s in sampled_sims:
    out = subprocess.run([sys.executable, f"{s}.py"], cwd=HERE,
                         capture_output=True, text=True).stdout
    for rgx, expected, label in SIM_POOL[s]:
        m = re.search(rgx, out)
        if not m:
            print(f"  [{s}] {label}: PATTERN NOT FOUND -> MISMATCH")
            all_ok = False
            continue
        if expected == "MATCH":
            got = "MATCH"
        elif "/" in expected:
            got = "/".join(m.groups())
        else:
            got = m.group(1)
        ok = (got == expected)
        all_ok = all_ok and ok
        print(f"  [{s}] {label}\n        live={got!r}  claimed={expected!r}  -> {'OK' if ok else 'MISMATCH'}")

print("\n" + "=" * 72)
print(f"INTEGRITY RESULT: {'ALL SAMPLED SIM NUMBERS MATCH THEIR READS' if all_ok else 'MISMATCH FOUND'}")
print("=" * 72)
print("Decision verdicts are re-derived by the auditor in prose (require judgment,")
print("not just extraction); the sample above fixes WHICH decisions were re-derived.")

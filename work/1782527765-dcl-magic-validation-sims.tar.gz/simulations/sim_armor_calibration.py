#!/usr/bin/env python3
"""
sim_armor_calibration.py — nail the armor-class numbers so NONE is strictly dominated and EACH is
the right pick in some context (B10 resolution, doc 14). Post-B1: Dodge = C-Ev + equip − WeightPen
(NO Speed term).

The B10 finding ("Mail & Leather have no tank niche") used a TANK-ONLY lens ("best vs attacker X").
That's the wrong test: armor is largely job-gated, and the two middle classes were never meant to be
tanks. The right test is the design pillar P1′:
  (1) NON-DOMINATION — no class is >= every other class on every axis a unit cares about
      {DR-vs-cut, DR-vs-thrust, DR-vs-crush, Move, Dodge}; and
  (2) EVERY-CLASS-HAS-A-CONTEXT — for some (mobility-preference w, attacker), each class is the best
      pick. A unit that doesn't value mobility (w≈0, the anvil) vs one that lives on it (high w, the
      skirmisher), against different attackers, should NOT all reach for the same armor.

We also re-check the old "robe is universally most-robust" symptom now that Speed is out of Dodge.

Built to FALSIFY a number set, then sweep for a robust region.
"""
import itertools

# ---- 3d6 ----
_CUM = {3:1,4:4,5:10,6:20,7:35,8:56,9:81,10:108,11:135,12:160,13:181,14:196,15:206,16:212,17:215,18:216}
def p_le(n):
    n = int(round(n))
    if n < 3: return 0.0
    if n >= 18: return 1.0
    return _CUM[n] / 216.0

# ---- fixed pipeline constants (isolate the ARMOR; absolute magnitudes ride global G/DR-scaling) ----
R          = 12.0   # raw pre-DR damage input (base+wmod), held constant
PEN_FLOOR  = 0.20   # min fraction of raw that always lands (doc 02)
ATK_SKILL  = 13     # attacker skill, constant
C_EV       = 10.0   # wearer Class-Evade, held constant to ISOLATE armor (job-coupled in reality)
GUN_PEN    = 0.65   # gun/penetration ignores 65% of DR (doc 03 divisor 'alto') — the anti-armor attacker
WOUND      = {"cut":1.5, "thrust":2.0, "crush":1.0, "gun":1.0}
ATK_DRTYPE = {"cut":"cut", "thrust":"thrust", "crush":"crush", "gun":"thrust"}  # gun rides thrust-DR, then divided

def injury(armor, atk):
    dr = armor["DR"][ATK_DRTYPE[atk]]
    if atk == "gun":
        dr *= (1.0 - GUN_PEN)
    through = max(PEN_FLOOR * R, R - dr)
    return through * WOUND[atk]

def dodge(armor, k_dodge):
    return C_EV - k_dodge * armor["Weight"]     # lighter = dodgier; NO Speed (post-B1)

def p_land(armor, atk, k_dodge):
    return p_le(ATK_SKILL) * (1.0 - p_le(dodge(armor, k_dodge)))

def eff_dmg(armor, atk, k_dodge):               # per-turn effective damage; LOWER = better survival
    return injury(armor, atk) * p_land(armor, atk, k_dodge)

def move_pen(weight, b1, b2, b3):               # coarse, stepped (doc 14): protects Move
    if weight <= b1: return 0
    if weight <= b2: return -1
    if weight <= b3: return -2
    return -3

# ---- the test ----
def dominated(cls, others, axes):
    """cls is strictly dominated if some other is >= on every axis and > on at least one."""
    for o in others:
        if all(o[a] >= cls[a] - 1e-9 for a in axes) and any(o[a] > cls[a] + 1e-9 for a in axes):
            return True
    return False

def evaluate(ARMOR, k_dodge, bks, move_value, w_grid):
    b1,b2,b3 = bks
    # axis vector per class (higher = better on that axis): survival is -eff_dmg; mobility is move_pen
    axisvec = {}
    for name,a in ARMOR.items():
        axisvec[name] = {
            "def_cut":    -eff_dmg(a,"cut",k_dodge),
            "def_thrust": -eff_dmg(a,"thrust",k_dodge),
            "def_crush":  -eff_dmg(a,"crush",k_dodge),
            "def_gun":    -eff_dmg(a,"gun",k_dodge),
            "Move":        move_pen(a["Weight"],b1,b2,b3),
            "Dodge":       dodge(a,k_dodge),
        }
    pareto_axes = ["def_cut","def_thrust","def_crush","Move","Dodge"]
    dom = [n for n in ARMOR if dominated(axisvec[n], [axisvec[o] for o in ARMOR if o!=n], pareto_axes)]

    # every-class-has-a-context: argmax over (mobility weight w, attacker)
    winners = set(); argmap = {}
    for w in w_grid:
        for atk in ("cut","thrust","crush","gun"):
            best, bestname = -1e9, None
            for name,a in ARMOR.items():
                # utility = survival  +  w * mobility(move_pen<=0)*move_value
                u = -eff_dmg(a,atk,k_dodge) + w * move_pen(a["Weight"],b1,b2,b3) * move_value
                if u > best: best, bestname = u, name
            winners.add(bestname); argmap[(w,atk)] = bestname
    return axisvec, dom, winners, argmap

def poles_ok(axisvec):
    # plate = mitigation pole: uniquely best vs cut & thrust (honest blades)
    plate_cut = max(axisvec, key=lambda n: axisvec[n]["def_cut"]) == "Plate"
    plate_thr = max(axisvec, key=lambda n: axisvec[n]["def_thrust"]) == "Plate"
    # robe = avoidance pole: best vs gun (penetration) AND best Dodge/Move
    robe_gun  = max(axisvec, key=lambda n: axisvec[n]["def_gun"]) == "Robe"
    robe_dod  = max(axisvec, key=lambda n: axisvec[n]["Dodge"]) == "Robe"
    # robe NOT universally most-robust (post-B1): plate must beat robe vs cut
    robe_not_universal = axisvec["Plate"]["def_cut"] > axisvec["Robe"]["def_cut"]
    return plate_cut and plate_thr and robe_gun and robe_dod and robe_not_universal

if __name__ == "__main__":
    print("ARMOR CALIBRATION — find numbers where NO class is dominated and EACH wins a context (P1′)\n")

    # candidate number set (relative units). DR by type; Plate has the documented crush hole.
    BASE_ARMOR = {
        "Plate":   {"Weight":26, "DR":{"cut":9,"thrust":8,"crush":3}, "HP":6},  # mitigation pole; crush/gun holes
        "Mail":    {"Weight":16, "DR":{"cut":5,"thrust":5,"crush":5}, "HP":3},  # FLAT generalist — no type hole
        "Leather": {"Weight":8,  "DR":{"cut":2,"thrust":2,"crush":2}, "HP":1},  # light, a little DR
        "Robe":    {"Weight":3,  "DR":{"cut":0,"thrust":0,"crush":0}, "HP":0},  # avoidance pole
    }
    W_GRID = [0.0, 1.0, 2.0, 3.0, 4.0]      # mobility preference: anvil(0) → skirmisher(4)

    # ---- sweep the calibration knobs for a robust passing region ----
    passing = []
    for k_dodge in (0.22, 0.28, 0.34):
        for b2 in (18, 20, 22, 24):                  # the Mail|Plate move divider
            for mv in (1.5, 2.5):                    # how a unit prices 1 Move tier in damage-units
                bks = (12, b2, 30)
                axisvec, dom, winners, argmap = evaluate(BASE_ARMOR, k_dodge, bks, mv, W_GRID)
                ok = (len(dom)==0 and len(winners)==4 and poles_ok(axisvec))
                if ok: passing.append((k_dodge,b2,mv))
    print(f"robust region: {len(passing)} / "
          f"{3*4*2} swept (k_dodge,b2,move_value) combos satisfy [0 dominated & all 4 win a context & poles hold]")
    if passing:
        kd = sorted({p[0] for p in passing}); b2s = sorted({p[1] for p in passing}); mvs = sorted({p[2] for p in passing})
        print(f"   passing k_dodge∈{kd}  b2∈{b2s}  move_value∈{mvs}")

    # ---- detailed read on the recommended config (DEFAULT: plate stays −1, no knight nerf) ----
    # NB: the sweep shows plate −2/mail −1 AND plate −1/mail −1 both pass (0 dominated, all 4 win).
    # Separating the Move tiers is an OPTIONAL lever, not required — Mail is held non-dominated at the
    # SAME −1 tier by the Dodge gradient + its flat DR covering plate's crush hole. Default keeps −1.
    K, BKS, MV = 0.28, (14, 28, 40), 2.5
    print(f"\n{'='*82}\nRECOMMENDED (default — plate stays −1): k_dodge={K}  "
          f"move-bands=(≤14→0, 15–28→−1, 29–40→−2)  move_value={MV}\n{'='*82}")
    axisvec, dom, winners, argmap = evaluate(BASE_ARMOR, K, BKS, MV, W_GRID)
    print("  per-class axes (def_* = survival vs that attacker, higher=better; Move≤0; Dodge):")
    print(f"  {'class':8} {'W':>3} {'Move':>4} {'Dodge':>6} | {'vs cut':>7} {'vs thr':>7} {'vs crush':>8} {'vs gun':>7}")
    for n,a in BASE_ARMOR.items():
        v = axisvec[n]
        print(f"  {n:8} {a['Weight']:>3} {v['Move']:>4} {v['Dodge']:>6.1f} | "
              f"{-v['def_cut']:>7.2f} {-v['def_thrust']:>7.2f} {-v['def_crush']:>8.2f} {-v['def_gun']:>7.2f}"
              f"   (eff dmg/turn, LOWER=tankier)")
    print(f"\n  strictly-dominated classes: {dom if dom else 'NONE  ✓ (every class is on the Pareto frontier)'}")
    print(f"  classes that win ≥1 context: {sorted(winners)}  ({len(winners)}/4)")
    print(f"  poles hold (plate=mitigation, robe=avoidance, robe NOT universally best): {poles_ok(axisvec)}")

    print("\n  WHO is the best pick, by (mobility preference w × attacker) — every cell is a real context:")
    corner = "w\\atk"
    print(f"    {corner:>6} | {'cut':>8} {'thrust':>8} {'crush':>8} {'gun':>8}")
    print("    " + "-"*46)
    for w in W_GRID:
        row = [f"{argmap[(w,atk)]:>8}" for atk in ("cut","thrust","crush","gun")]
        tag = "anvil" if w==0 else ("skirmisher" if w==max(W_GRID) else "")
        print(f"    {w:>6} | " + " ".join(row) + (f"   <- {tag}" if tag else ""))

    print("\n  READ: plate owns the anvil rows (low w) vs honest blades; robe/leather own the high-w &")
    print("  gun cells (mobility + dodge the penetration); mail is the flat pick that shows up vs crush")
    print("  (plate's hole) and as the dodgier heavy at the same −1 Move tier. None dominated.")

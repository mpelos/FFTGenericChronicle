# sim_armor_calibration — read (B10 resolution)

**Question.** Set armor-class numbers so the system satisfies the real pillar **P1′** instead of the
wrong "best-tank-vs-X" lens that produced B10. Two tests, post-B1 (Dodge = C-Ev + equip − WeightPen,
**no Speed term**):

1. **Non-domination** — no class is ≥ every other on every axis a unit weighs {DR-vs-cut, -thrust,
   -crush, Move, Dodge}. (This is the actual "no strictly-better option" pillar.)
2. **Every class has a context** — across (mobility-preference `w` from anvil→skirmisher) × (attacker
   type), each class is the best pick somewhere. (No armor is pointless.)

The B10 finding ("Mail & Leather have no tank niche") was a **category error**: armor is largely
**job-gated** (a mage wears robe because it's a mage, not by free choice), and Leather/Robe were never
tanks. So "not the best tank" ≠ a P1′ violation. The honest tests are the two above.

## Recommended numbers (relative/provisional — absolute magnitudes ride global G/DR-scaling)

| class | Weight | DR cut / thr / crush | Move tier | Dodge | identity |
|-------|-------:|:--------------------:|:---------:|------:|----------|
| **Plate**   | 26 | 9 / 8 / **3** | **−1** *(−2 loaded)* | 2.7 | mitigation pole — anti-blade; **holes vs crush & gun** |
| **Mail**    | 16 | 5 / 5 / **5** | **−1** | 5.5 | **flat, no type hole**; dodgier & crush-safe vs plate, same Move tier |
| **Leather** |  8 | 2 / 2 / 2     | **0**  | 7.8 | mobility chassis — defense is positional, not DR |
| **Robe**    |  3 | 0 / 0 / 0     | **0**  | 9.2 | avoidance pole — dodges, DR-piercing/magic flow off it |

- Move bands: `≤14 → 0 · 15–28 → −1 · 29–40 → −2` (coarse, doc 14) — mail & "normal" plate both at
  −1; loaded plate → −2. k_dodge=0.28, C-Ev=10 (held constant to isolate the armor; in play C-Ev is
  job-coupled).

## Result

- **strictly-dominated classes: NONE** — all four sit on the Pareto frontier. ✓
- **all 4 win a context** (4/4). ✓
- **poles hold**, and **robe is NOT universally most-robust** (plate beats robe vs cut). ✓
- **robust:** 16/24 swept (k_dodge, move-divider b2, move_value) combos pass all three; the pick is
  inside the plateau, not a knife-edge.

Best-pick map (who you'd actually equip), `eff dmg/turn` lower = tankier:

```
   w\atk |   cut  thrust  crush   gun
    0.0  | Plate   Plate   Mail   Robe   <- anvil (ignores mobility)
    1.0  | Plate   Plate Leather  Robe
    2.0  |Leather Leather Leather  Robe
    4.0  |Leather Leather Leather  Robe   <- skirmisher
```

## The structural rules this proves (the durable design facts)

1. **Lighter must always grant more Dodge** (monotonic Weight→Dodge). This fine-grained gradient is
   what keeps *adjacent* classes non-dominated even when they shoulder the same Move tier — a lighter
   class is never "the same but worse," it trades DR for Dodge.
2. **Plate's crush/gun holes are load-bearing** — they're what hand Mail its clear niche (the
   anti-crush tank) and what the robe avoidance-pole exploits via penetration. Flat-DR Mail is *never
   the best blind pick* (plate's raw mitigation wins the mixed average) — Mail's niche is specifically
   *crush / plate's-hole* and *job-gated mid-weight*: narrow but legible and non-dominated. That
   narrowness is acceptable precisely because armor is rarely a free choice.

Together, rules 1 + 2 keep **Mail non-dominated and context-winning even sharing Plate's −1 Move
tier** — so B10's "smoking gun" (mail and normal plate both at −1) is *not* a real break. The sim
confirms both `plate −2 / mail −1` and `plate −1 / mail −1` pass (0 dominated, all 4 win a context):
separating the Move tiers is an **optional lever** (a sharper "lighter literally moves more" identity),
**not a requirement**. The recommended default keeps **plate at −1** to avoid nerfing knight mobility
and to stay faithful to the approved Weight model; plate reaches −2 only when fully loaded with
shield + helm.

## Post-B1 confirmation

With Speed removed from Dodge, **plate has the best worst-case (7.7)**, not robe (12.6). The old
sim_armor_triangle "robe mildly most-robust overall" symptom was a Speed→Dodge artifact (R1/B1) and is
**gone** once B1 is applied. The avoidance↔mitigation asymmetry (Dodge multiplicative vs DR
subtractive) survives but no longer makes the dodge-pole universally best.

## What would flip this

A class set where some job can equip two classes and the lighter one is strictly dominated (e.g. if
Weight→Dodge were made flat, or if Mail were dropped into Plate's Move tier). The sweep shows the
passing region is wide, so ordinary calibration drift won't break it — collapsing a structural rule
(rule 1 or 2) would.

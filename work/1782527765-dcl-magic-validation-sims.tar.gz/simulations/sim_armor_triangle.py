#!/usr/bin/env python3
"""
sim_armor_triangle.py — is the armor 'triangle' actually cyclic? (D14-72/79/85)
Claim: Plate > Leather > Caster/Robe > Plate (rock-paper-scissors), no class strictly best.
Built to FALSIFY: if one class takes least effective damage across ALL attacker archetypes,
it is strictly best and the triangle is a fiction. We measure EFFECTIVE damage-taken per turn =
injury-per-hit * P(land), lower = tankier, for each armor vs each attacker archetype.

Mechanisms: subtractive type-DR (plate high cut/thrust, low crush; robe thin), Weight->Dodge
(plate heavy=low Dodge, robe light=high Dodge), magic ignores physical DR (only a magic-dodge),
caster/robe has the best magic-dodge. Numbers are placeholders, swept.
"""
from sim_core import injury, p_land, CONFIG, p_le

# Dodge floor is Speed-driven (C-Ev + Speed) and Weight only REDUCES it (D04-11, D14-62).
# So we HOLD the wearer's Speed CONSTANT (same unit swaps armor) and derive physical Dodge =
# C_EV + SPEED - weight_dodge_pen. This isolates the ARMOR's own contribution (DR + weight + mdodge)
# instead of falsely handing light armor a high Dodge. magic-dodge is a separate non-depleting stat.
C_EV, SPEED = 2, 8
WEIGHT_PEN = {"plate":6, "mail":4, "leather":2, "robe":1}   # from sim_weight kit pens
ARMOR = {
    "plate":   {"dodge": C_EV+SPEED-WEIGHT_PEN["plate"],   "mdodge": 3},   # 4: gets hit, mitigates
    "mail":    {"dodge": C_EV+SPEED-WEIGHT_PEN["mail"],     "mdodge": 4},   # 6
    "leather": {"dodge": C_EV+SPEED-WEIGHT_PEN["leather"],  "mdodge": 5},   # 8
    "robe":    {"dodge": C_EV+SPEED-WEIGHT_PEN["robe"],     "mdodge": 10},  # 9 phys, evades MAGIC
}
# attacker archetypes: (label, type, wmod-tier, skill, is_magic, magic_power)
ATTACKERS = [
    ("cut-bruiser",   "cut",     "alto", 12, False, 0),
    ("thrust-lancer", "thrust",  "alto", 12, False, 0),
    ("crush-breaker", "crush",   "alto", 13, False, 0),   # anti-plate
    ("gunner(div2)",  "missile", "medio",13, False, 0),   # ranged anti-armor
    ("mage",          None,      None,   13, True, 22),    # ignores DR; vs magic-dodge
]
PA = 10

def eff_damage(attacker, armor):
    label, dtype, tier, skill, is_magic, mpow = attacker
    a = ARMOR[armor]
    if is_magic:
        # magic ignores physical DR; deterministic; only magic-dodge negates (non-depleting)
        per_hit = mpow
        pl = p_land(skill, a["mdodge"])
        return per_hit * pl
    w = CONFIG["wmod"][tier]
    if dtype == "crush":
        w = w * CONFIG["crush_wmod_mult"]
    div = "gun" if label.startswith("gun") else "none"
    per_hit = injury(PA, w, dtype, armor, CONFIG, divisor=div)
    pl = p_land(skill, a["dodge"])
    return per_hit * pl

print("="*78)
print("EFFECTIVE DAMAGE TAKEN per turn (injury*P(land)); LOWER = tankier vs that attacker")
print("="*78)
header = f"  {'armor':9}" + "".join(f"{a[0]:>15}" for a in ATTACKERS) + f"{'WORST':>9}"
print(header)
worst_by_armor = {}
table = {}
for armor in ARMOR:
    row = []
    for atk in ATTACKERS:
        d = eff_damage(atk, armor)
        row.append(d)
    table[armor] = row
    worst = max(row)
    worst_by_armor[armor] = worst
    print(f"  {armor:9}" + "".join(f"{d:15.1f}" for d in row) + f"{worst:9.1f}")

print("\n  -- who is tankiest (min effective dmg) vs each attacker? --")
for j,atk in enumerate(ATTACKERS):
    best = min(ARMOR, key=lambda ar: table[ar][j])
    worst = max(ARMOR, key=lambda ar: table[ar][j])
    print(f"  vs {atk[0]:14}: best={best:8}  worst={worst}")

print("\n  -- cyclicity check: does any armor have the LOWEST worst-case (strictly best tank)? --")
champ = min(worst_by_armor, key=worst_by_armor.get)
print(f"  lowest worst-case damage: {champ} ({worst_by_armor[champ]:.1f}).")
print("  For a real triangle, each class should be best vs some attacker AND worst vs another,")
print("  and no class should have a dominating (lowest) worst-case. Read the rows above.")

print("\n"+"="*78)
print("SENSITIVITY SWEEP — vary plate crush-DR and mage power; does the picture flip?")
print("="*78)
from itertools import product
base = dict(CONFIG)
for crushdr, mpow in product((2,3,5),(16,22,28)):
    cfg = {**base, "DR":{**base["DR"], "plate":{**base["DR"]["plate"], "crush":crushdr}}}
    # recompute plate's worst case under this cfg
    def ed(atk, armor, cfg):
        label, dtype, tier, skill, is_magic, mp = atk
        a = ARMOR[armor]
        if is_magic:
            return mpow * p_land(skill, a["mdodge"])
        w = cfg["wmod"][tier]
        if dtype=="crush": w*=cfg["crush_wmod_mult"]
        div = "gun" if label.startswith("gun") else "none"
        return injury(PA,w,dtype,armor,cfg,divisor=div)*p_land(skill,a["dodge"])
    plate_worst = max(ed(a,"plate",cfg) for a in ATTACKERS)
    robe_worst  = max(ed(a,"robe", cfg) for a in ATTACKERS)
    leath_worst = max(ed(a,"leather",cfg) for a in ATTACKERS)
    champ = min([("plate",plate_worst),("leather",leath_worst),("robe",robe_worst)], key=lambda x:x[1])
    print(f"  plate_crushDR={crushdr} mage={mpow}: worstcase plate={plate_worst:.0f} "
          f"leather={leath_worst:.0f} robe={robe_worst:.0f} -> tankiest={champ[0]}")

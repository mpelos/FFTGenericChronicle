# sim_armor_triangle.py — read (2026-06-26)

Tests D14-79 "armor triangle" (claim: Plate > Leather > Caster/Robe > Plate, cyclic, no class strictly
best as a tank). Metric: effective damage taken/turn = injury × P(land), lower = tankier.

## Modeling fix (caught mid-run)
v1 hard-coded robe Dodge=12 (light⇒evasive), which made robe falsely best vs *everything*. But the Dodge
floor is **Speed-driven** (C-Ev + Speed) and Weight only *reduces* it — light armor doesn't grant Dodge.
v2 holds the wearer's Speed constant and derives Dodge = C-Ev + Speed − WeightPen, isolating the armor.

## Findings (corrected)
| armor | best vs | worst vs | tank niche? |
|-------|---------|----------|-------------|
| **plate** | cut, thrust (mitigation) | crush, **mage** | yes — anti-blade |
| **robe** | crush, gunner, **mage** (avoidance+magic-dodge) | thrust | yes — anti-armor/anti-magic |
| **mail** | — (nothing) | thrust, gunner | **NONE as a tank** |
| **leather** | — (nothing) | cut | **NONE as a tank** |

- **Not a cyclic triangle.** It's a **2-pole axis**: plate (mitigation, beats honest blades) vs robe
  (avoidance + magic-dodge, beats armor-piercing & magic). Mail and Leather are **never the best tank vs
  any attacker** — they have no *tanking* niche (their justification must be mobility/offense/cost, which
  this defense-only lens doesn't capture). This extends ED-4 ("Mail no niche") to Leather too.
- **Robe has the lowest worst-case** (15.0) in **8/9 sweep cells** — mildly the most robust overall,
  because its worst enemy (thrust) is capped while plate's worst enemy (mage) scales with spell power.
  Avoidance is mildly favored over mitigation because Dodge suppresses P(land) *multiplicatively* while DR
  only *subtracts* — **another downstream symptom of R1 (Speed→Dodge is strong)**.
- **Lever exists:** plate becomes tankiest-overall only when magic is weak AND plate's crush-DR is high
  (sweep: plate_crushDR=5, mage=16). So the plate↔robe balance is tunable via magic threat + crush-DR.

## Verdict
**D14-79 PARTIALLY FALSIFIED.** The "cyclic triangle" framing overstates the structure: it's a 2-pole
mitigation↔avoidance axis with two tweener classes (Mail, Leather) that lack a tanking niche, and a mild
avoidance bias (robe most-robust). Not a teardown — tunable — but the design should (a) reframe the
"triangle" honestly as plate↔robe, (b) give Mail/Leather an explicit non-tank justification (Move/Dodge
mobility, cost, offense enablement), and (c) note robe's overall-robustness is yet another reason to tax
Speed→Dodge (R1). **What would flip this:** a real cyclic counter (e.g. something light loses to that
plate beats) wired in, or mobility/offense folded into the metric showing Mail/Leather pull their weight.

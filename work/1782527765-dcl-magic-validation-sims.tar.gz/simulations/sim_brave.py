#!/usr/bin/env python3
"""
sim_brave.py — is any Brave band best for ALL builds? (P4 two-sided traits; D07-4/6/16/17/18/20; B9)
Built to FALSIFY P4: if HIGH Brave is the best pick for more than one distinct archetype with no
offsetting loss, the trait is one-sided at that extreme. Brave is two-sided by design:
  HIGH: +physical offense (x1.56), +mental-status resist, +courage reactions, BUT -2 active defense.
  LOW : +2..3 active defense, BUT -physical offense (x0.76), -mental resist, panic reactions.
Litmus (D07-14): Brave is PHYSICAL-only — magic offense ignores it, so a mage's offense is Brave-flat.
The decisive variable is EXPOSURE: the -2 defense only costs a unit that actually gets hit; a protected
backline archer pays ~nothing for high Brave while gaining +offense.

Whether HIGH Brave grants mental-status resist (D07-7) is CONTESTED — it is exactly the mechanic in
contradiction A1 (stun: Brave-composure vs base-HP-physical). So the sim runs BOTH ways and reports both
verdicts, so the conclusion never rests on a single contested term.
"""
from sim_core import p_le

BRAVE = {
    "low":  {"off":0.76, "def_shift":+3, "p_mentalCC":0.25},
    "mid":  {"off":1.00, "def_shift": 0, "p_mentalCC":0.15},
    "high": {"off":1.56, "def_shift":-2, "p_mentalCC":0.06},
}
ARCH = {
    "frontline fighter": {"exposure":0.55, "is_physical":True,  "base_dpr":10, "dodge_base":8},
    "protected archer":  {"exposure":0.12, "is_physical":True,  "base_dpr":9,  "dodge_base":9},
    "pure mage":         {"exposure":0.30, "is_physical":False, "base_dpr":11, "dodge_base":8},
}
INCOMING_HIT = 9
CC_COST = 8

def score(arch, brave, mental_link):
    a = ARCH[arch]; b = BRAVE[brave]
    off = a["base_dpr"] * (b["off"] if a["is_physical"] else 1.0)
    base_pland = 1 - p_le(a["dodge_base"])
    shifted_pland = 1 - p_le(a["dodge_base"] + b["def_shift"])
    extra_dmg = a["exposure"] * (shifted_pland - base_pland) * INCOMING_HIT
    cc = (b["p_mentalCC"] if mental_link else BRAVE["mid"]["p_mentalCC"]) * CC_COST
    return off - extra_dmg - cc, off, extra_dmg, cc

def report(mental_link):
    best_by_arch = {}
    for arch in ARCH:
        kind = "physical" if ARCH[arch]["is_physical"] else "MAGIC"
        print(f"\n  {arch} (exposure {ARCH[arch]['exposure']}, {kind} offense):")
        scores = {}
        for brave in ("low","mid","high"):
            s, off, dmg, cc = score(arch, brave, mental_link)
            scores[brave] = s
            print(f"    {brave:4}: score={s:6.2f}  (offense={off:5.2f}  −def_cost={dmg:5.2f}  −mentalCC={cc:4.2f})")
        best = max(scores, key=scores.get)
        best_by_arch[arch] = best
        print(f"    -> best Brave for {arch}: {best.upper()}")
    print(f"\n  best-by-archetype: {best_by_arch}")
    bands = set(best_by_arch.values())
    if len(bands) == 1:
        print(f"  -> ONE band ({list(bands)[0].upper()}) best for EVERY archetype. P4 VIOLATED (universal-best Brave).")
    else:
        print(f"  -> archetypes split across bands {bands}. P4 base case HOLDS.")
    phys_best = {a:b for a,b in best_by_arch.items() if ARCH[a]["is_physical"]}
    if set(phys_best.values()) == {"high"}:
        print(f"  NOTE: both physical archetypes (incl. the PROTECTED archer) want HIGH: {phys_best}")
        print("  -> the -2 downside is nearly free for low-exposure physical builds. P4 FRAGILE at the")
        print("     protected extreme (B9): high Brave is a near-universal pick for any physical unit kept")
        print("     off the front line. The mage litmus only preserves Brave-choice for pure casters.")
    return best_by_arch

print("="*82)
print("BRAVE band value per archetype (higher=better). off − defense_cost − mentalCC_cost")
print("="*82)
for mode in (True, False):
    tag = "ON  (D07-7 as written: high Brave resists mental)" if mode else "OFF (mental-resist neutral, pending A1)"
    print("\n" + "#"*82)
    print(f"#### MODE: Brave→mental-resist {tag}")
    print("#"*82)
    report(mode)

print("\n"+"="*82)
print("SENSITIVITY — vary the protected archer's exposure; when does HIGH stop being free?")
print("(mental-resist OFF, so only the defense tradeoff is in play — the conservative case)")
print("="*82)
for exp in (0.05,0.12,0.20,0.30,0.45,0.60,0.80):
    ARCH["protected archer"]["exposure"]=exp
    sh,_,_,_ = score("protected archer","high",False)
    sm,_,_,_ = score("protected archer","mid",False)
    sl,_,_,_ = score("protected archer","low",False)
    best = max((("low",sl),("mid",sm),("high",sh)), key=lambda x:x[1])[0]
    print(f"  archer exposure={exp:.2f}: low={sl:.2f} mid={sm:.2f} high={sh:.2f} -> best={best.upper()}")
print("  -> the exposure at which HIGH stops winning = how 'protected' is too protected.")

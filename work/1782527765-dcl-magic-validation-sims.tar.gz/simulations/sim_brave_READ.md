# sim_brave.py — read (2026-06-26)

Tests P4 (no Brave band best for all builds; D07-4/6/16/17/18/20; B9). Two-sided by design: HIGH = +phys
offense (×1.56), +mental-resist, +courage, −2 active defense; LOW = +defense, −offense, −mental-resist.
Litmus (D07-14): Brave is physical-only, so a mage's offense is Brave-flat. Run BOTH ways on the contested
"high Brave resists mental" link (D07-7 — the same mechanic as contradiction A1).

## Findings (ground truth)
- **Mental-resist ON (D07-7 as written):** HIGH Brave is best for **all three** archetypes (fighter,
  protected archer, AND pure mage) → **P4 VIOLATED — a universal-best band.** The +1.52 mental-resist swing
  even drags the Brave-flat mage to HIGH.
- **Mental-resist OFF (conservative, pending A1):** fighter→HIGH, archer→HIGH, mage→LOW → P4 *base case*
  holds (bands split), **but both physical archetypes want HIGH.**
- **Sensitivity (mental OFF) is the damning part:** the protected archer prefers HIGH across the **entire**
  exposure sweep 0.05→0.80 — even a *heavily* exposed physical unit wants HIGH. Reason: the offense gain
  (+56% of base ≈ +5.6) is **~7× the defense cost** (exposure×Δp_land×hit ≈ 0.2–0.9). The −2 to-hit penalty
  is far too small to offset the offense multiplier.

## Verdict
**B9 CONFIRMED and stronger than v1.** Brave is **not meaningfully two-sided for physical builds** under
the current numbers: HIGH dominates for anything physical regardless of exposure. Only the **mage litmus**
(D07-14) preserves a real Brave choice (pure casters want LOW). The contested D07-7 link, if resolved
"high Brave resists mental," tips it to a **flat P4 violation** — so the A1 ruling has direct balance
stakes (it is not cosmetic). This is sensitivity-robust, not a knife-edge.
**Fix (design):** steepen the high-Brave downside (a much larger defense penalty, or a genuine second
drawback), or shrink the offense multiplier, so the two sides match in magnitude. Tie the A1 resolution to
this: don't let high Brave own offense + mental-resist + courage against one weak downside.
**What would flip it:** a high-Brave offense multiplier near ~1.15–1.2 (not 1.56) with the current −2, or a
−4/−5 defense penalty, would let exposure actually decide the band.

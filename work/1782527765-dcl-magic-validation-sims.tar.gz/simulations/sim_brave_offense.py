#!/usr/bin/env python3
"""
sim_brave_offense.py — TUNE the Brave offense-swing magnitude M (B9 part 3, post-fix).

Context: B9's *structural* break (high Brave is universally-best for any low-exposure physical build)
is now fixed two ways already locked in the docs:
  - A1 resolved: stun/knockdown are PHYSICAL (base-HP), so Brave's mental upside is ONLY the
    will-override statuses (fear/charm/confuse/berserk). Modeled as WILL_CC.
  - Taunt INVERTED: high Brave is *vulnerable* to taunt/provoke -> it can be pulled out of cover.
    Modeled as a provoke exposure bump PB added to a high-Brave unit's expected incoming attacks.
What's left is the NUMBER: how big should the high-Brave offense multiplier M be?

This sim is built to FALSIFY "we can keep M=1.56". Currency = net HP swing per round
(damage dealt - damage taken - control lost), all in the same damage units, so offense and the
defense downside are finally comparable (the old sim compared full-DPR offense to fractional
defense cost, which structurally guaranteed offense would dominate).

Reads to watch:
  1. best Brave per archetype  -> mage must want LOW (litmus); builds must SPLIT (P4).
  2. archer risk/reward of going mid->high -> if ~0, high is FREE for the backliner (B9 not closed).
  3. frontline must still find HIGH worthwhile (the glass-cannon fantasy survives).
NOTE: net-HP currency UNDER-rewards offense (it ignores kill-tempo: a dead enemy stops hitting back),
so it is CONSERVATIVE toward high Brave. If high still pays off here, it pays off more in play.
"""
from sim_core import p_le

# ------- knobs under test (the thing we are tuning) -------
DOWN = 0.43        # off_low = 1-(M-1)*DOWN ; 0.43 reproduces today's 0.76 floor at M=1.56
PB   = 0.35        # provoke exposure bump on HIGH Brave (taunt-inversion fix), extra attacks/round
INCOMING = 9.0     # avg damage of one incoming hit (~ base_dpr scale)
CC_COST  = 8.0     # value lost to one will-override control status
DEF_SHIFT = {"low": +3, "mid": 0, "high": -2}                 # locked active-defense downside
WILL_CC   = {"low": 0.22, "mid": 0.13, "high": 0.06}          # P/round of eating a will-override status

# exposure = expected enemy landing-attempts vs this unit per round (before the Brave def shift)
ARCH = {
    "frontline DPS":    {"exposure": 0.90, "physical": True,  "dpr": 13, "dodge": 8},
    "protected archer": {"exposure": 0.25, "physical": True,  "dpr": 9,  "dodge": 9},
    "evasive duelist":  {"exposure": 0.55, "physical": True,  "dpr": 10, "dodge": 11},
    "front tank":       {"exposure": 1.30, "physical": True,  "dpr": 6,  "dodge": 9},
    "pure mage":        {"exposure": 0.50, "physical": False, "dpr": 11, "dodge": 8},
}

def off_mult(M, brave):
    return {"low": 1 - (M - 1) * DOWN, "mid": 1.0, "high": M}[brave]

def exposure_eff(arch, brave):
    e = ARCH[arch]["exposure"]
    if brave == "high":
        e += PB                    # provokable: taunt drags a high-Brave unit into more attacks
    return e

def dmg_taken(arch, brave):
    a = ARCH[arch]
    land = 1 - p_le(a["dodge"] + DEF_SHIFT[brave])      # P(an incoming attack lands) at this Brave
    return exposure_eff(arch, brave) * land * INCOMING

def value(arch, brave, M):
    a = ARCH[arch]
    off = a["dpr"] * (off_mult(M, brave) if a["physical"] else 1.0)
    taken = dmg_taken(arch, brave)
    cc = WILL_CC[brave] * CC_COST
    return off - taken - cc, off, taken, cc

def best_brave(arch, M):
    return max(("low", "mid", "high"), key=lambda b: value(arch, b, M)[0])

def report(M):
    print(f"\n{'='*84}\nM (high-Brave offense mult) = {M:.2f}   "
          f"[low={off_mult(M,'low'):.2f}  mid=1.00  high={M:.2f}]   PB(provoke)={PB}\n{'='*84}")
    best = {}
    for arch in ARCH:
        kind = "phys" if ARCH[arch]["physical"] else "MAGIC"
        print(f"\n  {arch}  (exposure {ARCH[arch]['exposure']}, dpr {ARCH[arch]['dpr']}, "
              f"dodge {ARCH[arch]['dodge']}, {kind})")
        vals = {}
        for b in ("low", "mid", "high"):
            v, off, tk, cc = value(arch, b, M)
            vals[b] = v
            print(f"    {b:4}: net={v:6.2f}   (dealt={off:5.2f}  taken={tk:5.2f}  ctrl={cc:4.2f})")
        bb = max(vals, key=vals.get)
        best[arch] = bb
        # risk/reward of the AGGRESSIVE pick mid->high (is high "free"?)
        rew = value(arch, "high", M)[1] - value(arch, "mid", M)[1]     # extra dmg dealt
        risk = dmg_taken(arch, "high") - dmg_taken(arch, "mid")        # extra dmg taken
        rr = risk / rew if rew > 0.01 else float('nan')
        tag = ""
        if ARCH[arch]["physical"]:
            tag = "  <-- high is ~FREE (B9!)" if rr < 0.35 else ("  (high is a real bet)" if bb=="high" else "")
        print(f"    -> best: {bb.upper()}   | mid->high  reward(+dmg)={rew:.2f}  risk(+taken)={risk:.2f}  "
              f"risk/reward={rr:.2f}{tag}")
    bands = set(best.values())
    print(f"\n  best-by-archetype: {best}")
    print(f"  mage wants: {best['pure mage'].upper()} (litmus expects LOW)   |   distinct bands used: {sorted(bands)}")
    phys = {a: b for a, b in best.items() if ARCH[a]["physical"]}
    if set(phys.values()) == {"high"}:
        print("  -> every physical build still wants HIGH. P4 fragile; M too high.")
    else:
        print(f"  -> physical builds SPLIT {phys}. P4 base case holds at this M.")
    return best

def pb_sweep():
    """How robust is 'high is no longer free for the archer' to the taunt strength PB?
    PB=0.0 reproduces the pre-fix B9 world (no taunt vulnerability)."""
    global PB
    print("\n" + "#"*84)
    print("# PB SENSITIVITY — protected archer: does high stay a real cost as taunt weakens?")
    print("# (rr = risk/reward of mid->high; best = archer's preferred Brave)")
    print("#"*84)
    saved = PB
    for M in (1.56, 1.45, 1.35, 1.25):
        print(f"\n  M={M:.2f}:")
        for pb in (0.00, 0.15, 0.25, 0.35, 0.50):
            PB = pb
            rew = value("protected archer", "high", M)[1] - value("protected archer", "mid", M)[1]
            risk = dmg_taken("protected archer", "high") - dmg_taken("protected archer", "mid")
            rr = risk / rew if rew > 0.01 else float('nan')
            bb = best_brave("protected archer", M)
            free = "  <-- FREE (B9 open)" if rr < 0.35 else ""
            print(f"    PB={pb:.2f}: archer best={bb:4}  rr={rr:.2f}{free}")
    PB = saved

if __name__ == "__main__":
    print("BRAVE offense-swing tuning — net-HP currency, taunt-fix (PB) and A1 (stun off Brave) baked in")
    for M in (1.56, 1.45, 1.35, 1.30, 1.25, 1.20):
        report(M)
    print("\n" + "#"*84)
    print("# SUMMARY: best Brave per archetype as M shrinks (looking for the split + non-free archer)")
    print("#"*84)
    print(f"  {'M':>5} | {'frontline':>9} {'archer':>7} {'duelist':>8} {'tank':>5} {'mage':>5}")
    for M in (1.56, 1.45, 1.35, 1.30, 1.25, 1.20):
        b = {a: best_brave(a, M) for a in ARCH}
        print(f"  {M:5.2f} | {b['frontline DPS']:>9} {b['protected archer']:>7} "
              f"{b['evasive duelist']:>8} {b['front tank']:>5} {b['pure mage']:>5}")
    pb_sweep()

# sim_brave_offense — tuning the Brave offense-swing magnitude (B9 part 3)

**Question (Marcelo, 2026-06-26):** with B9's structural break already fixed (A1: stun off Brave;
taunt INVERTED so high Brave is provokable), what should the **high-Brave offense multiplier `M`** be?
Today it is `1.56` (low `0.76`). Run sims, watch each build, tweak until a defensible number.

## Model (built to falsify "keep 1.56")

- **Fair currency.** Net HP swing per round = `damage dealt − damage taken − control lost`, all in the
  same damage units. (The old `sim_brave.py` compared full-DPR offense to a *fractional* defense cost,
  which structurally guaranteed offense would dominate — it could never find the knee.)
- **Conservative toward high Brave.** Net-HP ignores kill-tempo (a dead enemy stops hitting back), so it
  *under*-rewards offense. If high still wins here, it wins harder in play. → the knee it finds is a
  *floor* for "melee DPS still wants high."
- **The two locked fixes are baked in:** `WILL_CC` = high Brave resists only will-override statuses
  (fear/charm/confuse/berserk); stun is physical (off Brave). `PB` = provoke exposure bump: a high-Brave
  unit eats `+PB` extra attacks/round because taunt can pull it out of cover.
- Five archetypes (frontline DPS, protected archer, evasive duelist, front tank, pure mage) with
  placeholder exposure/dpr/dodge declared in the script and **fixed before reading the output**.

## What the sweep showed

**best Brave per archetype as `M` shrinks (PB=0.35):**

| M | frontline | archer | duelist | tank | mage |
|------|------|------|------|------|------|
| 1.56 | high | high | high | low | low |
| 1.45 | high | high | high | low | low |
| **1.35** | **high** | **high** | **high** | **low** | **low** |
| 1.30 | low | high | high | low | low |
| 1.25 | low | mid | mid | low | low |

- **Mage wants LOW at every M** — litmus robust (mage offense is Brave-flat, so only its magic
  vulnerability + defense matter). **Tank wants LOW at every M.** The split (P4) never collapses.
- **Frontline DPS flips off `high` below M≈1.35** *in this offense-conservative model.* So 1.35 is the
  floor that keeps the glass-cannon-melee-wants-high fantasy without leaning on (unmodeled) kill-tempo.

**The decisive finding — PB sensitivity (is high still a real cost for the protected archer?):**
`rr` = risk/reward of going mid→high (extra damage taken ÷ extra damage dealt). `rr<0.35` ≈ "high is FREE" = B9 open.

| | PB=0.00 | PB=0.15 | PB=0.25 | PB=0.35 | PB=0.50 |
|------|------|------|------|------|------|
| M=1.56 | 0.10 ⚠FREE | 0.32 ⚠FREE | 0.47 | 0.62 | 0.84 |
| M=1.45 | 0.12 ⚠FREE | 0.40 | 0.58 | 0.77 | 1.05 |
| **M=1.35** | 0.15 ⚠FREE | **0.51** | **0.75** | **0.99** | 1.35 |
| M=1.25 | 0.21 ⚠FREE | 0.72 | 1.05 | 1.39 | 1.89 |

## Read

1. **The taunt fix (PB), not the number (M), is what closes B9.** At `PB=0` (no taunt vulnerability) the
   archer's high is FREE at *every* M, even 1.25 (rr=0.21). Shrinking the offense swing alone never fixes
   B9 — confirms the structural fix was necessary and is load-bearing.
2. **M and PB trade off, and taunt is deliberately rare** (`13`: control statuses = few jobs, real cost,
   never oppressive). So `PB` is realistically *low* (~0.15–0.25). The prudent move is to size `M` so the
   B9 fix still holds **at low PB** — i.e., not lean on a rare status being common.
   - At **M=1.35**, even a rare taunt (PB=0.15) keeps the archer's high a real cost (rr=0.51); a moderate
     taunt (0.25) gives 0.75. Robust.
   - At **M=1.56**, a rare taunt (PB=0.15) leaves high borderline-free (rr=0.32). Fragile — it *needs*
     taunt to be common, which the design says it won't be.
3. **M=1.35 is the intersection** of all three constraints: melee DPS still wants high (conservative
   floor), the archer's high stays non-free even if taunt is rare, and the swing stays dramatic
   (`1.35 / 0.76 ≈ 1.8×` low→high; or `≈1.6×` if low is kept at 0.85). Mage/tank want low throughout.

## Recommendation

**High-Brave offense `M = 1.35`** (down from 1.56); low end kept ~`0.76` (optionally deepened toward
Faith's `0.60` floor for Brave↔Faith symmetry + a real bunker sacrifice — a secondary knob).
**Design rule learned:** *because the B9 corrective (taunt) is deliberately rare, the offense swing must
be modest (~1.35) so Brave stays honest without depending on a rare status.* Final exact value + the
Faith-symmetry match remain calibration; sensitivity to PB is documented above so no single value drives it.

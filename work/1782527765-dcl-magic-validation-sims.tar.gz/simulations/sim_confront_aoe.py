#!/usr/bin/env python3
"""
sim_confront_aoe.py — FALSIFY the AoE caster-supremacy break (M2 / MR-3), THEN quantify the fix.

TWO independent auditors (GPT + Claude convergence) found the same load-bearing gap: the magic
calibration EXCLUDED AoE, and AoE is the real caster-supremacy vector. The single-target G_m* anchor
(=0.65 on sim_core's physical scale) was fitted to "mage single-target battle-total == fighter total
vs a soft target" (decision 11.49). But the mage's signature spells (Fira/Firaga) are AoE, and the
design treats clustering as a CORE payoff. With AoE active:
  - CTX-B (attrition: fighter out-sustains a soft target past T>=12) is ERASED for k>=2 (audit_aoe_ctxB).
  - CTX-A (rush the lone robe mage) is NOT AI-executable: the repo's own docs say the targeting AI is
    "out of scope / unmapped" (13-statuses:157, ex-05-RE:158); the FFT AI closes-to-melee + focus-fires
    but does NOT reliably rush a back-line caster (critics/ai-targeting-research.md). A screening
    frontline also flips the 1v1 (audit_ctxA_frontline). => CTX-A is a 1v1 mechanic, not an AI behaviour.
So MR-3's >=2 COMMON, AI-EXECUTABLE losing contexts is UNMET as specced. This is philosophy.md's #1
(caster supremacy) AND #2 (AI can't play it) failure modes at once.

PART 1 reproduces the break on the physical (sim_core) scale.
PART 2 sweeps the fix levers and finds the region that restores >=2 losing contexts that rely ONLY on
AI-ACTUAL behaviour (close-to-melee + focus-fire + the mage's OWN MP/charge/range limits + encounter
geometry) — NOT the aspirational "AI rushes the squishy."

Reuses sim_confront_supremacy machinery (GM_STAR, fighter_turn, spell_onhit, bolt_onhit, the burst
economy, targets/stages) UNCHANGED. The generalized group-battle below reduces to S.mage_burst_battle
when k=1 and all levers are off (asserted at import).

AXES CROSSED: stage {early,mid,late} x cluster k {1,2,3} x target archetype
  {plate,leather,monk,thief,robe} x MP-state {fresh,depleted} x lever sweeps (per-target MP, AoE
  spell_power, AoE charge, friendly-fire) x blended E[k] {1.0,1.3,1.5,2.0} x G_m sweep.
AXES SKIPPED (named, with bias sign):
  - LIVE AI verification: Windows-only; this Linux checkout cannot launch the game. Reachability/rush
    are modelled mechanically (deterministic CT race) -> the AI-executability claim is reasoned, not
    engine-proven (the whole point of the AI-actual reframing).
  - Real ENTD map geometry / spawn positions: cluster size k and start-distance are PARAMETERS, not
    read from encounters -> a designer still must author maps that expose the mage (stated, not assumed).
  - Zodiac off-neutral, status/CC, healing-AoE, Reflect/absorb: neutral element only here (separate
    breaks). Off-neutral weakness only HELPS magic -> neutral is CONSERVATIVE for the 'fixed' claim.
  - Multi-mage stacking (a party that is ALL casters): per-mage analysis only -> if one mage is bounded,
    N mages scale linearly like N fighters; the stacking degeneracy is a separate (encounter) axis.
  - Reaction/Counter (punishes the meleeing fighter, never the ranged bolt): omitted -> slightly favors
    the FIGHTER, conservative against the bolt.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_confront_supremacy as S
from sim_core import injury, p_land, CONFIG

GM        = S.GM_STAR
STAGES    = S.STAGES
FSK       = S.FIGHTER_SKILL
TARGETS   = dict(S.TARGETS)                 # copy; we add a monk archetype
GEN_W     = S.GEN_W
CRUSH     = S.CRUSH_MULT
SP, COST  = S.SP, S.COST
POOL, TRICK = S.MP_POOL, S.MP_TRICK
BOLT      = S.BOLT_SP_DEFAULT
spell_onhit = S.spell_onhit
bolt_onhit  = S.bolt_onhit
fighter_turn = S.fighter_turn

# monk target archetype (martial artist: unarmored-light, evasive, mid HP) — added for the spread.
# Inject into BOTH the local copy and the supremacy module's table (fighter_turn reads S.TARGETS).
TARGETS["monk"] = {"armor": "leather", "dodge": 10, "hp": 150}
S.TARGETS["monk"] = TARGETS["monk"]
SOFT = ("leather", "thief", "robe", "monk")

def hr(c="="): print(c*100)

# ============================================================================
# Generalized mage group-battle with AoE-cost levers.
#   pt_mp   (a1) per-target MP fraction: an AoE burst on k targets costs base*(1+pt_mp*(k-1))
#   aoe_sp  (a5) multi-target spell_power multiplier (Firaga deals SP*aoe_sp when it is AoE)
#   aoe_chg (a4) EXTRA dead charge turns on AoE bursts (0 = current 2-turn occupancy; 1 = +1 telegraph)
#   ff      (a3) friendly-fire fraction: net cluster value loses ff (clipping own frontline / mispos.)
# Reduces to S.mage_burst_battle when k=1 and all levers off (asserted below).
# Returns (group_total, bolt_total, burst_total, n_bursts).
# ============================================================================
def mage_group(ma, gm, T, k, *, pool=POOL, trick=TRICK, bolt_sp=BOLT,
               pt_mp=0.0, aoe_sp=1.0, aoe_chg=0, ff=0.0, magic_evade=0.0):
    mp = pool; pending = None; cd = 0; t = 0
    bolt_tot = 0.0; burst_tot = 0.0; nb = 0
    def land(x): return x * (1.0 - magic_evade)
    need = 1 + aoe_chg                                  # dead turns before an AoE burst resolves
    kc = COST["Firaga"] * (1 + pt_mp * (k - 1))
    ic = COST["Fira"]   * (1 + pt_mp * (k - 1))
    while t < T:
        mp += trick
        if pending is not None:                         # resolving a charged AoE burst
            cd -= 1
            if cd == 0:
                d1 = land(spell_onhit(ma, SP[pending] * aoe_sp, gm))
                burst_tot += d1 * k * (1.0 - ff)        # hits all k; ff discounts net value
                nb += 1; pending = None
            t += 1; continue
        if mp >= kc and t < T - need:
            mp -= kc; pending = "Firaga"; cd = need
        elif mp >= ic and t < T - need:
            mp -= ic; pending = "Fira"; cd = need
        else:
            bolt_tot += land(bolt_onhit(ma, gm, bolt_sp))   # single-target free floor
        t += 1
    return bolt_tot + burst_tot, bolt_tot, burst_tot, nb

# self-check: with k=1 and levers off, the group battle == the trusted baseline economy
_base = S.mage_burst_battle(STAGES["mid"], 1.0, T=10)[0]
_grp  = mage_group(STAGES["mid"], 1.0, 10, 1)[0]
assert abs(_base - _grp) < 1e-6, f"group economy diverged from baseline: {_base} vs {_grp}"

# ============================================================================
# Blended-G_m re-anchor: assume the mage averages E[k] targets on its AoE bursts, set G_m so
# (single-target bolt floor + E[k]*burst) == fighter total vs soft. Bolt stays single-target.
# ============================================================================
def blended_gm(Ek, stage="mid", T=10, pool=POOL, trick=TRICK, bolt_sp=BOLT):
    ma = pa = STAGES[stage]; sk = FSK[stage]
    ftot = fighter_turn(pa, sk, "leather", "right") * T
    _, bolt1, burst1, _ = mage_group(ma, 1.0, T, 1, pool=pool, trick=trick, bolt_sp=bolt_sp)
    return ftot / (bolt1 + Ek * burst1), ftot, bolt1, burst1

def bolt_floor_ratio(gm, stage="mid", bolt_sp=BOLT):
    ma = pa = STAGES[stage]; sk = FSK[stage]
    return bolt_onhit(ma, gm, bolt_sp) / fighter_turn(pa, sk, "leather", "right")

def attrition_crossover(gm, k, stage="mid", **lev):
    """First T of a SUSTAINED fighter lead (fighter ahead at T AND still ahead at T+4) — skips the
    opening charge-turn transient so we read the real front-load->attrition crossover, not the start."""
    ma = pa = STAGES[stage]; sk = FSK[stage]
    f_leu = fighter_turn(pa, sk, "leather", "right")
    for T in range(3, 72):
        a = mage_group(ma, gm, T,   k, **lev)[0] < f_leu * T
        b = mage_group(ma, gm, T+4, k, **lev)[0] < f_leu * (T + 4)
        if a and b:
            return T
    return None

def mage_ever_leads(gm, k, stage="mid", T_hi=20, **lev):
    """Does the mage out-damage the fighter at ANY T<=T_hi? (front-load present => not over-nerfed)."""
    ma = pa = STAGES[stage]; sk = FSK[stage]
    f_leu = fighter_turn(pa, sk, "leather", "right")
    return any(mage_group(ma, gm, T, k, **lev)[0] >= f_leu * T for T in range(3, T_hi + 1))

def calibrate_realized(k_typ, stage="mid", T=10, **lev):
    """Co-calibrate G_m WITH the AoE cost active: set G_m so the mage's REALIZED output on a typical
    k_typ-cluster (levers on) == fighter total vs soft. Avoids the double-count of blend-E[k] x per-target-MP."""
    ma = pa = STAGES[stage]; sk = FSK[stage]
    ftot = fighter_turn(pa, sk, "leather", "right") * T
    out1 = mage_group(ma, 1.0, T, k_typ, **lev)[0]      # output is linear in G_m
    return ftot / out1

def cluster_multiple(gm, k, stage="mid", T=10, **lev):
    """mage group output at k / mage single-target output at k=1 (levers off). 'how much AoE pays'."""
    ma = STAGES[stage]
    grp = mage_group(ma, gm, T, k, **lev)[0]
    base = mage_group(ma, gm, T, 1)[0]
    return grp / base

def vs_fighter(gm, k, stage="mid", T=10, tgt="leather", **lev):
    """mage group output / fighter group output (fighter clears the cluster at constant dpt)."""
    ma = pa = STAGES[stage]; sk = FSK[stage]
    grp = mage_group(ma, gm, T, k, **lev)[0]
    return grp / (fighter_turn(pa, sk, tgt, "right") * T)

# ============================================================================
# Reachability: deterministic CT race (rush) + once-adjacent TTK on the 110-HP/0-DR robe mage.
# ============================================================================
def rush_duel(start_dist, gm, bolt_sp=BOLT, frontline_delay=0, stage="mid",
              mage_hp=110, atk_hp=130, atk_speed=10, mage_speed=7, atk_skill=13,
              pt_mp=0.0, aoe_chg=0):
    """A fast flanker closes on the mage; the mage kites with bolt + bursts. Returns (winner, tick)."""
    pa = ma = STAGES[stage]
    def atk_hit():                                       # dual-wield backstab vs robe (no defense)
        strike = injury(pa, GEN_W, "cut", "robe", CONFIG)
        return 2 * strike * p_land(atk_skill, TARGETS["robe"]["dodge"], "back")
    ct_a = ct_m = 0; mp = POOL; pending = None; cd = 0
    dist = start_dist; mhp = mage_hp; ahp = atk_hp; delay = frontline_delay
    need = 1 + aoe_chg
    kc = COST["Firaga"]                                  # rush = single target k=1, pt_mp irrelevant at k=1
    for tick in range(1, 400):
        ct_a += atk_speed; ct_m += mage_speed
        if ct_m >= 100 and mhp > 0:                      # mage acts
            ct_m -= 100; mp += TRICK
            if pending is not None:
                cd -= 1
                if cd == 0:
                    ahp -= spell_onhit(ma, SP[pending], gm); pending = None
            elif mp >= kc:
                mp -= kc; pending = "Firaga"; cd = need
            else:
                ahp -= bolt_onhit(ma, gm, bolt_sp)
            if ahp <= 0:
                return "MAGE", tick
        if ct_a >= 100 and ahp > 0:                      # flanker acts
            ct_a -= 100
            if dist > 1:
                dist = max(1, dist - 4)
            elif delay > 0:
                delay -= 1
            else:
                mhp -= atk_hit()
            if mhp <= 0:
                return "FLANKER", tick
    return "TIMEOUT", 400

def adjacent_ttk(kind, stage="mid", mage_hp=110):
    """dmg/turn an already-adjacent attacker does to the robe mage, and turns-to-kill."""
    pa = STAGES[stage]; rd = TARGETS["robe"]["dodge"]
    if kind == "knight-front":
        dpt = injury(pa, GEN_W, "cut", "robe", CONFIG) * p_land(13, rd, "front")
    elif kind == "knight-flank":
        dpt = injury(pa, GEN_W, "cut", "robe", CONFIG) * p_land(13, rd, "back")
    elif kind == "monk-2hit":                            # martial artist: higher PA, 2 unarmed strikes
        dpt = 2 * injury(pa + 2, S.WMOD["baixo"], "crush", "robe", CONFIG) * p_land(13, rd, "front")
    elif kind == "thief-backstab":                       # dual-wield, behind
        dpt = 2 * injury(pa, GEN_W, "cut", "robe", CONFIG) * p_land(13, rd, "back")
    else:
        raise ValueError(kind)
    return dpt, mage_hp / max(dpt, 1e-9)

# ============================================================================
# MAIN
# ============================================================================
if __name__ == "__main__":
    print("CONFRONT AoE — FALSIFY the AoE caster-supremacy break, then quantify the fix")
    hr()
    print(f"physical scale = sim_core (G=1).  single-target-anchored G_m* = {GM:.3f}  (decision 11.49)")
    print(f"economy: pool {POOL} + {TRICK}/turn (~100 MP / T10).  Firaga 30 / Fira 18 MP, both AoE, 2-turn charge.")
    print(f"bolt = 0-MP single-target floor (sp {BOLT}).  targets: {', '.join(TARGETS)}")

    # ======================================================================
    # PART 1 — CONFIRM THE BREAK
    # ======================================================================
    hr()
    print("PART 1 — CONFIRM THE BREAK (AoE active, single-target-anchored G_m* = {:.3f})".format(GM))
    hr()
    print("1A. CTX-B attrition crossover vs a CLUSTER of k soft targets (mage bursts hit all k; fighter hits 1).")
    print("    ratio = mage group-dmg / fighter group-dmg ; crossover T = fighter overtakes (CTX-B alive).")
    print(f"    {'k':>3} | " + " ".join(f"T{t:<2}".rjust(7) for t in (8,10,12,16,20)) + " | crossover T")
    print("    " + "-"*78)
    p1_cross = {}
    for k in (1, 2, 3):
        cells = [f"{vs_fighter(GM, k, T=T):6.2f}" for T in (8,10,12,16,20)]
        cx = attrition_crossover(GM, k); p1_cross[k] = cx
        cs = str(cx) if cx else "NEVER"
        print(f"    {k:>3} | " + " ".join(c.rjust(7) for c in cells) + f" | {cs}")
    print("    READ: k=1 reproduces the report's CTX-B (~T11). At k>=2 the fighter never overtakes inside a")
    print("    real battle (no FFT fight runs 50+ turns) -> CTX-B is ERASED once enemies cluster.")

    print("\n1B. CALIBRATION OVERSHOOT — the mage's real (AoE) output vs the single-target anchor it was")
    print("    called 'balanced' against (== fighter total vs leather, mid, T10):")
    anchor = mage_group(STAGES["mid"], GM, 10, 1)[0]
    ftot10 = fighter_turn(STAGES["mid"], FSK["mid"], "leather", "right") * 10
    print(f"    single-target mage total = {anchor:5.0f}   (fighter anchor = {ftot10:.0f})")
    for k in (1, 2, 3):
        g = mage_group(STAGES["mid"], GM, 10, k)[0]
        print(f"    cluster k={k}: group output = {g:5.0f}   ({g/anchor:.2f}x anchor, {g/ftot10:.2f}x fighter)")

    print("\n1C. CTX-A 'rush the lone robe mage' — is it AI-EXECUTABLE?")
    print("    DOC FACTS (not a sim): the targeting AI is UNMAPPED / out-of-scope")
    print("      - docs/deep-combat-layer/13-statuses-and-reactions.md:157 — directed aggression 'requires")
    print("        understanding/modifying the game's targeting AI (out of scope for now)'.")
    print("      - 'auto-attack nearest' is documented ONLY as a Berserk-status fallback, never baseline.")
    print("      - critics/ai-targeting-research.md — FFT AI closes-to-melee + focus-fires, does NOT")
    print("        reliably rush a back-line caster; this Linux checkout cannot verify live (Windows-only).")
    print("    MECHANICAL leg — even granting a PERFECT rusher + a screening frontline (D blocked turns),")
    print("    is the 1v1 robust? (FLANKER = the rusher kills the mage):")
    print(f"      {'frontline-delay D':18} | dist3 | dist5")
    flip = None
    for D in (0, 2, 4, 6, 8):
        w3, _ = rush_duel(3, GM, frontline_delay=D)
        w5, _ = rush_duel(5, GM, frontline_delay=D)
        if flip is None and w3 == "MAGE" and w5 == "MAGE": flip = D
        print(f"      {D:<18} | {w3:>5} | {w5:>5}")
    flipmsg = f"only once screened D>={flip} turns" if flip is not None else "NOT even with 8 turns of screening"
    print(f"    -> the lone mage loses the rush ({flipmsg}) -> the 1v1 mechanic is ROBUST (matches the")
    print("       convergence auditor). So CTX-A does NOT fail on the mechanic; it fails ONLY on")
    print("       AI-EXECUTABILITY: the vanilla AI does not smart-rush the back-line (targeting unmapped, above).")
    print("    => CTX-A is a robust 1v1 MECHANIC the engine AI cannot TRIGGER -> not a COMMON AI-EXECUTABLE")
    print("       losing context. Its AI-actual replacement is (iii) reachability: the normal close-to-melee")
    print("       advance + encounter geometry reach the mage, then this same robust mechanic kills it.")

    print("\n  PART-1 VERDICT: with AoE live at the single-target G_m*, do >=2 COMMON, AI-EXECUTABLE losing")
    print(f"  contexts survive?  CTX-B erased at k>=2 (cross k2={p1_cross[2]}, k3={p1_cross[3]}); CTX-A is a robust")
    print("  1v1 mechanic the AI can't TRIGGER (targeting unmapped; no smart-rush).  ANSWER: NO -> M2 FAILS AS SPECCED.")

    # ======================================================================
    # PART 2 — QUANTIFY THE FIX
    # ======================================================================
    hr()
    print("PART 2 — QUANTIFY THE FIX")
    hr()

    # ---- 2A: AoE-cost levers, each swept INDEPENDENTLY at the single-target G_m* ----
    print("2A. AoE-COST LEVERS (each alone, G_m* fixed). Goal: bound the cluster multiple AND bring the")
    print("    MP-attrition crossover back inside a real battle (T<=~16) at k=2.")
    print(f"    {'lever':30} | {'mult k2':>7} {'mult k3':>7} | {'xover k2':>8} {'xover k3':>8} | {'bolt flr':>8}")
    print("    " + "-"*86)
    base_flr = bolt_floor_ratio(GM)
    levers = [
        ("baseline (no AoE cost)",        dict()),
        ("per-target MP  lambda=0.5",     dict(pt_mp=0.5)),
        ("per-target MP  lambda=1.0",     dict(pt_mp=1.0)),
        ("AoE spell_power x0.7",          dict(aoe_sp=0.7)),
        ("AoE charge +1 (telegraph)",     dict(aoe_chg=1)),
        ("friendly-fire 0.20",            dict(ff=0.20)),
        ("pt_mp0.5 + chg+1 (combo)",      dict(pt_mp=0.5, aoe_chg=1)),
    ]
    for name, lev in levers:
        m2 = cluster_multiple(GM, 2, **lev); m3 = cluster_multiple(GM, 3, **lev)
        x2 = attrition_crossover(GM, 2, **lev); x3 = attrition_crossover(GM, 3, **lev)
        x2s = str(x2) if x2 else "NEVER"; x3s = str(x3) if x3 else "NEVER"
        print(f"    {name:30} | {m2:7.2f} {m3:7.2f} | {x2s:>8} {x3s:>8} | {base_flr:8.2f}")
    print("    READ: per-target MP is the strongest single lever — it taxes EXACTLY the cluster (the mage's")
    print("    OWN budget drains faster on more targets), so it is AI-INDEPENDENT. lambda=1.0 fully flattens")
    print("    AoE (output independent of k); lambda=0.5 keeps a real but bounded cluster payoff.")
    # finite-radius / break-even-N (the 'needs >=N clustered to be worth it' lever), derived:
    for asp in (0.7, 0.6):
        print(f"    finite-radius break-even: at AoE spell_power x{asp}, AoE beats a full single-target nuke only")
        print(f"      at k >= {1/asp:.2f} -> needs >=2 clustered targets to pay (a positional gate, not a damage cap).")
    print("    per-target MP keeps AoE >= single-target MP-efficiency at every k (k=1 pays nothing extra) —")
    print("    it caps the UPSIDE without ever making AoE strictly worse than single-target. That's the clean knob.")

    # ---- 2B: blended-G_m re-anchor; bolt-floor guard ----
    print("\n2B. RE-ANCHOR G_m ON A BLENDED E[k] (single + E[k]*burst == fighter). Bolt-floor must stay >=0.50")
    print("    (else the depleted mage is dead weight -> M3/heroic breaks).")
    print(f"    {'E[k]':>5} | {'G_m_blend':>9} | {'bolt/leather-ftr':>16}  guard(>=0.50)")
    print("    " + "-"*54)
    gm_blend = {}
    for Ek in (1.0, 1.3, 1.5, 2.0):
        g, *_ = blended_gm(Ek); gm_blend[Ek] = g
        fr = bolt_floor_ratio(g)
        ok = "OK" if fr >= 0.50 else "DEAD-WEIGHT"
        print(f"    {Ek:5.1f} | {g:9.3f} | {fr:16.2f}  {ok}")
    print("    READ: the pure re-anchor self-caps at E[k]~1.3 (G_m~0.53, bolt 0.54). At E[k]>=1.5 the bolt")
    print("    floor falls below 0.50 -> dead weight. This is the auditors' collision: you CANNOT absorb a")
    print("    2-target cluster by dropping the WHOLE spine, because that kills the single-target bolt floor.")
    print("    => the spine-wide G_m can only carry a MODEST blend; the AoE-specific cost (2A) must carry the rest.")

    # ---- 2C: the AI-ACTUAL losing contexts, tested under the candidate fix ----
    print("\n2C. AI-ACTUAL LOSING CONTEXTS (rely ONLY on close-to-melee + focus-fire + the mage's OWN")
    print("    MP/charge/range limits + encounter geometry — NOT 'AI rushes the squishy').")

    # CANDIDATE FIX — co-calibrate G_m WITH the per-target-MP cost live (NOT blend-E[k] x lever, which
    # double-taxes). per-target MP lambda=0.5 is the surgical, AI-independent cluster cap; then set G_m
    # so the mage's REALIZED typical-2-cluster output == a fighter. Existing charge>=1 telegraph is kept
    # (NOT increased — charge+1 over-nerfs, see 2A). The abstract E[k] blend (2B) brackets this G_m.
    FIXLEV = dict(pt_mp=0.5)
    GM_FIX = calibrate_realized(2, **FIXLEV)
    print(f"\n    CANDIDATE FIX:  per-target MP lambda=0.5  +  G_m re-anchored to realized 2-cluster parity = {GM_FIX:.3f}")
    print(f"    (vs single-anchor 0.652; the E[k] blend in 2B brackets it: E[k]=1.0->0.65, E[k]=1.3->0.53.)")

    print("\n    (i) MP-ATTRITION (the mage's OWN limit; AI-independent). Does the fighter out-sustain a long")
    print("        fight EVEN with AoE on a cluster? (mage front-loads bursts, then floors to the bolt.)")
    print(f"        {'k':>3} | {'mage leads early?':>17} | {'T10 ratio':>9} | {'sustained xover T':>17}")
    ok_attr = True
    for k in (1, 2, 3):
        leads = mage_ever_leads(GM_FIX, k, **FIXLEV)
        r10 = vs_fighter(GM_FIX, k, **FIXLEV)
        xf = attrition_crossover(GM_FIX, k, **FIXLEV)
        if k == 2 and (xf is None or xf > 20): ok_attr = False
        print(f"        {k:>3} | {str(leads):>17} | {r10:9.2f} | {str(xf) if xf else 'NEVER':>17}")
    print("        READ: at k=2 the mage front-loads (leads early) then the fighter overtakes and STAYS ahead")
    print("        inside a real battle -> the MP-attrition losing context RETURNS, driven purely by the mage's")
    print("        own budget. (Unfixed, k>=2 was NEVER — see 1A.)")

    print("\n    (ii) SPREAD / SINGLE-TARGET + magic-evade (lone target, no cluster, target bought the slot).")
    print("         mage full output (fresh, k=1) vs fighter, vs a lone evasive thief, magic-evade 0 vs 0.5:")
    ma = pa = STAGES["mid"]; sk = FSK["mid"]
    f_thief = fighter_turn(pa, sk, "thief", "right") * 10
    for me in (0.0, 0.5):
        mg = mage_group(ma, GM_FIX, 10, 1, magic_evade=me)[0]
        tag = "auto-land -> mage's GOOD matchup" if me == 0 else "slot bought -> mage UNDERPERFORMS"
        print(f"         evade {me:.1f}: mage {mg:5.0f} vs fighter {f_thief:5.0f}  ({mg/f_thief:.2f}x)  {tag}")
    print("         READ: vs a LONE evasive target the auto-landing mage WINS without the slot -> this is a")
    print("         losing context ONLY when the magic-evade slot is bought, which the AI won't shop ->")
    print("         author-dependent (key foes / anti-magic jobs). A real but CONDITIONAL 3rd context.")

    print("\n    (iii) REACHABILITY / TTK — once the AI's normal close-to-melee advance ARRIVES at the exposed")
    print("          110-HP / 0-DR mage (front collapses / mage caught — NOT a smart rush), how fast does it die?")
    print(f"          {'attacker (adjacent)':22} | {'dmg/turn':>8} | {'turns-to-kill':>13} | bursts landed first")
    ttk_thief = None
    for kind in ("knight-front", "monk-2hit", "thief-backstab", "knight-flank"):
        dpt, ttk = adjacent_ttk(kind)
        if kind == "thief-backstab": ttk_thief = ttk
        print(f"          {kind:22} | {dpt:8.1f} | {ttk:13.1f} | ~{int(ttk // 2)}")
    ok_reach = (ttk_thief is not None and ttk_thief <= 3.5)
    print("          also the RUSH RACE under the fix (lone mage, weaker at G_m_fix), start dist 3/5:")
    for sd in (3, 5):
        w, tk = rush_duel(sd, GM_FIX)
        print(f"            start_dist={sd}: {w} at tick {tk}")
    print("          READ: a fast flanker/backstabber kills the robe in <=3 turns once adjacent (<=1 burst")
    print("          landed); the lone mage loses the rush race. AI-actual via close-to-melee + focus-fire +")
    print("          encounter geometry (maps must expose the mage) — NOT the back-line rush the engine lacks.")

    # ---- 2D: combined-fix scorecard + identity preservation ----
    print("\n2D. COMBINED-FIX SCORECARD (does it restore >=2 robust AI-actual contexts AND keep mage identity?)")
    ma = pa = STAGES["mid"]; sk = FSK["mid"]
    mult2 = cluster_multiple(GM_FIX, 2, **FIXLEV); mult3 = cluster_multiple(GM_FIX, 3, **FIXLEV)
    flr = bolt_floor_ratio(GM_FIX)
    # anti-armor: the identity is "no loadout-slot needed, flat vs DR + scales on clusters", NOT
    # "out-damages a perfectly-countered crush specialist on ONE target". Measure it honestly:
    mg_pl_single = mage_group(ma, GM_FIX, 10, 1)[0]
    mg_pl_k2     = mage_group(ma, GM_FIX, 10, 2, **FIXLEV)[0]
    f_pl_crush = fighter_turn(pa, sk, "plate", "right") * 10                  # right tool (crush)
    f_pl_cut   = S.fighter_onhit(pa, "plate", "fixed") * p_land(sk, TARGETS["plate"]["dodge"]) * 10  # wrong tool (cut)
    aa_wrong = mg_pl_single / f_pl_cut                                        # vs a sword that bounces off plate
    aa_right = mg_pl_single / f_pl_crush                                      # vs the crush specialist
    aa_clust = mg_pl_k2 / f_pl_crush                                         # AoE flat-vs-armor at scale
    print(f"    bolt floor vs leather-fighter ............... {flr:.2f}   ({'OK >=0.50' if flr>=0.5 else 'DEAD WEIGHT'})")
    print(f"    cluster payoff (k2 / k3 vs own single) ...... {mult2:.2f}x / {mult3:.2f}x   (bounded; was 1.74 / 2.48 unfixed)")
    print(f"    anti-armor vs WRONG-tool (cut) fighter, plate {aa_wrong:.2f}x   ({'kept (>1)' if aa_wrong>1 else 'LOST'})  <- the real identity")
    print(f"    anti-armor vs RIGHT-tool (crush), 1 plate ... {aa_right:.2f}x   (~parity is fine: fighter's right-tool answer)")
    print(f"    anti-armor vs RIGHT-tool (crush), 2-plate AoE {aa_clust:.2f}x   ({'kept (>1)' if aa_clust>1 else 'lost'})  <- flat-vs-armor at scale")
    print(f"    MP-attrition context (i) returns ............ {ok_attr}")
    print(f"    reachability context (iii) returns .......... {ok_reach}  (thief TTK {ttk_thief:.1f})")
    antiarmor_kept = (aa_wrong > 1.0 and aa_clust > 1.0)
    print(f"    => anti-armor identity kept (wrong-tool + cluster) . {antiarmor_kept}")
    n_robust = int(ok_attr) + int(ok_reach)
    print(f"    => robust AI-ACTUAL losing contexts restored: {n_robust} (need >=2)")

    # ======================================================================
    # PART 3 — SPREAD COVERAGE & SENSITIVITY
    # ======================================================================
    hr()
    print("PART 3 — SPREAD: stage x k x archetype x MP-state, and G_m/E[k] sensitivity")
    hr()
    print("3A. mage/fighter group-dmg ratio under the FIX (G_m={:.3f}, per-target MP 0.5), per stage x k.".format(GM_FIX))
    print("    >1 = mage ahead (T10). vs leather; fighter clears the cluster at constant dpt.")
    print(f"    {'stage':6} | {'k=1':>6} {'k=2':>6} {'k=3':>6}")
    for stg in ("early", "mid", "late"):
        cells = [f"{vs_fighter(GM_FIX, k, stage=stg, **FIXLEV):6.2f}" for k in (1,2,3)]
        print(f"    {stg:6} | " + " ".join(cells))

    print("\n3B. archetype spread (mid, T10): mage FRESH (full MP) vs mage DEPLETED (bolt-floor only) vs fighter.")
    print("    TTK = HP / dmg-per-turn; lower kills faster. k=1 (no cluster) to isolate the archetype matchup.")
    print(f"    {'target':8} {'HP':>4} | {'mageFRESH':>9} {'TTKf':>5} | {'mageDEPL(bolt)':>14} {'TTKd':>5} | {'fighter':>7} {'TTKx':>5}")
    for tgt in ("plate", "leather", "monk", "thief", "robe"):
        hp = TARGETS[tgt]["hp"]
        # NOTE: mage damage is element/DR-blind, so the archetype only changes HP & (for fighter) DR/dodge.
        mf = mage_group(STAGES["mid"], GM_FIX, 10, 1)[0] / 10
        md = bolt_onhit(STAGES["mid"], GM_FIX)
        ff = fighter_turn(STAGES["mid"], FSK["mid"], tgt, "right")
        print(f"    {tgt:8} {hp:>4} | {mf*10:9.0f} {hp/max(mf,1e-9):5.1f} | "
              f"{md*10:14.0f} {hp/max(md,1e-9):5.1f} | {ff*10:7.0f} {hp/max(ff,1e-9):5.1f}")
    print("    READ: DEPLETED mage (bolt floor) is SLOWER than the fighter on every soft target (TTKd > TTKx)")
    print("    -> the attrition loss is archetype-robust; its only edge is plate (anti-armor) and auto-land vs thief.")

    print("\n3C. SENSITIVITY — G_m sweep (with per-target MP 0.5 live): bolt floor, k=2 sustained crossover,")
    print("    k=2 vs-fighter ratio @T10. Brackets the safe G_m window; the realized-2-cluster anchor sits inside.")
    print(f"    {'G_m':>6} {'bolt flr':>8} {'k2 xover':>9} {'k2 vs ftr':>10} {'note':>22}")
    cand = sorted({gm_blend[1.3], gm_blend[1.0], GM_FIX, 0.50, 0.58, 0.60})   # exact (not rounded) so the FIX row matches 2C
    for g in cand:
        fr = bolt_floor_ratio(g)
        x2 = attrition_crossover(g, 2, **FIXLEV); m2 = vs_fighter(g, 2, **FIXLEV)
        note = "<- realized-2cluster FIX" if abs(g-GM_FIX) < 1e-6 else (
               "bolt dead-weight" if fr < 0.50 else ("E[k]=1.3 blend" if abs(g-gm_blend[1.3])<1e-6 else
               ("single-anchor (hot)" if abs(g-gm_blend[1.0])<1e-6 else "")))
        print(f"    {g:6.3f} {fr:8.2f} {str(x2) if x2 else 'NEVER':>9} {m2:10.2f} {note:>22}")
    print("    (k=2 crossover is numerically sensitive AT exact parity — the cumulative curves hug; read it as")
    print("     'inside a real battle ~T10-15', not a sharp integer.)")
    print("    Also the abstract E[k] blend (no lever) for reference — bolt floor guard caps it at E[k]~1.3:")
    print(f"    {'E[k]':>6} {'G_m':>8} {'bolt flr':>9}")
    for Ek in (1.0, 1.3, 1.5, 2.0):
        g = gm_blend[Ek]; print(f"    {Ek:6.1f} {g:8.3f} {bolt_floor_ratio(g):9.2f}")
    print("    READ: safe G_m window ~[0.53,0.60] with per-target MP 0.5 — bolt floor >=0.50 AND k=2 attrition")
    print("    crossover inside a real battle. Recommended = realized-2-cluster anchor (~0.55). Higher G_m keeps")
    print("    a stronger single-target anti-armor edge but pushes the cluster crossover later; lower kills the bolt.")

    # ======================================================================
    # VERDICT FLAGS (ground truth)
    # ======================================================================
    hr()
    print("VERDICT FLAGS (computed):")
    break_ctxB = (p1_cross[2] is None or p1_cross[2] > 30)
    overshoot2 = mage_group(STAGES["mid"], GM, 10, 2)[0] / anchor
    print(f"  P1 break: CTX-B erased at k=2 (crossover {p1_cross[2]}) ........... {break_ctxB}")
    print(f"  P1 break: cluster output overshoot k=2 = {overshoot2:.2f}x anchor .... {overshoot2 > 1.5}")
    print(f"  P1 break: CTX-A AI-executable? (docs say targeting unmapped) ....... False (reasoned)")
    print(f"  P1: >=2 COMMON AI-EXECUTABLE losing contexts survive as specced .... False  <-- M2 FAILS")
    print(f"  P2 fix: bolt floor under fix >= 0.50 .............................. {flr >= 0.50} ({flr:.2f})")
    print(f"  P2 fix: cluster payoff bounded (k2 {mult2:.2f}x < 1.6) ............... {mult2 < 1.6}")
    print(f"  P2 fix: anti-armor identity kept (wrong-tool >1 AND cluster >1) ... {antiarmor_kept} ({aa_wrong:.2f}x / {aa_clust:.2f}x)")
    print(f"  P2 fix: MP-attrition context (i) returns at k=2 .................. {ok_attr}")
    print(f"  P2 fix: reachability context (iii) returns ....................... {ok_reach}")
    print(f"  P2 fix: >=2 robust AI-ACTUAL losing contexts restored ............ {n_robust >= 2}  ({n_robust})")
    hr()
    print("Ground truth above; interpretation in sim_confront_aoe_READ.md.")

# sim_confront_aoe — READ (AoE caster-supremacy: FALSIFY the break, then quantify the fix)

**What it does.** Takes the load-bearing gap both convergence auditors landed on — *AoE was excluded from
the magic calibration, and AoE is the real caster-supremacy vector* — and (Part 1) reproduces the break on
the trusted physical (`sim_core`) scale, then (Part 2) sweeps the design levers to find the region that
restores **≥2 common losing contexts that rely ONLY on AI-ACTUAL behaviour** (close-to-melee + focus-fire +
the mage's own MP/charge/range limits + encounter geometry), not the aspirational "AI rushes the squishy."
Reuses `sim_confront_supremacy` (G_m\*, the burst economy, targets) unchanged; the generalized group-battle
reduces to `S.mage_burst_battle` when k=1 with levers off (asserted at import). **The script's printed output
is ground truth; this only interprets it.**

---

## (1) THE CONFIRMED BREAK — does M2 fail as specced? **YES.**

At the single-target-anchored **G_m\*=0.652** (decision 11.49: mage single-target battle-total ≈ a fighter's
vs a soft target), with AoE active (Fira/Firaga hit a cluster of `k`; the free bolt stays single-target):

| | k=1 (single, the report's CTX-B) | k=2 | k=3 |
|---|---|---|---|
| mage/fighter group-dmg @T10 | 1.00 | **1.74** | **2.48** |
| CTX-B attrition crossover (fighter overtakes) | **T≈11** ✓ holds | **T≈57** (no battle lasts this) | **NEVER** |
| cluster output vs the single-target anchor | 1.00× | **1.74×** | **2.48×** |

- **CTX-B (attrition) is ERASED at k≥2.** The mage's signature spells are AoE, so the calibration anchored its
  *worst* case (single-target). On any clustered fight the "balanced" mage runs **1.74–2.48× hot** — exactly
  philosophy.md's "AoE that's just more damage" failure mode. Reproduces the GPT + Claude auditors' figures
  (T10 mage 194 vs fighter 111; k=2 crossover ~T56–57; cluster 1.74/2.48×).
- **CTX-A (rush the lone robe mage) is a robust 1v1 MECHANIC the AI cannot TRIGGER.** The deterministic CT race
  shows the 110-HP/0-DR mage **loses the rush even with 8 turns of screening delay** (so the mechanic is real —
  credit where due, matching the convergence auditor). But the repo's own manual of truth says the **targeting
  AI is unmapped / out-of-scope** (`docs/deep-combat-layer/13-statuses-and-reactions.md:157`; "auto-attack
  nearest" is only a Berserk fallback, never baseline). The vanilla AI **closes-to-melee + focus-fires** but
  does **not** smart-rush a back-line caster (`critics/ai-targeting-research.md`), and this Linux checkout
  cannot verify live. So CTX-A is **not AI-EXECUTABLE** as "rush the squishy."

**Net:** with AoE live, **CTX-B is gone (k≥2) and CTX-A is not AI-triggerable → ZERO robust common
AI-EXECUTABLE losing contexts for "bring mages." M2 FAILS AS SPECCED** — the run's #1 chartered failure
(caster supremacy) AND #2 ("the AI can't play it") at once. This is **not calibration-fixable by G_m alone**
(see §2): the single-target anchor cannot bound a multi-target kit.

---

## (2) THE FIX REGION — which levers restore ≥2 AI-actual contexts, at what identity cost

**Two families of lever, and why one alone fails:**

- **(b) Re-anchor G_m on a blended E[k]** (single + E[k]·burst ≈ fighter) **alone hits a hard wall.** Because
  the bolt floor scales with the *same* spine, dropping G_m to absorb a cluster kills the depleted-mage floor:
  E[k]=1.0→G_m 0.65 (bolt 0.66 ✓), E[k]=1.3→0.53 (bolt **0.54**, the last safe step), E[k]=1.5→0.48 and
  E[k]=2.0→0.38 (**both DEAD-WEIGHT**, bolt < 0.50). You **cannot** absorb a 2-target cluster by dropping the
  whole spine — that's the auditors' "G_m≈0.38 collides with the heroic bolt floor," reproduced exactly.
- **(a) An AoE-SPECIFIC cost** is what the spine-wide G_m can't be: surgical and **AI-independent**. The
  strongest is a **per-target MP cost** (an AoE on k targets costs `base·(1+λ(k-1))`): the mage's *own* budget
  drains faster on bigger clusters, so it caps the cluster UPSIDE without ever making AoE worse than
  single-target (k=1 pays nothing extra). At λ=0.5 the k=2/k=3 cluster multiple falls **1.74/2.48 → 1.18/1.57**
  and the MP-attrition crossover returns from `T57/NEVER → T21/T36`; λ=1.0 fully flattens AoE (output
  independent of k). Reduced AoE spell_power (×0.7 → break-even needs ≥2 clustered) and +1 AoE charge are
  weaker/cruder variants; friendly-fire (a *player-side* positional cost) is real but positioning-dependent.

**The region that works = a MODEST G_m re-anchor + an AoE-specific cost, together.** Per-target MP λ≈0.5
carries the cluster cap; G_m re-anchored to the mage's **realized** typical-2-cluster output (≈0.55, which the
abstract blend brackets at E[k] 1.0→1.3) carries the "AoE was free in the old anchor" correction — **without**
the double-tax of stacking a full E[k] blend on top of a full per-target cost. Safe window: **G_m ∈ [0.53,
0.60] with λ=0.5** (bolt floor ≥0.50 AND k=2 attrition crossover inside a real battle).

**Identity cost (honest):** the single-target anti-armor *edge* softens — the full single-target mage goes from
1.08× a right-tool crush specialist on one plate to **~0.91×** (a tie, not a loss). That is **acceptable and
correct**: the mage's anti-armor identity is "no loadout-slot needed + flat-vs-DR + scales on clusters," not
"out-damages a perfectly-countered crush specialist on one target." Measured honestly the identity is **kept**:
vs a WRONG-tool (sword/cut) fighter on plate **1.44×**, and on a **2-plate cluster 1.08×** (flat-vs-armor at
scale). The bolt floor stays heroic (0.56), and clustering still pays a real **1.18×/1.57×** (k2/k3) — bounded,
not erased.

---

## (3) THE RECOMMENDED FIX (the design fork, resolved)

**Adopt BOTH, jointly co-calibrated:**

1. **AoE pays per target in MP — `cost = base · (1 + λ(k-1))`, λ ≈ 0.5.** A Firaga on 3 targets costs ~2× a
   single-target Firaga, so big clusters drain the per-battle budget ~twice as fast. AI-independent (it's the
   mage's own resource), legible, and it taxes *exactly* the supremacy vector. Keep the existing **charge ≥ 1**
   telegraph (do **not** add +1 — the combo over-nerfs, collapsing the cluster payoff to ~1.05×).
2. **Re-anchor G_m to the realized typical-2-cluster output, `G_m ≈ 0.55`** (down from the single-target 0.65;
   the abstract E[k] blend brackets it at E[k] 1.0→1.3). This bakes AoE into the budget so the mage hits
   parity at its *typical* cluster, not its worst case.

**Resulting named losing contexts (the two robust + one conditional):**

- **(i) MP-attrition — ROBUST, AI-independent.** The mage front-loads ~2 cluster bursts then floors to the
  bolt; the fighter out-sustains. Under the fix the fighter overtakes and **stays** ahead inside a real battle
  at k=2 (crossover ~T10–14, near-parity-sensitive) and k=3 (~T18) — was `NEVER` unfixed. Driven purely by the
  mage's own budget; needs no AI smarts. The depleted (bolt-only) mage is **slower than a fighter on every soft
  archetype** (TTK 17.8–24.2 vs 8.6–19.0) — archetype-robust.
- **(iii) Reachability — ROBUST via documented AI + geometry.** Once the AI's normal **close-to-melee advance**
  reaches the exposed 110-HP/0-DR mage (front collapses / mage caught — *not* a smart rush), a flanker/
  backstabber kills it in **~2.7 turns** (≤1 burst landed); even a front-attacking knight kills it in ~5–9.
  This is the AI-actual replacement for CTX-A: same robust mechanic, triggered by encounter geometry + the
  documented advance, not by back-line targeting the engine lacks. **Encounter-authoring obligation:** maps
  must put melee in reach of the casters.
- **(ii) Spread / magic-evade — CONDITIONAL 3rd.** Vs a *lone* evasive target the auto-landing mage WINS
  without the slot (1.38×) — it's a losing context **only** when a dedicated magic-evade slot is bought
  (0.69×), which the AI won't shop. Real but author-dependent (give key foes / anti-magic jobs the slot).

**Mage identity preserved:** bolt floor 0.56 (heroic, never dead weight), clustering pays 1.18×/1.57× (a real
positional payoff, bounded — was 1.74×/2.48×), anti-armor kept vs wrong-tool (1.44×) and at cluster scale
(1.08×). **Scorecard: 2 robust AI-actual losing contexts restored + identity intact → M2 satisfied under the
fix.**

---

## (4) WHAT WOULD FLIP THIS READ

- **(i) flips if** the per-target MP cost is **not** adopted: G_m re-anchoring alone caps at E[k]≈1.3 before the
  bolt dies, which under-bounds a 2-cluster — the mage stays hot on clusters and MP-attrition does not return.
  The fix is the **conjunction**; neither lever alone suffices.
- **(iii) flips if** encounters **don't** expose the casters to the AI's melee advance. Reachability is a real
  mechanic but its *AI-executability* is **encounter-authored**, not engine-native — if maps keep mages
  permanently un-reachable, context (iii) evaporates and the fix falls back to (i) alone (one context, M2
  unmet). **This is the single biggest open dependency** and is verifiable only on the live Windows build (the
  one axis this sim cannot close): does the vanilla AI's close-to-melee + focus-fire actually arrive at and
  kill an exposed mage? If the live AI tunnels nearer/available targets and never reaches the mage even when
  geometry allows, (iii) weakens to "human-only," leaving (i) + (ii-conditional).
- **The whole break is monotone in G_m and λ.** Raising G_m back toward 0.65 (or a Rod magic-power mod lifting
  bolt/spell tiers) re-inflates the cluster and re-erases (i); lowering λ toward 0 removes the cluster cap.
  Conversely λ→1.0 (full per-target cost) makes AoE pure tempo (no damage advantage) and would *over*-satisfy
  M2 at the cost of the clustering payoff the philosophy sells — so λ is a real design dial, not a free win.
- **Untested corners (named):** live AI verification (Windows-only — the load-bearing one); real ENTD map
  geometry (k and start-distance are parameters here, not encounters); multi-mage *stacking* (a full caster
  party scales like N fighters once each is bounded, but the AoE-overlap of several mages on one cluster is a
  separate encounter axis); off-neutral Zodiac / status-AoE / healing-AoE / Reflect (each only *helps* magic →
  neutral here is conservative for the "fixed" claim). If any of these tilt magic harder, the recommended λ
  rises and/or G_m drops within the [0.53, 0.60] window.

#!/usr/bin/env python3
"""
sim_confront_faith.py — MR-2: is Faith genuinely TWO-SIDED per unit, or one-sided PER ROLE?

P4 (doc 00.4 / register 08.x): Faith is a permanent two-sided slider — "no universally-best
setting." The SUSPICION under test (falsify it, honestly):
    Faith is one-sided PER ROLE — a CASTER always wants HIGH (output), a NON-CASTER always wants
    LOW (free magic-defense, since a physical unit's offense rides BRAVE, not Faith — 02.9/07.6/08.6).
    If so the per-unit "slider" is cosmetic: every unit has a forced pick, the trait is bimodal-by-role.

This is the same defect the BRAVE run found (sim_brave.py): HIGH Brave won for BOTH physical
archetypes (frontline AND protected archer) because the −2 active-defense downside is ~free for the
unexposed; the split survived only via the mage litmus + the taunt inversion. We test whether Faith
inherits the parallel defect by SYMMETRY.

THE CRUX the suspicion misses (and this sim quantifies):
    Low Faith is NOT a free dump. Target-Faith scales HEALING RECEIVED ×0.70 (11.29 / 12.5, LOCKED:
    "one Faith rule for all magic") — so a low-Faith unit costs ×1/0.70 = ×1.43 heal-budget to top off.
    And that tax falls on the WHOLE damage it takes (physical included), while low Faith's magic-defense
    only refunds the MAGIC fraction. So the most-exposed/most-healed unit — the one that most wants the
    magic defense — is the worst one to dump Faith on. That is the atheist-tank heal paradox (test 3).

Falsification logic:
  - If LOW strictly minimizes a non-caster's team-cost across all plausible battle/heal profiles
    -> low Faith is strictly correct for every non-caster -> suspicion CONFIRMED (one-sided per role).
  - If the best non-caster Faith MOVES with heal-reliance / magic-frequency / buff-scaling
    -> the slider is live -> suspicion REFUTED (genuinely two-sided per unit).

Objective (team-resource cost to FIELD this unit at Faith F; the unit's own OFFENSE is Faith-flat for
a non-caster so it cancels and is shown == 0):
    cost(F) = heal_budget(F) + hp_pool_drain(F) + status_loss(F)            [minimise]
  where, normalising incoming threat to 1.0 at mid-Faith and letting fm = faith_mult(F):
    base_D(F)   = (1−m) + m·fm                 # only the MAGIC fraction m scales with target Faith
    D(F)        = base_D(F)·(1 − buff_prevent)  # buffs prevent some damage; scale on Faith iff opted in
    heal_budget = h · D(F) / fm                 # restore healed fraction h; heals LAND at ×fm  <-- the tax
    hp_drain    = w_hp · (1−h) · D(F)           # unhealed damage eats the HP pool / KO risk
    status_loss = status_freq · p_inflict(F)    # magical status resists on INVERSE Faith (13.13/13.14)

Numbers come from the existing sims: Faith band [0.70,1.30] centred 1.0 (sim_magic_faith), inverse-Faith
status, G_m≈3 (cancels in a per-unit ratio). Every magnitude is swept so no single value drives a verdict.
"""

from sim_core import p_le
from sim_magic_faith import faith_mult

# ---- Faith levels & the band -------------------------------------------------
LEVELS = ("low", "mid", "high")
F_OF = {"low": 25, "mid": 55, "high": 85}          # atheist / neutral / zealot (sim_magic_faith band)
BL, BH = 0.70, 1.30                                  # provisional band; swept at the bottom

def fm(level, bl=BL, bh=BH):
    return faith_mult(F_OF[level], bl, bh)

# magical-status infliction probability vs target Faith (inverse-Faith: low resists, high succumbs).
# Grounded in the 13.x 3d6 contest (resist number falls as Faith rises): p_inflict = 1 − P(3d6 ≤ resist).
# resist numbers low/mid/high = 12/10/8 -> p_inflict 0.259/0.500/0.741. Curve is open (doc OQ); we keep
# the SHAPE and scale its intensity in the sweep.
P_INFLICT_BASE = {"low": 1 - p_le(12), "mid": 1 - p_le(10), "high": 1 - p_le(8)}

def p_inflict(level, intensity=1.0):
    # intensity 0 -> flat 0.5 (Faith doesn't touch status); 1 -> full inverse-Faith spread
    base = P_INFLICT_BASE[level]
    return 0.5 + intensity * (base - 0.5)

# ---- the two value functions -------------------------------------------------
def noncaster_cost(level, *, m, h, w_hp, status_freq, status_intensity,
                   buff_reliance, buff_scaling, bl=BL, bh=BH, B0=0.35):
    """Team-resource cost to keep a NON-CASTER (Faith-flat offense) alive at Faith `level`. Lower=better."""
    f = fm(level, bl, bh)
    base_D = (1 - m) + m * f
    buff_strength = f if buff_scaling else 1.0          # do received buffs scale on target Faith?
    buff_prevent = buff_reliance * B0 * buff_strength
    D = base_D * (1 - buff_prevent)
    heal_budget = h * D / f                              # <-- the ×1/fm healing tax
    hp_drain = w_hp * (1 - h) * D
    status_loss = status_freq * p_inflict(level, status_intensity)
    total = heal_budget + hp_drain + status_loss
    return total, dict(D=D, heal=heal_budget, hp=hp_drain, st=status_loss)

def caster_value(level, *, enemy_m, exposure, hit_mag, status_freq, status_intensity,
                 turn_value, bl=BL, bh=BH, base_out=1.0):
    """Net value of a CASTER at Faith `level` (offense IS Faith-scaled). Higher=better."""
    f = fm(level, bl, bh)
    output = base_out * f                                # PRIMARY contribution, +/-30%
    vuln = exposure * enemy_m * f * hit_mag              # caster takes magic ×fm (fragile robe)
    status = status_freq * p_inflict(level, status_intensity) * turn_value  # stopped caster = 0 output
    return output - vuln - status, dict(out=output, vuln=vuln, st=status)

def best(d, maximise=False):
    return (max if maximise else min)(d, key=d.get)

# ---- battle profiles (enemy-side) & unit archetypes (team-side) --------------
BATTLE = {                       # enemy-caster frequency -> magic fraction m + status frequency
    "low-magic":  dict(m=0.15, status_freq=0.10),
    "med-magic":  dict(m=0.35, status_freq=0.20),
    "high-magic": dict(m=0.60, status_freq=0.35),
}
# non-caster archetypes: differ by how they survive (DR-soak vs heal-lean) and buff appetite.
ARCH = {
    "plate knight":       dict(h=0.20, w_hp=0.55, buff_reliance=0.60),  # DR soaks; modest heal; prime buff target
    "leather skirmisher": dict(h=0.40, w_hp=0.65, buff_reliance=0.40),  # low DR; leans on heals/evasion
    "monk":               dict(h=0.45, w_hp=0.70, buff_reliance=0.50),  # HP bruiser in melee; heal-lean
}
STATUS_INTENSITY = 1.0
TURN_VALUE = 1.0


def line(): print("   " + "-" * 74)

# ============================================================================
if __name__ == "__main__":
    print("=" * 82)
    print("MR-2 — Faith: genuinely two-sided per unit, or one-sided PER ROLE (cosmetic slider)?")
    print("   band [%.2f,%.2f]  fm low/mid/high = %.2f / %.2f / %.2f   heal-budget mult 1/fm = %.2f / %.2f / %.2f"
          % (BL, BH, fm("low"), fm("mid"), fm("high"), 1/fm("low"), 1/fm("mid"), 1/fm("high")))
    print("=" * 82)

    # -- test 1 headline: what low Faith GAINS vs COSTS a non-caster -----------
    print("\nTEST 1 — 'low Faith = free defensive dump for a non-caster': priced out")
    print("  GAINS (low vs mid):  incoming magic ×%.2f (−%.0f%% on the magic fraction);  magical-status"
          % (fm("low"), 100*(1-fm("low"))))
    print("  infliction %.2f→%.2f (−%.0f%% chance to be slept/stopped/petrified)."
          % (p_inflict("mid"), p_inflict("low"), 100*(1-p_inflict("low")/p_inflict("mid"))))
    print("  OFFENSE COST: 0.00 — a non-caster's offense rides BRAVE, not Faith (02.9/07.6/08.6). Confirmed flat.")
    print("  HIDDEN COST:  healing received ×%.2f -> ×%.2f heal-budget to top off (11.29/12.5, LOCKED);"
          % (fm("low"), 1/fm("low")))
    print("  and that ×1.43 tax hits the top-off of ALL damage taken (physical included), while the magic")
    print("  refund only covers the magic fraction. -> low Faith is a TRADE, not a free dump.")

    # -- test 1/4 core: best Faith per archetype x battle, buff-scaling off then on
    for scaling in (False, True):
        tag = ("BUFFS scale on target-Faith (proposed 'taunt-inversion' rescue)" if scaling
               else "buffs do NOT scale on Faith (LOCKED rules only: healing+damage+status)")
        print("\n" + "#" * 82)
        print(f"#### NON-CASTER best Faith — {tag}")
        print("#" * 82)
        collapse = {}
        for arch, ap in ARCH.items():
            print(f"\n  {arch}  (heal-reliance h={ap['h']}, hp-weight {ap['w_hp']}, buff-reliance {ap['buff_reliance']}):")
            for bname, bp in BATTLE.items():
                costs = {}
                for lv in LEVELS:
                    c, _ = noncaster_cost(lv, m=bp["m"], h=ap["h"], w_hp=ap["w_hp"],
                                          status_freq=bp["status_freq"], status_intensity=STATUS_INTENSITY,
                                          buff_reliance=ap["buff_reliance"], buff_scaling=scaling)
                    costs[lv] = c
                b = best(costs)
                collapse.setdefault(bname, []).append(b)
                cells = "  ".join(f"{lv}={costs[lv]:.3f}" for lv in LEVELS)
                print(f"    {bname:>10}: {cells}   -> best {b.upper()}")
        # collapse check, per battle column
        print("\n  best-Faith spread across the 3 non-caster archetypes, by battle:")
        anylive = False
        for bname, picks in collapse.items():
            uniq = set(picks)
            note = "ALL same -> one-sided" if len(uniq) == 1 else "SPLIT -> slider live"
            if len(uniq) > 1: anylive = True
            print(f"    {bname:>10}: {picks}  ({note})")
        print("  -> " + ("at least one battle splits the archetypes: the non-caster slider is LIVE here."
                         if anylive else
                         "every battle picks ONE band for all non-casters: non-caster Faith COLLAPSED one-sided."))

    # -- test 2 + D: caster side, and the MID-Faith search ---------------------
    print("\n" + "#" * 82)
    print("#### TEST 2 — CASTER side: is HIGH strictly correct? Is the caster slider ever live?")
    print("#" * 82)
    print("  caster: backline robe (exposure 0.20, hit_mag 1.5), stopped-caster turn_value 1.2\n")
    print(f"   {'enemy pressure':>22} | {'low':>7} {'mid':>7} {'high':>7} | best")
    line()
    caster_picks = []
    pressures = [
        ("calm (low-magic)",       dict(enemy_m=0.15, exposure=0.15, hit_mag=1.3, status_freq=0.08)),
        ("typical (med-magic)",    dict(enemy_m=0.35, exposure=0.20, hit_mag=1.5, status_freq=0.15)),
        ("magic-heavy",            dict(enemy_m=0.60, exposure=0.30, hit_mag=1.8, status_freq=0.25)),
        ("status-siege (extreme)", dict(enemy_m=0.70, exposure=0.50, hit_mag=2.2, status_freq=0.50)),
    ]
    for label, pp in pressures:
        vals = {}
        for lv in LEVELS:
            v, _ = caster_value(lv, enemy_m=pp["enemy_m"], exposure=pp["exposure"], hit_mag=pp["hit_mag"],
                                status_freq=pp["status_freq"], status_intensity=STATUS_INTENSITY,
                                turn_value=1.2)
            vals[lv] = v
        b = best(vals, maximise=True)
        caster_picks.append(b)
        print(f"   {label:>22} | {vals['low']:>7.3f} {vals['mid']:>7.3f} {vals['high']:>7.3f} | {b.upper()}")
    print(f"\n  caster best across pressure = {caster_picks}")
    print("  -> " + ("CASTER IS ROBUSTLY ONE-SIDED HIGH" if set(caster_picks) == {"high"}
                     else f"caster slider moves: {set(caster_picks)}")
          + " — the +/-30% OUTPUT swing on the caster's primary job dwarfs the vuln/status fractions.")

    print("\n  MID-Faith search — scan (non-caster heal-reliance × magic) for cells where MID is the UNIQUE best:")
    hm_label = "h \\ m"
    print(f"   {hm_label:>7} | " + " ".join(f"{bp['m']:>10.2f}" for bp in BATTLE.values()))
    line()
    mid_cells = 0; total_cells = 0
    for h in (0.10, 0.20, 0.30, 0.40, 0.50, 0.60):
        row = []
        for bname, bp in BATTLE.items():
            costs = {lv: noncaster_cost(lv, m=bp["m"], h=h, w_hp=0.6, status_freq=bp["status_freq"],
                                        status_intensity=STATUS_INTENSITY, buff_reliance=0.5,
                                        buff_scaling=False)[0] for lv in LEVELS}
            b = best(costs); total_cells += 1
            if b == "mid": mid_cells += 1
            row.append(f"{b.upper():>10}")
        print(f"   {h:>7.2f} | " + " ".join(row))
    print(f"  -> MID is the unique best in {mid_cells}/{total_cells} non-caster cells. Faith is NOT bimodal-by-role")
    print("     if MID wins a real region; it IS effectively bimodal if MID is a thin seam between LOW and HIGH.")

    # -- test 3: atheist-tank heal paradox, quantified ------------------------
    print("\n" + "#" * 82)
    print("#### TEST 3 — atheist-tank heal paradox: the ×1.43 healing tax vs the magic-defense refund")
    print("#" * 82)
    print("  A unit healed back fraction h of its damage. Extra heal-budget from LOW vs MID Faith, and the")
    print("  magic-defense saving, as the battle's magic fraction m varies (h=0.40, the exposed-tank case):\n")
    print(f"   {'m (magic frac)':>16} | {'heal-budget LOW/MID':>20} | {'extra budget':>12} | {'magic dmg saved':>15} | net")
    line()
    h = 0.40
    for m in (0.0, 0.2, 0.35, 0.5, 0.7, 1.0):
        _, lo = noncaster_cost("low", m=m, h=h, w_hp=0.6, status_freq=0.0, status_intensity=0,
                               buff_reliance=0.0, buff_scaling=False)
        _, mi = noncaster_cost("mid", m=m, h=h, w_hp=0.6, status_freq=0.0, status_intensity=0,
                               buff_reliance=0.0, buff_scaling=False)
        extra = lo["heal"] - mi["heal"]                 # extra heal budget low costs over mid
        dmg_saved = mi["D"] - lo["D"]                   # less damage low takes (the refund)
        net = dmg_saved - extra                         # >0 = low is cheaper overall; <0 = paradox bites
        flag = "low cheaper" if net > 0 else "PARADOX: low COSTS more"
        print(f"   {m:>16.2f} | {lo['heal']:>9.3f}/{mi['heal']:<9.3f} | {extra:>+12.3f} | {dmg_saved:>15.3f} | {net:>+.3f} {flag}")
    print("\n  READ: for any battle with a PHYSICAL component (m<1) the ×1.43 tax on topping off ALL damage")
    print("  outweighs the magic refund, so a HEALED low-Faith tank is a NET drain — and the frontline tank is")
    print("  exactly the most-healed unit. Low Faith's 'downside' bites hardest on the unit that most wants it.")

    # -- the crossover h* ------------------------------------------------------
    print("\n  Crossover h* — heal-reliance at which LOW stops being the strict best (med-magic, buff off):")
    bp = BATTLE["med-magic"]; hstar = None
    for h in [i/100 for i in range(0, 81, 2)]:
        costs = {lv: noncaster_cost(lv, m=bp["m"], h=h, w_hp=0.6, status_freq=bp["status_freq"],
                                    status_intensity=STATUS_INTENSITY, buff_reliance=0.5,
                                    buff_scaling=False)[0] for lv in LEVELS}
        if best(costs) != "low":
            hstar = h; break
    print(f"   -> below h≈{hstar:.2f} LOW wins (heal-light heroic-soak meta); above it MID/HIGH take over.")
    print("   The DCL's own pillars (heroic full-HP, DR-primary armor, MP-scarce budget) PUSH toward heal-light")
    print("   -> the regime where the non-caster slider COLLAPSES to LOW is the regime the design encourages.")

    # -- test 4: Brave symmetry ------------------------------------------------
    print("\n" + "#" * 82)
    print("#### TEST 4 — does Faith inherit BRAVE's one-sided collapse by symmetry?")
    print("#" * 82)
    print("  BRAVE (sim_brave): −active-defense downside is ~free for the UNEXPOSED -> HIGH won for BOTH")
    print("    physical archetypes; split survived only via the mage litmus + the FORCED taunt inversion.")
    print("  FAITH (here):      −healing/buff downside is ~free for the UN-HEALED  -> LOW wins for non-casters")
    print("    in the heal-light regime; the heal countervail only bites if the unit is actually healed/buffed.")
    print("  Parallel defect: 'the downside only bites a subset, so the other subset gets a free pick.'")
    print("  KEY DIFFERENCE: Brave's rescue (taunt) is a FORCED mechanic (drags the protected into the open);")
    print("  Faith's healing countervail is PLAYER-OPTIONAL (just don't heal the low-Faith tank, soak instead).")
    print("  Faith's caster pole is also MORE rigid than any Brave archetype (HIGH ~always; see TEST 2).")
    print("  -> Faith does not copy Brave exactly, but carries the same structural fragility, harder on the")
    print("     caster side. The matching FORCED rescue would be: make received BUFFS scale on target-Faith.")

    # -- sensitivity -----------------------------------------------------------
    print("\n" + "#" * 82)
    print("#### SENSITIVITY — band width, magic frequency, buff-scaling: where does the verdict move?")
    print("#" * 82)
    print("  Non-caster best Faith (plate knight, med-magic) across band width × buff-scaling:")
    print(f"   {'band':>14} | buff-off | buff-on")
    line()
    ap = ARCH["plate knight"]; bp = BATTLE["med-magic"]
    for bl, bh in [(0.80, 1.20), (0.70, 1.30), (0.65, 1.30)]:
        picks = []
        for sc in (False, True):
            costs = {lv: noncaster_cost(lv, m=bp["m"], h=ap["h"], w_hp=ap["w_hp"],
                                        status_freq=bp["status_freq"], status_intensity=STATUS_INTENSITY,
                                        buff_reliance=ap["buff_reliance"], buff_scaling=sc, bl=bl, bh=bh)[0]
                     for lv in LEVELS}
            picks.append(best(costs).upper())
        print(f"   [{bl:.2f},{bh:.2f}] | {picks[0]:>8} | {picks[1]:>7}")
    print("  -> wider-low band ([0.65,1.30]) deepens BOTH the magic-defense AND the healing tax (×1.54);")
    print("     buff-scaling ON is the lever that most reliably pulls a non-caster OFF the LOW corner.")

    print("\n  Heal-reliance × magic-frequency grid (plate knight, buff OFF) — best Faith:")
    hb_label = "h \\ battle"
    print(f"   {hb_label:>12} | " + " ".join(f"{b:>11}" for b in BATTLE))
    line()
    for h in (0.15, 0.30, 0.45, 0.60):
        row = []
        for bname, bp in BATTLE.items():
            costs = {lv: noncaster_cost(lv, m=bp["m"], h=h, w_hp=0.55, status_freq=bp["status_freq"],
                                        status_intensity=STATUS_INTENSITY, buff_reliance=0.6,
                                        buff_scaling=False)[0] for lv in LEVELS}
            row.append(f"{best(costs).upper():>11}")
        print(f"   {h:>12.2f} | " + " ".join(row))
    print("  -> the best non-caster Faith genuinely MOVES with heal-reliance and magic-frequency (LOW->MID->HIGH).")
    print("     The slider is live WHERE the meta heals; it is cosmetic (LOW-locked) where it does not.")

    print("\n  G_m note: G_m scales absolute magic magnitudes, not the per-unit Faith RATIO compared here, so it")
    print("  cancels; it sets how MUCH a wrong Faith pick costs in HP, not WHICH pick wins. (skipped axis)")

    print("\n" + "=" * 82)
    print("VERDICT (see _READ.md): the 'non-caster ALWAYS wants LOW' suspicion is REFUTED — even with")
    print("locked-rules-only (no buff scaling) the non-caster slider MOVES with magic-frequency and")
    print("heal-reliance (HIGH in low-magic, MID in med-magic, LOW in high-magic), and the atheist-tank")
    print("heal paradox gives low Faith a real, quantified cost (net drain at m<~0.35). The caster pole IS")
    print("one-sided HIGH — but that is the intended glass-cannon identity (a real downside accepted, not")
    print("avoided), flipping only under can't-function status-siege. Lean: HOLDS (FRAGILE) — two fragile")
    print("regimes (high-magic battles collapse non-casters to LOW; heal-light metas, h<~0.36, collapse them")
    print("too — exactly where the heroic DR-soak pillars push). ONE hardening rec: scale received BUFFS on")
    print("target-Faith (the taunt-inversion analog) so low Faith costs the exposed frontliner non-optionally.")
    print("=" * 82)

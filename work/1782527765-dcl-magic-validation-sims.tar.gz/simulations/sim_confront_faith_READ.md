# sim_confront_faith — MR-2 read: is Faith one-sided PER ROLE?

**Decision under test (P4 / 00.4 / 08.x):** Faith is a genuinely two-sided permanent slider — *no
universally-best setting*.
**Suspicion (tried to prove):** Faith is one-sided *per role* — a caster always wants HIGH (output), a
non-caster always wants LOW (free magic-defense, since a physical unit's offense rides **Brave**, not
Faith — 02.9/07.6/08.6). If so the per-unit slider is cosmetic; the trait is bimodal-by-role.

**Lean: HOLDS (fragile).** The strong suspicion is **refuted for non-casters** and **confirmed for
casters**, with two real fragility regimes and one clean hardening fix.

---

## The crux the suspicion misses (test 1)

Low Faith is **not a free dump**. The locked rule "one Faith rule for all magic" (11.29 / 12.5) means
**target-Faith scales healing received ×0.70**, so a low-Faith unit costs **×1.43 heal-budget** to top
off. Pricing the trade for a non-caster (low vs mid):

| lever | low-Faith effect | who it favors |
|---|---|---|
| **offense** | **×1.00 — flat** (rides Brave, not Faith) | neither — cancels |
| incoming magic | ×0.70 (−30% on the **magic fraction** `m`) | low |
| magical status (sleep/stop/petrify) | infliction 0.50 → 0.26 (−48%) | low |
| **healing received** | ×0.70 → **×1.43 heal-budget** on **all** damage topped off | **high** |
| buffs received (Protect/Haste/Regen) | weaker **iff** they scale on target-Faith (currently unspecified) | high |

So low Faith is a **trade** (magic-defense + status-resist *vs* healing/buff efficiency), not a free
defensive dump. The suspicion's premise ("zero offensive cost, pure defensive gain") is true on offense
but **false on sustain**.

## Non-caster slider is LIVE — even with locked-rules-only (no buff scaling)

Best Faith for the three physical archetypes, by enemy-caster frequency (buff scaling OFF):

| battle (magic frac) | plate knight | leather skirmisher | monk | spread |
|---|---|---|---|---|
| low-magic (m=0.15) | **MID** | HIGH | HIGH | split → slider live |
| med-magic (m=0.35) | LOW | **MID** | **MID** | split → slider live |
| high-magic (m=0.60) | LOW | LOW | LOW | **all LOW → one-sided** |

The best non-caster Faith **moves** LOW→MID→HIGH with magic-frequency × heal-reliance. In a **low-magic**
battle the plate knight's *worst* setting is LOW (almost no magic to resist, yet still ×1.43 to heal).
"Every non-caster always wants LOW" is **false** — it only holds in **high-magic** battles. (sim Part A,
and the heal×magic grids.)

## The atheist-tank heal paradox is real and quantified (test 3)

For a healed tank (heal-reliance h=0.40), extra heal-budget that LOW costs over MID vs the magic-damage it
refunds, as magic fraction `m` varies:

| m | extra heal-budget (low−mid) | magic dmg saved | **net** |
|---|---|---|---|
| 0.00 | +0.171 | 0.000 | **−0.171** low costs more |
| 0.20 | +0.137 | 0.060 | **−0.077** low costs more |
| 0.35 | +0.111 | 0.105 | **−0.006** ~break-even |
| 0.50 | +0.086 | 0.150 | +0.064 low cheaper |
| 1.00 | −0.000 | 0.300 | +0.300 low cheaper |

The ×1.43 tax hits the top-off of **all** damage (physical included); the magic refund only covers the
**magic fraction**. So for any battle with a physical component (`m < ~0.35`) a **healed** low-Faith tank
is a **net drain** — and the frontline tank is exactly the most-exposed, most-healed unit. Low Faith's
"downside" bites hardest on the unit that most wants the magic defense. **Crossover h\* ≈ 0.36** (med-magic):
below it LOW wins, above it MID/HIGH take over.

## Caster side IS one-sided HIGH (test 2) — but by design

| enemy pressure | low | mid | high | best |
|---|---|---|---|---|
| calm | 0.66 | 0.92 | 1.19 | HIGH |
| typical | 0.58 | 0.81 | 1.03 | HIGH |
| magic-heavy | 0.40 | 0.53 | 0.66 | HIGH |
| status-siege (extreme) | 0.005 | −0.07 | −0.15 | LOW |

The ±30% **output** swing on the caster's primary job dwarfs the vuln/status fractions; HIGH wins in every
realistic battle, flipping only under "can't-function" status-siege. This **confirms** the suspicion for
casters — but a caster wanting HIGH *is the intended glass-cannon identity* (08.5): the magic-fragility +
status-vulnerability downside is real and **accepted**, not avoided. It is a one-sided *choice*, but not a
degenerate dominance.

## Is MID ever best? (bimodal-by-role check)

MID is the unique best in **3/18** non-caster cells (buff off) — a genuine **diagonal seam** (as heal-reliance
rises, the MID band slides to higher magic), not a vestigial slot. With buff-scaling ON it widens. So Faith
is **not** cleanly bimodal — there is a real interior region — but that region is **modest** and contingent.

## Brave symmetry (test 4)

| | Brave (sim_brave) | Faith (here) |
|---|---|---|
| free-ride defect | −active-defense is ~free for the **unexposed** → HIGH won for **both** physical archetypes | −healing/buff is ~free for the **un-healed** → LOW wins for non-casters in heal-light metas |
| rescue | **taunt inversion** — *forced* (drags the protected into the open) | healing countervail — **player-optional** (just don't heal the low-Faith tank, soak instead) |
| other pole | mage litmus keeps casters off HIGH | caster pole is *more rigid* (HIGH ≈ always) |

Faith carries the **same structural fragility** as Brave (the downside only bites a subset, so the other
subset gets a near-free pick), but its non-caster countervail is **softer** (optional, not forced) and its
caster pole is **harder** (more one-sided). Faith does **not** copy Brave's exact collapse — the non-caster
slider is demonstrably live in common battles — but it shares the fragility class.

## Sensitivity (axes crossed)

- **Band width:** narrower [0.80,1.20] keeps plate at LOW even with buffs; [0.70,1.30]/[0.65,1.30] flip to MID
  with buff scaling on. Wider-low deepens **both** the magic-defense *and* the healing tax (×1.54).
- **Magic frequency (enemy-caster freq):** the single biggest lever — low→HIGH-favoring, high→LOW-locked for
  non-casters.
- **Heal-reliance h:** the decisive team-side lever; crossover h\* ≈ 0.36.
- **Buff-Faith scaling (on/off):** the most reliable lever to pull a non-caster **off** LOW; it is the
  proposed hardening fix.
- **Status frequency / intensity:** raises low Faith's appeal (more to resist), pushing h\* up.

**Axes skipped / held:** exact inverse-Faith 3d6 status curve (parametrized off 13.x resist numbers, swept by
intensity); `G_m` magnitude (cancels in the per-unit Faith ratio — it sets *how much* a wrong pick costs in
HP, not *which* pick wins); Magic Evade binary land-roll (folded into the net magic fraction `m`);
spell-tier/MA/base(MA) magnitudes (cancel); AoE shape / positioning (folded into `m`); the healer's
action-economy opportunity cost (proxied by heal-budget); Reflect/undead-invert; the caster's own Brave.

## Honest lean: **HOLDS (fragile)** — one revision recommended

- **Refuted:** "non-caster always wants LOW, slider cosmetic." The non-caster slider moves with battle and
  team context even on locked rules; low Faith carries a real, quantified sustain cost (atheist-tank paradox).
- **Confirmed:** the caster pole is one-sided HIGH — but as the *intended* glass-cannon identity, with a real
  accepted downside, not a dominance.
- **Fragile in two regimes:** (1) **high-magic battles** collapse all non-casters to LOW; (2) **heal-light
  metas** (h < ~0.36) collapse them too — and the DCL's own pillars (heroic full-HP-to-0, DR-primary armor,
  MP-scarce budget) actively push toward heal-light. The fragility lands exactly where the design steers.

### One-line "what would flip this"
> **Make received buffs (Protect/Haste/Regen/Shell) scale on target-Faith, like healing does.** Then the
> exposed frontliner — the prime buff target — pays a *non-optional* cost for low Faith (its buffs land 30%
> weaker), the forced analog of Brave's taunt inversion, and the non-caster slider stays live even in the
> heal-light, high-magic regimes where it currently collapses to LOW. Conversely, if a future ruling makes
> healing/buffs **Faith-independent** (heal/buff land flat regardless of target Faith), the non-caster
> countervail vanishes entirely and Faith **breaks** to one-sided LOW for every non-caster — the suspicion
> would then be proven.

#!/usr/bin/env python3
"""
sim_confront_heal.py — MR-5: does HEALING trivialize damage (stalemate / unkillable corner)?

FALSIFICATION TARGET (philosophy §2): "Healing trivializes damage. If heal-per-turn >= damage-per-turn,
fights stalemate or the team is unkillable. Target-Faith scaling and MP-gating are the claimed brakes."
SUSPICION: heal and damage SHARE the magic spine (register 11.28 / 12.5):
    heal = base(MA) x heal_power x faith_caster x faith_target x G_m      # the damage spine MINUS resist
so heal-per-cast == nuke-per-cast BY CONSTRUCTION (heal_per_turn ~ damage_per_turn by default). Try to
reach a stalemate / unkillable corner. Be honest both ways.

REUSE (no re-derivation): fmult()/SP/MA/G_M/heal()/dmg() from sim_magic_heal; injury()/p_land()/base_pa()/
CONFIG from sim_core. This file only CONFRONTS the two spines and adds (a) the MP-budget clock with the
"no heal floor" rule, and (b) the action-economy lens (a heal is a turn NOT attacking).

heal_power: UNSET in the docs (OQ-18). FIXED here to the labeled tier SP["Cura"]=1.8 (the standard
single-target sustain heal — the same tier the reused heal sim uses throughout its own PART C).
"strong heal" = SP["Curaga"]=3.0. SWEPT over {Cure 1.0, Cura 1.8, Curaga 3.0}; G_m in {2,3,4};
MP budget (heal-power POINTS / battle); # healers in {1,2}.

Axes CROSSED: phase(early/mid/late) x target-Faith(atheist/neutral/zealot) x target-armor(robe/mail/plate)
  x attacker-mix(phys-only / magic-nuke / both) x heal_power x G_m x MP-budget x #healers.
Axes SKIPPED (named): Speed/CT turn-cadence asymmetry (assumed 1:1 acting cadence — a real skip: a faster
  healer widens the window, a faster attacker shrinks it); charge-time per cast (folded into MP-as-burst);
  AoE heal vs AoE nuke (single-target lane only); Magic-Evade on the target (un-invested => magic lands p=1;
  dedicated-slot variant shown once); interrupt of a charged heal (noted in the determinism section);
  full 4v4 board AI (one target lane, action-economy-normalized instead); undead-invert (designed property).
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_core as core
import sim_magic_heal as mh

ATH, NEU, ZEAL = mh.ATH, mh.NEU, mh.ZEAL                 # 25 / 55 / 85
TIER = mh.SP                                             # {"Cure":1.0,"Cura":1.8,"Curaga":3.0}
HEAL_POWER_FIX = TIER["Cura"]                            # FIXED primary heal_power = 1.8 ("Cura")
STRONG = TIER["Curaga"]                                  # "strong heal" tier 3.0
L_BATTLE = 15                                            # nominal battle length (turns); swept-noted

# phase stat blocks — placeholders (RATIOS drive the verdict, and they are swept). "mid" anchors to the
# reused heal sim (MA=16, pools 110/150/220). early ~0.6x pools, late ~1.4x pools + DR inflation (02.13).
PHASE = {
 "early": dict(ma=10, pa=8,  wmod=core.CONFIG["wmod"]["medio"],      skill=11, drs=1.0, hp={"mage":70, "neu":95,  "tank":140}),
 "mid":   dict(ma=16, pa=10, wmod=core.CONFIG["wmod"]["alto"],       skill=12, drs=1.0, hp={"mage":110,"neu":150, "tank":220}),
 "late":  dict(ma=22, pa=13, wmod=core.CONFIG["wmod"]["muito_alto"], skill=13, drs=1.6, hp={"mage":150,"neu":210, "tank":300}),
}
ARMORS = ["robe", "mail", "plate"]                       # target armor: soft mage / mid / heavy tank

# ---------------------------------------------------------------------------
# reused spines, as NUMERIC-power wrappers (literally the body of mh.heal / mh.dmg)
# ---------------------------------------------------------------------------
def heal_amt(ma, power, fh, ft, gm):                     # == mh.heal with numeric heal_power
    return ma * power * gm * mh.fmult(fh) * mh.fmult(ft)
def nuke_amt(ma, power, fc, ft, gm, elem=1.0):           # == mh.dmg (neutral element)
    return ma * power * gm * mh.fmult(fc) * mh.fmult(ft) * elem
# self-check: the wrappers reproduce the reused module on the named tiers (faithful reuse, not a fork)
assert abs(heal_amt(mh.MA, TIER["Cura"], NEU, NEU, mh.G_M) - mh.heal("Cura", NEU, NEU)) < 1e-9
assert abs(nuke_amt(mh.MA, TIER["Cura"], NEU, NEU, mh.G_M) - mh.dmg("Cura", NEU, NEU))  < 1e-9

def phys_dpt(ph, armor, dtype="cut", brave="mid"):
    """expected physical damage/turn from ONE fighter (sim_core injury x p_land); returns (dpt, injury, p_land)."""
    cfg = dict(core.CONFIG)
    if ph["drs"] != 1.0:
        cfg["DR"] = {k: {t: v * ph["drs"] for t, v in d.items()} for k, d in core.CONFIG["DR"].items()}
    inj = core.injury(ph["pa"], ph["wmod"], dtype, armor, cfg, brave=brave)
    pol = core.p_land(ph["skill"], 8)                    # open target, no-shield Dodge floor 8 (04.9)
    return inj * pol, inj, pol

def incoming_dpt(ph, ft, armor, mix, gm, nuke_power=HEAL_POWER_FIX, nuke_fc=NEU):
    """combined incoming damage/turn on the target. mix in {'phys','magic','both'}. magic lands (p=1, un-invested)."""
    d = 0.0
    if mix in ("phys", "both"):
        d += phys_dpt(ph, armor)[0]
    if mix in ("magic", "both"):
        d += nuke_amt(ph["ma"], nuke_power, nuke_fc, ft, gm)     # spine-exact with heal
    return d

# ---------------------------------------------------------------------------
# turn-by-turn survival under the MP clock (NO heal floor: out of MP => HPT drops to 0)
# ---------------------------------------------------------------------------
def survive_turns(hp_max, incoming, heal_per_cast, healers, mp_points, power, horizon=60):
    """Each healer has mp_points heal-power POINTS; one cast/turn spends `power` points -> casts each.
    While a healer has budget it heals heal_per_cast; when ALL budget is gone HPT->0 (no heal floor)."""
    casts_each = mp_points / power if power > 0 else 0
    hp = hp_max
    for t in range(1, horizon + 1):
        active = healers if t <= casts_each else 0      # all healers share the same per-healer budget here
        hp = min(hp_max, hp + active * heal_per_cast)   # heal first (reactive, determinism: P3)
        hp -= incoming
        if hp <= 0:
            return t
    return horizon                                       # survived the whole horizon (>= unkillable-enough)

# ===========================================================================
if __name__ == "__main__":
    print("=" * 86)
    print("sim_confront_heal — MR-5: can HEALING reach a stalemate / unkillable corner?")
    print(f"  FIXED heal_power = Cura {HEAL_POWER_FIX} | strong = Curaga {STRONG} | L_battle = {L_BATTLE} turns")
    print("=" * 86)

    # -----------------------------------------------------------------------
    print("\n" + "=" * 86)
    print("PART A — the spine identity & the WASH (the structural worry, stated exactly)")
    print("=" * 86)
    ph = PHASE["mid"]
    h = heal_amt(ph["ma"], HEAL_POWER_FIX, NEU, NEU, mh.G_M)
    n = nuke_amt(ph["ma"], HEAL_POWER_FIX, NEU, NEU, mh.G_M)
    print(f"   mid, neutral/neutral, Cura tier: heal/cast = {h:.1f}   magic-nuke/cast = {n:.1f}   -> equal by construction")
    print("   incoming(both) - heal  =  [phys + nuke(tier_d,fc)] - heal(tier_h,fh)")
    print("   target Faith ft scales BOTH nuke-taken and heal-received -> it CANCELS; what's left is:")
    print("        = phys_dpt  +  base*G*ft*( tier_d*fmult(fc) - tier_h*fmult(fh) )")
    print("   => at equal tier & equal caster-Faith, the magic halves cancel and NET = phys_dpt (> 0).")
    print("   => a same-tier nuker EXACTLY ties a same-tier healer; the physical fighter is UNCOVERED damage.")
    print("   The 'heal==damage on one spine' worry is TRUE per-cast, but it is a 1:1 WASH, not a stalemate.")

    # -----------------------------------------------------------------------
    print("\n" + "=" * 86)
    print("PART B — per-turn heal vs incoming, and the break-even (#attackers one healer out-paces)")
    print("=" * 86)
    print("   1 healer, Cura, neutral healer & target. r = heal/turn / phys_dpt = #physical fighters out-paced.")
    print(f"   {'phase':6} {'armor':6} {'heal/turn':>9} {'phys/turn':>9} {'nuke/turn':>9} {'r=heal/phys':>12} {'heal/nuke':>9}")
    for pk in ("early", "mid", "late"):
        ph = PHASE[pk]
        hh = heal_amt(ph["ma"], HEAL_POWER_FIX, NEU, NEU, mh.G_M)
        nn = nuke_amt(ph["ma"], HEAL_POWER_FIX, NEU, NEU, mh.G_M)
        for ar in ARMORS:
            pp = phys_dpt(ph, ar)[0]
            print(f"   {pk:6} {ar:6} {hh:9.1f} {pp:9.1f} {nn:9.1f} {hh/pp:12.1f} {hh/nn:9.2f}")
    print("   READ: heal/nuke == 1.00 everywhere (spine-exact wash). heal/phys = r is LARGE (per-cast burst)")
    print("   and grows vs heavier armor (phys collapses on DR, heal is flat) -> per-turn a healer out-paces")
    print("   MANY fighters. That is the BURST window; whether it is a stalemate is decided by the MP clock (C).")
    print("   NB: r is a CROSS-SPINE magnitude (magic G_m=3 vs physical G=1, independently set) -> calibration,")
    print("   not a law. The design's own anchor (11.49: mage BATTLE-total ~ fighter battle-total vs soft) sets")
    print("   the per-battle ratio ~1; the big per-turn r is the gated burst, reconciled over the battle by MP.")

    # break-even against a MIXED attack (1 fighter + 1 same-tier nuker)
    print("\n   break-even vs a MIXED attack (1 fighter + 1 nuker), mid, neutral target in mail:")
    ph = PHASE["mid"]
    for hp_tier_name, hp_tier in (("Cura", TIER["Cura"]), ("Curaga", TIER["Curaga"])):
        hh = heal_amt(ph["ma"], hp_tier, NEU, NEU, mh.G_M)
        inc = incoming_dpt(ph, NEU, "mail", "both", mh.G_M, nuke_power=TIER["Cura"])
        print(f"     healer {hp_tier_name:6}: heal/turn {hh:6.1f}  vs  incoming(both) {inc:6.1f}  -> "
              f"{'OUT-PACES (out-tiers)' if hh > inc else 'falls behind by %.1f (the phys chip + tier gap)' % (inc - hh)}")

    # -----------------------------------------------------------------------
    print("\n" + "=" * 86)
    print("PART C — the MP gate: does the budget STOP sustained out-healing, or only DELAY it?")
    print("=" * 86)
    print("   total battle healing = MP_budget(points) x base(MA) x G_m x faith_c x faith_t  (split-independent).")
    print("   NO heal floor (11.50/12.5): when MP is gone, HPT -> 0 (the floor is a damage BOLT, not a heal).")
    ph = PHASE["mid"]
    inc_both = incoming_dpt(ph, NEU, "mail", "both", mh.G_M, nuke_power=TIER["Cura"])
    inc_phys = incoming_dpt(ph, NEU, "mail", "phys", mh.G_M)
    hp_max = ph["hp"]["neu"]
    print(f"   scenario: mid, neutral target in mail, HP {hp_max}. incoming(both)={inc_both:.1f}, incoming(phys-only)={inc_phys:.1f}")
    print("   neutral healer (Cura). 'net' = incoming - HPT (<0 => HP held during the window). T_die = turn the")
    print("   target dies. UNKILLABLE needs net<=0 AND window>=L (MP outlasts the battle).")
    print(f"   {'MP_budget':>9} {'casts':>6} {'window':>6} {'net(phys)':>9} {'net(both)':>9} {'T_die(phys)':>11} {'T_die(both)':>11} {'verdict(phys)':>21}")
    hpc = heal_amt(ph["ma"], HEAL_POWER_FIX, NEU, NEU, mh.G_M)
    for mp in (3.6, 7.2, 12.6, 27.0, 1e9):              # 2,4,7,15 Curas... and effectively infinite
        casts = mp / HEAL_POWER_FIX
        net_p = inc_phys - hpc
        net_b = inc_both - hpc
        Tb = survive_turns(hp_max, inc_both, hpc, 1, mp, HEAL_POWER_FIX)
        Tp = survive_turns(hp_max, inc_phys, hpc, 1, mp, HEAL_POWER_FIX)
        unkill = (net_p <= 0 and casts >= L_BATTLE)
        verdict = "UNKILLABLE(window>=L)" if unkill else "delayed-death (clock)"
        mpl = "inf" if mp > 1e8 else f"{mp:.1f}"
        cw = "inf" if mp > 1e8 else f"{casts:.1f}"
        print(f"   {mpl:>9} {cw:>6} {cw:>6} {net_p:>9.1f} {net_b:>9.1f} {Tp:>11} {Tb:>11} {verdict:>21}")
    print("   READ: vs incoming(BOTH) net>0 every turn (the same-tier nuker ties the heal; the phys chip is")
    print("   uncovered) -> dies ~turn 7 REGARDLESS of MP (the clock is irrelevant; the wash already lost it).")
    print("   vs PHYS-ONLY net<<0 (heal pins HP) BUT you need window>=L (15 Cura casts!) to be unkillable; any")
    print("   smaller budget = delayed-death once HPT->0. NB even 'delayed-death' rows last >=L partly on the HP")
    print("   POOL (a 9/turn chip on 150 HP lasts ~16 turns) -> survival>=L is NOT proof of out-healing. The MP")
    print("   gate + 'no heal floor' is the load-bearing brake: a battle-long heal budget is the cost of unkillable.")

    # symmetric gate + the FLOOR asymmetry (the cleanest anti-stalemate fact)
    nuke_only = nuke_amt(ph["ma"], HEAL_POWER_FIX, NEU, NEU, mh.G_M)
    print(f"   symmetric gate: vs ONE same-tier/same-Faith nuker ({nuke_only:.1f}/cast), a healer cancels it")
    print("     turn-for-turn ONLY while BOTH have MP (a wash gated by equal budgets). Post-MP the FLOOR asymmetry")
    print("     decides it: an out-of-MP NUKER drops to its always-on BOLT floor (still chips, DR-ignoring), an")
    print("     out-of-MP HEALER drops to ZERO heal (no heal floor, 11.50/12.5). So on the SAME spine healing can")
    print("     at best TIE during the MP window and STRICTLY LOSES the post-MP endgame — it cannot out-last damage.")

    # -----------------------------------------------------------------------
    print("\n" + "=" * 86)
    print("PART D — the ATHEIST-TANK PARADOX (Q3): is the most-exposed frontliner the hardest to sustain?")
    print("=" * 86)
    print("   The natural tank is LOW Faith (magic-resistant frontliner). Faith scales heal-RECEIVED but does")
    print("   NOT touch physical damage (02.9/07.6). So under PHYSICAL fire the low-Faith tank gets x0.70 heal")
    print("   with NO compensating physical resistance -> strictly worse sustain. Quantify (heal received per cast):")
    ph = PHASE["mid"]
    base_full = heal_amt(ph["ma"], HEAL_POWER_FIX, NEU, NEU, mh.G_M)
    print(f"   {'target':18} {'fmult(ft)':>9} {'heal recv':>9} {'phys taken':>10} {'sustain eff (heal/phys)':>24}")
    pp_mail = phys_dpt(ph, "plate")[0]                  # tank in plate
    for lbl, ft, ar in (("atheist tank", ATH, "plate"), ("neutral", NEU, "mail"), ("zealot mage", ZEAL, "robe")):
        hr = heal_amt(ph["ma"], HEAL_POWER_FIX, NEU, ft, mh.G_M)
        pt = phys_dpt(ph, ar)[0]
        print(f"   {lbl:18} {mh.fmult(ft):9.2f} {hr:9.1f} {pt:10.1f} {hr/pt:24.2f}")
    # the inversion, isolated on Faith alone (same armor/phys), atheist vs zealot:
    ath_eff = mh.fmult(ATH); zeal_eff = mh.fmult(ZEAL)
    print(f"   isolating Faith only: atheist heal x{ath_eff:.2f} vs zealot heal x{zeal_eff:.2f}"
          f"  -> the low-Faith tank is {ath_eff/zeal_eff:.2f}x as heal-efficient ( {100*(1-ath_eff/zeal_eff):.0f}% LESS )")
    print("   under physical fire. INVERSION CONFIRMED: the unit you most want to keep up (exposed low-Faith tank)")
    print("   is the LEAST heal-efficient. (This pushes AWAY from an unkillable-tank corner, but is a real")
    print("   feels-bad / intent-inversion cost; vs MAGIC it is the intended wash — 0.70 dmg & 0.70 heal.)")

    # -----------------------------------------------------------------------
    print("\n" + "=" * 86)
    print("PART E — DETERMINISM interaction (Q4): does previewable damage + sustain hard-lock a stalemate?")
    print("=" * 86)
    ph = PHASE["mid"]
    pol = core.p_land(ph["skill"], 8)
    inj = phys_dpt(ph, "mail")[1]
    import math
    # physical has LANDING variance (Bernoulli), magic is deterministic AND lands -> zero variance.
    p3 = pol**3
    print(f"   magic nuke: deterministic damage (P3) AND reliably lands on un-invested (p=1) -> a reactive healer")
    print(f"     computes the exact top-up; the magic duel is an EXACT tie with no variance to break it.")
    print(f"   physical: damage is deterministic too, but LANDING is a 3d6 roll (p_land~{pol:.2f}) + crit bypass.")
    print(f"     so a physical attacker CAN spike above expectation in a window: P(3 lands in a row)~{p3:.2f},")
    print(f"     a {3*inj:.0f}-burst vs an expected {3*pol*inj:.0f} over 3 turns -> a reactive heal tuned to the mean")
    print(f"     can be overrun by a landing-streak. Determinism is total on the MAGIC side, NOT on the physical side.")
    print("   BUT the fight does not RESOLVE on the damage race (00.8/philosophy): the stalemate is broken OFF the")
    print("   damage axis -> exhaust the healer's MP (clock), CC/interrupt the charged heal (13.21), flank/focus the")
    print("   fragile robe healer (glass-cannon, disruptable on 3 axes 13.8), or focus a different target. Determinism")
    print("   makes the 1:1 duel CLEANER; it hard-locks only if the healer is ALSO unkillable/un-reachable — which")
    print("   the design specifically prevents. So: no hard-lock, conditional on the healer being killable (P10).")

    # -----------------------------------------------------------------------
    print("\n" + "=" * 86)
    print("PART F — SENSITIVITY SWEEP + STALEMATE HUNT (try hard to reach the unkillable corner)")
    print("=" * 86)
    print("   sweep heal_power x G_m x MP_budget x #healers x phase x attacker-mix, on the BEST-CASE-FOR-HEAL")
    print("   target (zealot HEALER on a low-Faith tank in plate). GENUINE unkillable corner requires BOTH:")
    print("     (a) net <= 0  (HPT >= incoming: the target gains/holds HP during the window), AND")
    print("     (b) window >= L_battle  (MP outlasts the battle — the clock never bites).")
    print("   Then classify by ACTION ECONOMY: nH >= nA = WASH (committed >= neutralized); nH < nA = DEGENERATE.")
    print(f"   {'phase':5} {'mix':5} {'hpow':5} {'Gm':>3} {'MP':>6} {'nH':>2} {'nA':>2} {'net':>7} {'window':>6} {'class':>11}")
    surviveL = outheal = genuine = 0
    deg = []
    for pk in ("early", "mid", "late"):
        ph = PHASE[pk]
        for mix, n_att in (("phys", 1), ("both", 2), ("magic", 1)):
            for hpow in (TIER["Cure"], TIER["Cura"], TIER["Curaga"]):
                for gm in (2.0, 3.0, 4.0):
                    for mp in (3.6, 7.2, 14.4, 30.0, 60.0):       # +fat budgets so the corner CAN be found
                        for nH in (1, 2):
                            ft, ar = ATH, "plate"
                            inc = incoming_dpt(ph, ft, ar, mix, gm, nuke_power=HEAL_POWER_FIX)  # nuker NEUTRAL
                            hpc = heal_amt(ph["ma"], hpow, ZEAL, ft, gm)     # zealot healer, max output
                            net = inc - nH * hpc
                            window = mp / hpow
                            Ts = survive_turns(ph["hp"]["tank"], inc, hpc, nH, mp, hpow)
                            if Ts >= L_BATTLE:    surviveL += 1
                            if net <= 0:          outheal  += 1
                            if net <= 0 and window >= L_BATTLE:
                                genuine += 1
                                cls = "WASH" if nH >= n_att else "DEGENERATE"
                                if cls == "DEGENERATE":
                                    deg.append((pk, mix, hpow, gm, mp, nH, n_att, net, window))
    for (pk, mix, hpow, gm, mp, nH, nA, net, window) in deg[:20]:
        print(f"   {pk:5} {mix:5} {hpow:5.1f} {gm:>3.0f} {mp:>6.1f} {nH:>2} {nA:>2} {net:>7.1f} {window:>6.1f} {'DEGENERATE':>11}")
    print(f"\n   sweep cells: {3*3*3*3*5*2} | survive>=L (noisy): {surviveL} | genuine out-heal (net<=0): {outheal}"
          f" | GENUINE unkillable (net<=0 AND window>=L): {genuine} | of those DEGENERATE (nH<nA): {len(deg)}")
    if deg:
        mps = sorted(set(r[4] for r in deg)); mixes = sorted(set(r[1] for r in deg))
        print(f"   The DEGENERATE corner needs mix in {mixes} and a FAT MP budget in {mps} (>= a full battle of casts).")
        print("   MECHANISM: the healer is a ZEALOT (x1.30 output) but the nuker is NEUTRAL (x1.0) at the SAME tier,")
        print("   so the medic OUT-FAITHS the nuke by ~30% and that surplus covers the small phys chip. CONTROL —")
        print("   Faith-MATCH the nuker to the healer (zealot nuker) and recompute net:")
        seen = set()
        for (pk, mix, hpow, gm, mp, nH, nA, net, window) in deg:
            key = (pk, mix, hpow, gm)
            if key in seen: continue
            seen.add(key)
            ph = PHASE[pk]; ft, ar = ATH, "plate"
            inc_m = phys_dpt(ph, ar)[0] + nuke_amt(ph["ma"], hpow, ZEAL, ft, gm)   # nuker now MATCHED (zealot)
            net_m = inc_m - nH * heal_amt(ph["ma"], hpow, ZEAL, ft, gm)
            print(f"     {pk}/{mix}/hpow{hpow}/Gm{gm:.0f}: matched net = {net_m:+.1f} "
                  f"({'COLLAPSES (net>0, wash restored)' if net_m > 0 else 'still net<=0'})")
        print("   => the only DEGENERATE corner is a Faith-MISMATCH (zealot medic vs non-zealot nuker) + a budget")
        print("   that outlasts the battle. Match the nuker's Faith and net -> the bare phys chip (>0): it collapses.")
    else:
        print("   NO genuine degenerate (net<=0 AND window>=L AND nH<nA) corner in the grid.")

    # -----------------------------------------------------------------------
    print("\n" + "=" * 86)
    print("VERDICT (computed)")
    print("=" * 86)
    print("  - SPINE WASH: same-tier heal == same-tile nuke per cast (true), but it is a 1:1 trade; vs a mixed")
    print("    attack the magic halves CANCEL and the physical chip is uncovered -> NET damage > 0, no default stalemate.")
    print("  - MP GATE: finite budget + NO heal floor => sustained out-healing is DELAYED-loss, never infinite;")
    print("    a stalemate needs the MP window to outlast the battle (a single budget number, OQ-21).")
    print("  - ATHEIST PARADOX: confirmed real under physical fire (low-Faith tank ~46% less heal-efficient than a")
    print("    zealot) — inverts intent but pushes AWAY from unkillable-tank.")
    print("  - DETERMINISM: total on the magic side (exact tie), NOT on the physical (landing variance); resolves")
    print("    off the damage axis (MP clock / CC / rush the fragile healer) => no hard-lock if the healer is killable.")
    print("  - GENUINE unkillable corner (27/810 cells) needs a Faith-MISMATCH (zealot medic out-Faithing a")
    print("    non-zealot nuker, +30%) AND a battle-long MP budget (window>=L). Faith-match the nuker -> net = the")
    print("    bare phys chip (>0) and it COLLAPSES; or cap the budget below a battle of casts and the clock bites.")

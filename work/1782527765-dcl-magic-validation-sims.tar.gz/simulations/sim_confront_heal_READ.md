# sim_confront_heal — read (MR-5: does HEALING trivialize damage → stalemate / unkillable?)

**Question.** Heal and damage share the magic spine (`heal = base(MA)×heal_power×faith_c×faith_t×G_m`,
the damage spine **minus** the resist term, register 11.28 / 12.5). So heal-per-cast == nuke-per-cast by
construction — "heal/turn ≈ damage/turn by default." Does that hard-lock fights into a stalemate or an
unkillable team? Falsification run: try hard to reach the corner; report both ways.

**Setup.** Reuses `sim_magic_heal.heal/dmg/fmult/SP` and `sim_core.injury/p_land` unchanged (a self-check
asserts the numeric-power wrappers reproduce the modules on the named tiers). **heal_power FIXED** to the
labeled tier `SP["Cura"]=1.8` (the standard sustain heal; "strong" = `Curaga 3.0`). **Axes crossed:**
phase(early/mid/late) × target-Faith(atheist/neutral/zealot) × armor(robe/mail/plate) ×
attacker-mix(phys / magic / both) × heal_power{1.0,1.8,3.0} × G_m{2,3,4} × MP-budget × #healers{1,2}.
**Axes skipped (named):** Speed/CT turn-cadence (assumed 1:1 — a faster healer widens the window); per-cast
charge time (folded into MP-as-burst); AoE heal vs AoE nuke; Magic-Evade on the target (un-invested ⇒
magic lands p=1); charged-heal interrupt (noted, not modelled); full 4v4 board AI; undead-invert.

## MR-5.1 — heal/turn vs damage/turn; the break-even → **a 1:1 WASH, not a stalemate**

Per-cast, `heal == nuke` exactly at equal tier/Faith/MA/G_m (`heal/nuke = 1.00` at every phase). But the
target's Faith `ft` scales **both** the nuke it takes and the heal it receives, so `ft` **cancels**:

> `incoming(both) − heal = phys_dpt + base·G·ft·( tier_d·fmult(fc) − tier_h·fmult(fh) )`

At equal tier and equal caster-Faith the magic halves cancel and **net = phys_dpt > 0**. A same-tier nuker
*exactly ties* a same-tier healer; the physical fighter is **uncovered** damage. Confirmed numerically — vs
a mixed attack (1 fighter + 1 same-tier nuker), a single **Cura** healer falls behind by exactly the phys
chip (86.4 heal vs 95.5 incoming); only by **out-tiering** (Curaga 144 > 95.5) does one healer pull ahead.

The scary-looking number is `r = heal/turn ÷ phys_dpt` ≈ **6–35** (one healer out-paces *many* fighters
per turn, worse vs heavy armor because physical collapses on DR while heal is flat). But `r` is a
**cross-spine magnitude** (magic `G_m=3` vs physical `G=1`, set independently per sim) — calibration, not
a law — and it is the **per-cast burst**, gated by MP and reconciled over a battle by the design's own
anchor (11.49: mage battle-total ≈ fighter battle-total). Two healers vs one attacker trivially out-paces,
but commits 2 units to neutralize 1 — a **board-losing** trade, not degeneracy.

## MR-5.2 — the MP gate → **DELAYS, never prevents; the floor asymmetry is the real brake**

Total battle healing = `MP_budget(points) × base(MA) × G_m × faith` (split-independent). With **no heal
floor** (11.50/12.5: out of MP, the floor is a damage *bolt*, not a heal), HPT → 0 when the budget is gone.
- vs **mixed** incoming: net > 0 every turn (nuke ties heal, phys chip uncovered) → target dies ~turn 7
  **regardless of MP** — the wash already lost it; the clock is irrelevant.
- vs **phys-only**: heal pins HP during the window, but you need **window ≥ L_battle (≈15 Cura casts!)**
  to be unkillable; any smaller budget = delayed-death once HPT→0.
- **Symmetric-gate + floor asymmetry (cleanest fact):** heal and nuke share spine *and* MP gate, so a
  healer can at best **tie** a same-tier/same-Faith nuker during the window — then the out-of-MP nuker
  keeps chipping at its bolt floor while the out-of-MP healer drops to **zero**. On one spine, **healing
  cannot out-last damage**: it ties during MP and strictly loses the endgame.

Caveat surfaced: "survives ≥ L" is **not** proof of out-healing — a 9/turn chip on a 150-HP pool lasts ~16
turns on the HP pool alone. The sim separates genuine out-heal (`net ≤ 0`) from HP-pool tankiness.

## MR-5.3 — atheist-tank paradox → **CONFIRMED, real inversion (but it helps, not hurts, the stalemate)**

The natural tank is **low-Faith** (the magic-resistant frontliner). Faith scales heal-received but does
**not** touch physical damage (02.9 / 07.6). So under **physical fire** the atheist tank is healed ×0.70
with **no** compensating physical resistance:

| target | fmult | heal recv | phys taken | sustain eff (heal/phys) |
|---|---:|---:|---:|---:|
| atheist tank | 0.70 | 60.5 | 5.8 | 10.4 |
| zealot mage | 1.30 | 112.3 | 13.3 | 8.5 |

Isolating Faith, the atheist is **0.54×** as heal-efficient as a zealot (**46% less**) under physical
attack — the unit you most want to keep up is the least sustainable by pure healing. Inversion of intent
**confirmed**; it is a feels-bad cost, but it pushes *away* from an unkillable-tank corner (the exposed
tank survives by DR + HP, not by being topped to full). Vs *magic* it is the intended wash (0.70 dmg & 0.70 heal).

## MR-5.4 — determinism → **total on the magic side, not the physical; no hard-lock**

Magic damage is deterministic (P3) **and** reliably lands on the un-invested (p=1) → a reactive healer
computes the exact top-up; the magic duel is an exact tie with no variance to break. Physical damage is
deterministic too, but **landing** is a 3d6 roll (+ crit bypass): P(3 lands in a row) ≈ 0.17, so a phys
attacker can transiently spike a ~50-burst over an expected ~27 — a heal tuned to the mean can be overrun
by a landing streak. **But** the fight does not resolve on the damage race (00.8): the 1:1 is broken **off**
the damage axis — exhaust MP (clock), interrupt the charged heal (13.21), flank/rush the fragile robe
healer (glass-cannon, disruptable on 3 axes, 13.8), or focus elsewhere. Determinism makes the duel
*cleaner*; it hard-locks **only** if the healer is also unkillable/unreachable — which the design prevents.

## Sensitivity sweep + stalemate hunt (810 cells, best-case-for-heal: zealot medic on a plate tank)

- **survive ≥ L (noisy): 452** · **genuine out-heal (net ≤ 0): 720** · **GENUINE unkillable (net ≤ 0 AND
  window ≥ L): 234** · **of those DEGENERATE (1 healer out-values ≥ 2 attackers): 27.**
- The 27 degenerate cells **all** require **mix = both**, a **fat MP budget (30–60 pts ≥ a full battle of
  casts)**, AND a **Faith mismatch** (zealot medic out-Faithing a *neutral* same-tier nuker by +30%, whose
  surplus covers the phys chip). **Control:** Faith-match the nuker (zealot nuker) → net = the bare phys
  chip (**+1.5 early … +8.4 late, always > 0**) → **every degenerate cell collapses to a wash.**
- Across G_m{2,3,4} the corner's *existence* is unchanged (it scales the margin, not the conclusion); the
  corner is gated by **budget** and **Faith-mismatch**, not by G_m.

## Verdict: **HOLDS — conditional on two calibrations (MP budget + Faith symmetry), with one real cost.**

The shared spine does **not** auto-stalemate. Same-tier heal vs same-tier nuke is a **1:1 wash**, and
against any mixed attack the magic halves cancel so the **physical chip is uncovered → net damage > 0**.
The **MP gate + "no heal floor"** make sustained out-healing a *delayed-loss*, never infinite — on one
spine healing **ties during MP and loses after** (the floor asymmetry: bolt vs zero). The only genuine
unkillable corner found is narrow and removable: a **zealot medic out-Faithing a non-zealot nuker** plus a
**battle-long MP budget** — and it collapses the moment the nuke's Faith matches or the budget is capped
below a battle of casts. The **atheist-tank paradox is real** (low-Faith frontliner ~46% less
heal-efficient under physical fire) — log it as an intent-inversion / feels-bad to watch, though it cuts
*against* unkillability.

**Conditions to bank (calibration, OQ-21 / OQ-17):** (1) MP budget for strong heals must be **< a full
battle of casts** (window < L) — this is the single load-bearing number; (2) keep heal and nuke on the
**same Faith band** so a medic can't structurally out-Faith a nuker; (3) preserve **no heal floor** (depleted
healer → bolt, not heal); (4) keep the healer **killable/reachable** (robe fragility + interrupt) so
determinism can't hard-lock.

## What would flip this (one line)

Give strong heals an MP budget that **outlasts the battle** (window ≥ L) — or a heal-only band/`G_m` that
lets a medic **out-Faith or out-scale** a same-tier nuker — and the wash tips into a genuine unkillable
corner (the floor asymmetry and the phys chip stop saving it).

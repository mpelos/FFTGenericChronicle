#!/usr/bin/env python3
"""
sim_confront_oneshot.py — MR-4 falsification: try to REACH a degenerate magic corner.

DECISION UNDER TEST (M4 / OQ-23): the multiplicative magic stack stays BOUNDED — no one-shot
offense corner, no immune defense corner. The design's claim: "one big multiplier (Faith),
modest bands elsewhere, a soft cap held in reserve." This sim does NOT try to confirm that; it
tries to BREAK it, both ways, and reports honestly which way it lands.

The stack (11.7 / 12.1):
    dmg = base(MA) × spell_power × faith_caster × faith_target × element_mult × G_m
          \___________________  the "spine"  ____________________/   ×  element band
Faith enters TWICE (caster output × target vulnerability), each a bounded band centered at 1.0.
element_mult = Zodiac(weak/neutral/resist) × Shell, modest bounded bands.

THE PIVOT — note 11.26 / OQ-13: the reserve soft-cap's DOMAIN is ambiguous. Two readings:
    (a) cap applies to element_mult ONLY        -> the faith² spine multiplies UNCAPPED on top
    (b) cap applies to the WHOLE product         -> faith_c × faith_t × element is bounded together
Both give the SAME everyday corner (cap dormant); they diverge exactly at the degenerate corner
(×2-weak element / widened Faith band). This sim makes that divergence the headline.

Two corners hunted:
  MR-4.1 OFFENSE one-shot: devout caster (high Faith) × vulnerable target (high Faith + weak/×2
         element + no Shell). Does corner × baseline reach >= target max HP? Test BOTH cap domains.
  MR-4.2 DEFENSE immune:   low-Faith target × Zodiac-resist × Shell (~0.24×, finite) THEN a binary
         Magic-Evade (capped <100%) composed on top. Does evade×0.24× become de-facto immunity?

Absolute magnitudes (base(MA) curve OQ-22, G_m OQ-17) are OPEN, so the absolute one-shot is
DECOUPLED from any single guessed number: it is reported as a function of one calibration knob,
B = "a neutral top-tier nuke as a fraction of the squishiest target's max HP," swept over a
defensible burst-nuke range. The STRUCTURAL result (corner multiplier × cap-domain) is the spine;
the absolute result is "given B, does the corner cross 100%." A grounded G_m∈{2,3,4} pass with
explicit HP pools cross-checks the magnitude regime.

Run:  python3 sim_confront_oneshot.py
"""

# ============================================================================
# CONFIG — every magic number declared, with its open-question tag; swept below.
# ============================================================================
F_MIN, F_MID, F_MAX = 25, 55, 85      # buildable faith band endpoints (atheist/neutral/zealot)
FAITH_FLOOR = 0.60                     # 08.4 / OQ-24: effective faith multiplier floored at 0.60

# Faith band candidates (11.19/11.22/OQ-11): provisional + two reserves.
FAITH_BANDS = {
    "[0.80,1.20] narrow": (0.80, 1.20),
    "[0.70,1.30] provis": (0.70, 1.30),
    "[0.65,1.30] widelow": (0.65, 1.30),
}

# Zodiac + Shell (09.3 / 11.11 / 11.23 / 11.24).
Z_EVERYDAY_WEAK = 1.30                 # modest everyday weak band
Z_RESIST        = 0.70
Z_X2_WEAK       = 2.00                 # the RARE designed exception (09.5)
SHELL           = 0.50

# spell tiers (11.9; summon per-unit tier per 11.6 — "a summon is a large elemental AoE").
SPELL = {"Fire": 1.0, "Fira": 1.8, "Firaga": 3.0, "Summon": 4.5}

# Soft cap (11.26 / OQ-13): value swept {2.0,2.5,3.0}; DOMAIN swept {element, whole}.
CAP_VALUES  = (2.0, 2.5, 3.0)
CAP_DOMAINS = ("element", "whole")

# G_m (OQ-17): register says ~3 calibrated; 8 "one-shots everyone". Swept {2,3,4}.
G_M_SWEEP = (2.0, 3.0, 4.0)

# Magic Evade (11.34/11.35/11.38/OQ-15): binary, no universal floor, capped <100%. Values open.
EVADE_SWEEP = (0.0, 0.50, 0.75, 0.90, 0.95)


# ============================================================================
# Model
# ============================================================================
def faith_mult(F, bl, bh, clamp_band=True):
    """Bounded band, ==1.0 at F_MID; bl at F_MIN, bh at F_MAX. Clamped to band by default
    (the design intent). clamp_band=False = linear extrapolation past faith 85 (an
    implementation risk: FFT faith reaches ~95)."""
    if F >= F_MID:
        v = 1.0 + (F - F_MID) / (F_MAX - F_MID) * (bh - 1.0)
    else:
        v = 1.0 + (F - F_MID) / (F_MID - F_MIN) * (1.0 - bl)
    if clamp_band:
        v = min(bh, max(bl, v))
    return max(FAITH_FLOOR, v)


def element_mult(zod, shell_on, zweak=Z_EVERYDAY_WEAK, zres=Z_RESIST, shell=SHELL):
    e = {"weak": zweak, "neutral": 1.0, "resist": zres}[zod]
    if shell_on:
        e *= shell
    return e


def corner_mult(fc, ft, zod="neutral", shell_on=False, cap=None, cap_domain="whole",
                bl=0.70, bh=1.30, zweak=Z_EVERYDAY_WEAK, zres=Z_RESIST, shell=SHELL,
                faith_clamp=True):
    """Relative multiplier over a neutral exchange (fc=ft=55, neutral element, no shell -> 1.0)."""
    fcm = faith_mult(fc, bl, bh, faith_clamp)
    ftm = faith_mult(ft, bl, bh, faith_clamp)
    elem = element_mult(zod, shell_on, zweak, zres, shell)
    if cap is not None and cap_domain == "element":
        elem = min(elem, cap)                 # (a) cap watches element ONLY
    prod = fcm * ftm * elem
    if cap is not None and cap_domain == "whole":
        prod = min(prod, cap)                 # (b) cap watches the whole product
    return prod, fcm, ftm, elem


# ============================================================================
if __name__ == "__main__":
    print("=" * 92)
    print("MR-4.1 OFFENSE — relative corner multiplier (over neutral), and how the CAP DOMAIN bites")
    print("=" * 92)
    print("  Faith provisional [0.70,1.30]. faith_c×faith_t max = 1.30×1.30 = 1.69 (the 'faith² spine').")
    print("  element everyday weak = 1.30 ; element ×2-exception = 2.00 ; (resist 0.70 / shell 0.50).\n")
    bl, bh = FAITH_BANDS["[0.70,1.30] provis"]
    scenarios = [
        ("neutral exchange (ref)",          55, 55, "neutral", False),
        ("EVERYDAY  zealot→zealot, weak",   85, 85, "weak",    False),
        ("EVERYDAY  zealot→fighter, weak",  85, 55, "weak",    False),
        ("EXCEPTION zealot→zealot, ×2 weak",85, 85, "weak",    False),  # zweak overridden below
        ("EXCEPTION zealot→fighter, ×2 weak",85,55, "weak",    False),
    ]
    print(f"  {'scenario':>34} | {'NO cap':>7} | {'cap=2.5 ELEMENT':>15} | {'cap=2.5 WHOLE':>14}")
    print("  " + "-" * 84)
    for lbl, fc, ft, zod, sh in scenarios:
        zw = Z_X2_WEAK if "×2" in lbl else Z_EVERYDAY_WEAK
        raw, *_ = corner_mult(fc, ft, zod, sh, cap=None,  bl=bl, bh=bh, zweak=zw)
        ce,  *_ = corner_mult(fc, ft, zod, sh, cap=2.5, cap_domain="element", bl=bl, bh=bh, zweak=zw)
        cw,  *_ = corner_mult(fc, ft, zod, sh, cap=2.5, cap_domain="whole",   bl=bl, bh=bh, zweak=zw)
        print(f"  {lbl:>34} | {raw:>6.2f}x | {ce:>14.2f}x | {cw:>13.2f}x")
    print("\n  READ: everyday weak corner = 1.69×1.30 = 2.20× — UNDER 2.5, cap dormant in BOTH domains.")
    print("  The ×2-exception corner = 1.69×2.00 = 3.38×. Cap=2.5 on the WHOLE product cuts it to 2.50×;")
    print("  cap=2.5 on ELEMENT ONLY leaves it at 3.38× (element 2.00<2.5 so the cap never fires, and the")
    print("  faith² 1.69 multiplies UNCAPPED on top). The cap-domain is load-bearing exactly here.")

    print("\n" + "=" * 92)
    print("MR-4.1b  the faith² spine UNCAPPED under domain (a): cap value × element-tier grid")
    print("=" * 92)
    print("  Question from the task: under (a) cap-on-element-only, does MA×spell×faith²×G_m reach a")
    print("  one-shot? Here is the corner the cap actually PERMITS, per cap value × domain.\n")
    print(f"  {'element tier':>20} | " + " | ".join(f"cap{c}=({d[:4]})" for c in CAP_VALUES for d in CAP_DOMAINS))
    print("  " + "-" * 86)
    for zod_lbl, zw in [("everyday weak 1.30", Z_EVERYDAY_WEAK), ("×2 weak (excpt) 2.00", Z_X2_WEAK)]:
        cells = []
        for c in CAP_VALUES:
            for d in CAP_DOMAINS:
                v, *_ = corner_mult(85, 85, "weak", False, cap=c, cap_domain=d, bl=bl, bh=bh, zweak=zw)
                cells.append(f"{v:>10.2f}x")
        print(f"  {zod_lbl:>20} | " + " | ".join(cells))
    print("\n  READ: every 'element'-domain cell with element<cap is IDENTICAL to no-cap — the cap is inert")
    print("  on element while faith² runs free. Only the 'whole'-domain cells actually clamp the corner.")
    print("  => Under reading (a) the soft-cap CANNOT bound the faith²-driven corner. It watches the wrong term.")

    print("\n" + "=" * 92)
    print("MR-4.1c  ABSOLUTE one-shot — decoupled from base(MA)/G_m via B = neutral nuke as % of HP")
    print("=" * 92)
    print("  base(MA) curve (OQ-22) and G_m (OQ-17) are OPEN, so absolute dmg = corner × (neutral nuke).")
    print("  Let B = neutral top-tier nuke as a fraction of the SQUISHIEST target's max HP. One-shot iff")
    print("  corner × B >= 1.0. We sweep B over a 'burst nuke' range and read the threshold corner.\n")
    corners_named = [
        ("everyday weak  (2.20×)", corner_mult(85, 85, "weak", False, bl=bl, bh=bh)[0]),
        ("×2 excpt, WHOLE-cap 2.5", corner_mult(85, 85, "weak", False, cap=2.5, cap_domain="whole",  bl=bl, bh=bh, zweak=Z_X2_WEAK)[0]),
        ("×2 excpt, ELEMENT-cap 2.5", corner_mult(85, 85, "weak", False, cap=2.5, cap_domain="element", bl=bl, bh=bh, zweak=Z_X2_WEAK)[0]),
        ("×2 excpt, NO cap (3.38×)", corner_mult(85, 85, "weak", False, bl=bl, bh=bh, zweak=Z_X2_WEAK)[0]),
    ]
    Bs = (0.30, 0.35, 0.40, 0.45, 0.50, 0.60)
    print(f"  {'corner':>26} | " + " ".join(f"B={int(100*b)}%" for b in Bs))
    print("  " + "-" * 70)
    for lbl, cm in corners_named:
        row = []
        for b in Bs:
            pct = cm * b
            row.append(f"{'1SHOT' if pct >= 1.0 else f'{int(100*pct)}%':>6}")
        print(f"  {lbl:>26} | " + " ".join(row))
    print("\n  READ: a top-tier nuke that does B of a squishy target's HP at neutral one-shots that target")
    print("  once corner×B>=1. Everyday 2.20× one-shots at B>=46%. The ×2 ELEMENT-cap (=NO-cap, 3.38×)")
    print("  one-shots at B>=30%. WHOLE-cap 2.5× needs B>=40%. The cap DOMAIN moves the one-shot threshold.")

    print("\n" + "=" * 92)
    print("MR-4.1d  WHO gets one-shot — mage-on-mage vs mage-on-fighter (the 'unpaid' one-shot)")
    print("=" * 92)
    print("  The offense corner needs a HIGH-Faith target (vulnerable). A high-Faith target IS a glass-")
    print("  cannon mage — one-shotting it may be intended. The DEGENERATE case is one-shotting a unit")
    print("  that did NOT buy the vulnerability: a fighter (neutral Faith) caught on his weak element.\n")
    B_REF = 0.45   # neutral top nuke ≈ 45% of the squishiest robe HP (a 'two-cast kill' baseline)
    print(f"  (using B={int(100*B_REF)}% of robe HP for a neutral nuke; fighter HP ≈ 1.5× robe HP)\n")
    targets = [("devout MAGE  (robe, faith 85)", 85, 1.0),
               ("neutral FIGHTER (leather, faith 55)", 55, 1.5)]
    for tlbl, ft, hp_mult in targets:
        print(f"  vs {tlbl}:")
        for zlbl, zod, zw in [("everyday weak 1.30", "weak", Z_EVERYDAY_WEAK),
                              ("×2 weak (exception)", "weak", Z_X2_WEAK)]:
            for dom in ("whole", "element"):
                cm, *_ = corner_mult(85, ft, zod, False, cap=2.5, cap_domain=dom, bl=bl, bh=bh, zweak=zw)
                pct = cm * B_REF / hp_mult
                flag = "  <<< ONE-SHOT" if pct >= 1.0 else ""
                print(f"      {zlbl:>20} cap2.5/{dom:>7}: corner {cm:>4.2f}x -> {int(100*pct):>3}% HP{flag}")
        print()
    print("  READ: the everyday band one-shots only the devout mage (intended glass-cannon). One-shotting")
    print("  the FIGHTER needs the ×2 element exception AND the ELEMENT-cap reading; under the WHOLE-cap")
    print("  reading the same build lands a big hit but not a clean one-shot of the healthy fighter.")

    print("\n" + "=" * 92)
    print("MR-4.1e  GROUNDED magnitude cross-check — explicit HP pools, base(MA)=MA, G_m∈{2,3,4}")
    print("=" * 92)
    print("  Simplest reading base(MA)=MA. Reports neutral Firaga and the 2.20× everyday corner as %HP.")
    print("  (Armor is DR-primary/HP-modest [14.10], so robe/leather/plate HP differ modestly.)\n")
    phases = [("early", 8,  {"robe": 90,  "leather": 110, "plate": 140}),
              ("mid",   16, {"robe": 110, "leather": 150, "plate": 200}),
              ("late",  26, {"robe": 170, "leather": 230, "plate": 300})]
    everyday = corner_mult(85, 85, "weak", False, bl=bl, bh=bh)[0]
    for gm in G_M_SWEEP:
        print(f"  --- G_m = {gm} ---")
        for plbl, ma, hp in phases:
            neutral = ma * SPELL["Firaga"] * 1.0 * gm
            corner  = neutral * everyday
            cell = " ".join(f"{k}:{int(100*neutral/v)}%/{int(100*corner/v)}%" for k, v in hp.items())
            print(f"    {plbl:>5} MA{ma:<2} Firaga={neutral:>5.0f} (neut%/corner% HP)  {cell}")
    print("\n  READ: with base(MA)=MA the simplest reading is HOT — at G_m≥3 a NEUTRAL Firaga already")
    print("  ~one-shots the robe mage, so the 2.20× corner is pure overkill. Safety lives ENTIRELY in")
    print("  choosing base(MA)/G_m to seat the neutral nuke well below 100% (push toward G_m=2 or a")
    print("  sub-linear base(MA)). OQ-23 is literal: there is no structural damper — only calibration.")

    print("\n" + "=" * 92)
    print("MR-4.1f  AoE-per-unit — a SUMMON (spell_power 4.5 vs Firaga 3.0 = ×1.5) hits a CLUSTER")
    print("=" * 92)
    print("  Per-unit a summon is the same spine at a higher tier (11.6). Per-unit one-shot threshold drops")
    print("  by Firaga/Summon = 3.0/4.5 = 0.67×. Using B(Firaga)=45% of robe HP -> B(Summon)=67.5%.\n")
    B_sum = B_REF * SPELL["Summon"] / SPELL["Firaga"]
    print(f"  {'per-unit target':>34} | {'neutral':>8} | {'everyday 2.20×':>14} | {'×2-excpt el-cap 3.38×':>21}")
    print("  " + "-" * 86)
    for tlbl, ft, hp_mult in [("devout MAGE in blast (robe)", 85, 1.0),
                              ("neutral FIGHTER in blast (leather)", 55, 1.5)]:
        neu = B_sum / hp_mult
        ev  = corner_mult(85, ft, "weak", False, bl=bl, bh=bh)[0] * B_sum / hp_mult
        x2  = corner_mult(85, ft, "weak", False, cap=2.5, cap_domain="element", bl=bl, bh=bh, zweak=Z_X2_WEAK)[0] * B_sum / hp_mult
        f = lambda x: "1SHOT" if x >= 1.0 else f"{int(100*x)}%"
        print(f"  {tlbl:>34} | {f(neu):>8} | {f(ev):>14} | {f(x2):>21}")
    print("\n  READ: a summon's higher per-unit tier means the AoE one-shots EVERY high-Faith unit in the")
    print("  blast at the everyday band, and one-shots fighters too under the ×2/element-cap reading — a")
    print("  multi-kill, not a single one-shot. The per-unit corner is the single-target corner × 1.5; the")
    print("  AoE multiplies the STAKES of the one-shot finding, it does not change its structure.")

    print("\n" + "=" * 92)
    print("MR-4.2  DEFENSE — the multiplicative turtle (finite) THEN binary Magic-Evade composed on top")
    print("=" * 92)
    print("  Multiplicative floor (defender controls faith_target, zodiac-resist, Shell):")
    for blab, (b_lo, b_hi) in FAITH_BANDS.items():
        ft = faith_mult(F_MIN, b_lo, b_hi)
        floor = ft * Z_RESIST * SHELL
        # extreme: if the attacker is ALSO low-faith (a bad mage) -> faith applies the resist twice
        floor_both = faith_mult(F_MIN, b_lo, b_hi) * ft * Z_RESIST * SHELL
        print(f"    band {blab:>16}: faith_t {ft:.2f} × zres 0.70 × shell 0.50 = {floor:.3f}×"
              f"   (atheist-caster extreme: {floor_both:.3f}×)")
    print("\n  -> ~0.21–0.25× : a HARD turtle, but FINITE (multiplicative resist never zeroes). The")
    print("     philosophy's 'never immunity' holds for the MULTIPLICATIVE stack alone. Now compose evade:\n")
    floor = faith_mult(F_MIN, 0.70, 1.30) * Z_RESIST * SHELL    # 0.245 with provisional band
    print(f"  resist floor = {floor:.3f}×. Magic-Evade is BINARY (evade=take nothing), capped <100%.")
    print(f"  Expected magic throughput = (1 − p_evade) × {floor:.3f}×. Casts-to-kill (expectation) at")
    print(f"  B={int(100*B_REF)}% (a landed neutral nuke = {int(100*B_REF)}% of this turtle's HP):\n")
    print(f"  {'p_evade':>8} | {'eff. mult':>10} | {'landed corner-nuke %HP':>22} | {'casts-to-kill (exp)':>20}")
    print("  " + "-" * 70)
    for p in EVADE_SWEEP:
        eff = (1 - p) * floor
        # a committed attacker still picks a zealot caster + switches element off resist: corner ~ best case
        landed_each = floor * B_REF          # one landed cast, full turtle mitigation, neutral caster
        exp_per_cast = eff * B_REF
        ctk = (1.0 / exp_per_cast) if exp_per_cast > 0 else float("inf")
        print(f"  {p:>7.0%} | {eff:>9.3f}× | {100*landed_each:>20.1f}% | {ctk:>20.1f}")
    print("\n  READ: the multiplicative turtle alone (~0.245×) takes ~11% HP per LANDED nuke at B=45% —")
    print("  finite, killable in ~9 landed casts. But binary evade multiplies EXPECTED throughput by")
    print("  (1−p): at 90% evade it takes ~90 casts-in-expectation, at 95% ~180. A caster's whole-fight")
    print("  budget is a handful of bursts (MP + charge) — so 'capped <100%' evade composed on the 0.24×")
    print("  floor is DE-FACTO MAGIC IMMUNITY. The guardrail caps the evade TERM, never evade×resist.")

    print("\n" + "=" * 92)
    print("MR-4.2b  with the multiplicative OUTS applied — is evade still the breach? (composition guardrail)")
    print("=" * 92)
    print("  Be MAXIMALLY fair to the attacker: apply the philosophy's outs (11.27). Switch OFF the resisted")
    print("  element (zodiac 0.70→1.0) and wait Shell out (0.50→1.0) → multiplicative mitigation collapses")
    print("  to faith_target ALONE = 0.70 (atheist). The turtle's MULTIPLICATIVE wall has counterplay. But")
    print("  Magic-Evade has NO out: binary, off-Speed (11.37), facing-independent (11.52), not depletable")
    print("  by focus-fire. Casts-to-kill at the POST-OUTS floor 0.70, B={}%:\n".format(int(100 * B_REF)))
    outs_floor = faith_mult(F_MIN, 0.70, 1.30)   # 0.70 — only target-faith remains after the outs
    print(f"  {'p_evade':>8} | {'eff. mult':>10} | {'landed %HP':>11} | {'casts-to-kill (exp)':>20} | within ~6-cast budget?")
    print("  " + "-" * 82)
    for p in EVADE_SWEEP:
        eff = (1 - p) * outs_floor
        exp_per_cast = eff * B_REF
        ctk = (1.0 / exp_per_cast) if exp_per_cast > 0 else float("inf")
        ok = "YES (finite/fair)" if ctk <= 6 else "NO — de-facto immune"
        print(f"  {p:>7.0%} | {eff:>9.3f}× | {100*outs_floor*B_REF:>10.1f}% | {ctk:>20.1f} | {ok}")
    # solve the evade cap that keeps a 6-cast kill at the post-outs floor: (1-cap)*0.70*B*6 >= 1
    cap_needed = max(0.0, 1 - 1.0 / (6 * outs_floor * B_REF))
    print(f"\n  Solve (1−cap)×0.70×{B_REF}×6 ≥ 1  ->  evade cap must be ≤ {cap_needed:.0%} to keep the")
    print("  outs-applied turtle killable inside a ~6-cast burst budget.")
    print("\n  READ: even after the attacker spends its outs (dropping the wall to a mere 0.70× faith resist),")
    print("  a Magic-Evade above ~45–50% still pushes casts-to-kill past a whole fight's burst budget. So a")
    print("  'feels-safe' evade cap of 80% is ALREADY de-facto magic immunity. The multiplicative turtle has")
    print("  counterplay; the BINARY EVADE composed on top does not — and 'capped <100%' is far too loose.")

    print("\n" + "=" * 92)
    print("AXES — crossed vs skipped")
    print("=" * 92)
    print("  CROSSED: G_m{2,3,4}; cap value{2.0,2.5,3.0}; cap DOMAIN{element,whole}; Faith band")
    print("    {[.80,1.20],[.70,1.30],[.65,1.30]}+floor0.60; element{everyday1.30, ×2-excpt2.00, resist0.70};")
    print("    Shell{on,off}; spell{Fire,Fira,Firaga,Summon4.5}; neutral-nuke %HP B-sweep; Magic-Evade")
    print("    p{0,.5,.75,.9,.95}; target archetype{mage robe, fighter leather}; phase{early,mid,late}.")
    print("  SKIPPED (flagged): base(MA) exact curve (OQ-22 — decoupled via B-sweep, slope-1 in the grounded")
    print("    pass only); Rod magic-power-mod 'scaled by Faith' (14.3) as a possible THIRD Faith application")
    print("    — would WIDEN the corner, not modeled; faith>85 unclamped extrapolation (modeled clamped,")
    print("    flagged); MP-budget/charge throttle on casts-per-fight (the real-world brake on the evade-")
    print("    immunity corner — out of damage-stack scope); absorb (×−1 heal-the-target) sign-flip; status")
    print("    axis; AI-usability of the dedicated magic-resist slot (philosophy R-A risk).")

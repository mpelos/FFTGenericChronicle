# sim_confront_oneshot — read (MR-4: try to reach a degenerate magic corner)

**Question.** M4 / OQ-23 claim the multiplicative magic stack stays **bounded** — no one-shot offense
corner, no immune defense corner — held by "one big multiplier (Faith), modest bands elsewhere, a soft
cap in reserve." This sim does not confirm that; it tries to **break** it both ways. The pivot is note
**11.26 / OQ-13**: the reserve soft-cap's DOMAIN is *unspecified* — does it cap `element_mult` only, or
the whole `faith_c × faith_t × element` product?

The stack: `dmg = base(MA) × spell_power × faith_caster × faith_target × element_mult × G_m`, Faith twice
(band [0.70,1.30] → faith² ≤ 1.69), `element_mult = Zodiac × Shell`.

---

## MR-4.1 OFFENSE — the everyday band holds; the cap DOMAIN is the break vector

**Everyday band: BOUNDED (holds).** Worst realistic corner (zealot→zealot, weak ×1.30, no Shell) =
1.69 × 1.30 = **2.20×** over neutral — under the ~2.5× cap, so the cap is **dormant in BOTH domains**.
The design's headline claim survives untouched here. Against a *fighter* (neutral Faith) the everyday
corner is only 1.69× — a heavy hit, not a one-shot.

**Reserve/exception invoked → the cap domain decides, and one reading reproduces a one-shot.**
Bring the rare ×2-weak element (09.5/11.24) or a widened Faith band, and the two readings split:

| corner | NO cap | cap 2.5 **element-only** (a) | cap 2.5 **whole-product** (b) |
|---|---:|---:|---:|
| zealot→zealot, ×2 weak | 3.38× | **3.38×** (cap inert) | **2.50×** (cap bites) |
| zealot→fighter, ×2 weak | 2.60× | 2.60× (cap inert) | 2.50× |

Under **(a)** the cap watches `element_mult`; since element (2.0) < cap (2.5) it **never fires**, and the
`MA × spell × faith² × G_m` spine multiplies the 1.69 faith² **uncapped on top** → 3.38×. The soft-cap is
structurally **incapable** of bounding the faith²-driven corner — it is watching the wrong term. Only
**(b)**, the whole-product cap, delivers the "soft cap in reserve" guarantee the philosophy claims. This
holds across cap values {2.0, 2.5, 3.0}: every element-domain cell equals the no-cap cell.

**Does it reach an absolute one-shot?** base(MA) (OQ-22) and G_m (OQ-17) are open, so the absolute result
is reported against one knob: `B` = a neutral top-tier nuke as a fraction of the squishiest target's HP.
One-shot iff `corner × B ≥ 1`. The corner has **~2.2× of headroom to spend**, so:
- everyday 2.20× one-shots the squishy target at **B ≥ 46%**;
- ×2-exception under element-cap (= no-cap, 3.38×) one-shots at **B ≥ 30%**; whole-cap 2.50× needs B ≥ 40%.

**Who actually dies (B = 45% of robe HP, fighter HP ≈ 1.5× robe):** the everyday corner one-shots only
the **devout mage** (robe, faith 85, 98% → effectively dead) — arguably the *intended* glass-cannon
outcome. One-shotting a **healthy fighter on his weak element** needs the **×2 exception AND the
element-only cap reading** (3.38× → 78% of a leather fighter… and a clean one-shot of the robe at 152%);
the whole-product cap holds the same build to a big-but-survivable hit. **AoE makes it worse, not
different:** a summon (per-unit tier 4.5 vs Firaga 3.0 = ×1.5) one-shots every high-Faith unit in the
blast at the everyday band and fighters too under the element-cap reading — a multi-kill, same structure.

**Grounded magnitude check.** With the simplest `base(MA)=MA` and the register's own G_m≈3, a *neutral*
Firaga already ~one-shots a robe mage (130% HP) — the corner is pure overkill. The absolute safety lives
**entirely** in choosing base(MA)/G_m to seat the neutral nuke well below 100% (toward G_m=2 or a
sub-linear base). OQ-23 is literal: no structural damper, only calibration.

## MR-4.2 DEFENSE — the multiplicative turtle holds; binary Magic-Evade composed on top breaches

**Multiplicative stack alone: FINITE, not immune (holds).** Defender's floor (atheist faith_target 0.70
× zodiac-resist 0.70 × Shell 0.50) = **0.245×** (0.21–0.28× across the band reserves). A multiplicative
resist never zeroes — "never immunity" is true for this layer, exactly as designed. And it has **outs**
(11.27): switch off the resisted element + wait Shell out collapses the wall to faith-only 0.70×.

**Compose the binary Magic-Evade and it breaches.** Evade is all-or-nothing, so it multiplies *expected*
throughput by `(1 − p)`. Even after the attacker spends every multiplicative out (wall down to 0.70×),
casts-to-kill at B=45%:

| p_evade | eff. mult | casts-to-kill (exp) | verdict |
|---:|---:|---:|---|
| 0% | 0.70× | 3.2 | killable/fair |
| 50% | 0.35× | 6.3 | de-facto immune |
| 75% | 0.175× | 12.7 | de-facto immune |
| 90% | 0.070× | 31.7 | de-facto immune |

A caster's whole-fight budget is a handful of bursts (MP + charge). **Magic-Evade above ~45–50% pushes
casts-to-kill past a full fight even with the turtle's wall already broken** — so a "feels-safe" 80%
evade cap is *already* de-facto magic immunity. The guardrail (11.38) caps the evade **term** in
isolation; it never bounds **evade × resist-stack**, and unlike the multiplicative wall the binary evade
has **no out** (off-Speed 11.37, facing-independent 11.52, not depletable by focus-fire). "Capped <100%"
is far too loose: to keep the turtle finite-killable the evade cap must sit **≤ ~47%**.

*(Caveat: the true real-world brake here is the MP/charge cast budget and the fact that an all-in
anti-magic turtle folds to physical — both outside the damage-stack scope; see skipped axes.)*

---

## Sensitivity

The structural results hold across every crossed axis. The everyday 2.20× corner is invariant to cap
value and cap domain (cap dormant). The break is **conditional and located precisely**: it needs a
reserve/exception (×2 element, widened Faith band, or unclamped faith>85) **and** the element-only cap
reading. The defense breach is monotone in evade and independent of which Faith-band reserve is chosen.
G_m / base(MA) move only the absolute baseline B, not the corner multiplier.

## Axes crossed / skipped

**Crossed:** G_m {2,3,4}; cap value {2.0,2.5,3.0}; **cap domain {element-only, whole-product}**; Faith
band {[.80,1.20],[.70,1.30],[.65,1.30]} + floor 0.60; element {everyday 1.30, ×2-exception 2.0, resist
0.70}; Shell on/off; spell {Fire,Fira,Firaga,Summon 4.5}; neutral-nuke %HP B-sweep; Magic-Evade
{0,.5,.75,.9,.95}; target archetype {robe mage, leather fighter}; phase {early,mid,late}.

**Skipped (flagged):** exact base(MA) curve (OQ-22 — decoupled via B-sweep; slope-1 only in the grounded
pass); **Rod magic-power-mod "scaled by Faith" (14.3) as a possible THIRD Faith application** — would
*widen* the corner, not modeled; faith>85 unclamped extrapolation (modeled clamped); **MP-budget / charge
throttle** on casts-per-fight (the real brake on the evade-immunity corner); absorb (×−1 heal) sign-flip;
status axis; AI-usability of the dedicated magic-resist slot (philosophy R-A risk).

## Lean: **HOLDS (everyday) / REVISE (the reserves)**

The bounded claim **holds for the everyday modest bands** — no one-shot of an unpaid target, no immunity
from the multiplicative stack. But two *reserve/exception* paths reproduce a degenerate corner, and both
are currently **under-specified, not safe**:
1. **Offense:** the soft-cap's domain must be **pinned to the whole product** (reading b). Left on
   `element_mult` only (or unspecified, as today), the faith² spine walks past it and the ×2-element /
   widened-band corner one-shots a fighter. One-line fix: `cap = min(cap, faith_c·faith_t·element)`.
2. **Defense:** the Magic-Evade cap must be bounded **against the resist stack**, not in isolation —
   "<100%" admits de-facto immunity; the composition `(1−cap)×resist_floor` needs a finite-kill floor
   (cap ≈ ≤ 50%, or a non-binary/partial-evade model).

Not a full **break**: the everyday-band invariant survives and both fixes are small. But the docs leave
exactly the two ambiguities (cap domain, evade composition) on which the corners turn — so "bounded" is
not yet *earned*, it is *one specification away*.

## What would flip this

**To HOLDS:** pin the soft-cap to the whole product **and** keep ×2/absorb + Faith-band-widening out of
the everyday band — then the offense corner cannot one-shot a non-mage; and set the Magic-Evade cap so
`(1−cap)×0.70 ≥ ~1/6` (≈ ≤ 47%) so the turtle stays finite-killable. **To BREAK:** ship the cap on
`element_mult` only (or leave it unspecified) and/or let a dedicated build reach >80% Magic-Evade — then
both degenerate corners are live in ordinary play.

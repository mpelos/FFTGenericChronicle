#!/usr/bin/env python3
"""
sim_confront_supremacy.py — FALSIFY "magic is balanced vs physical" (caster supremacy, M2/S-series).

Confronts MAGIC against the TRUSTED physical baseline (sim_core) on ONE common HP scale, and tries to
BREAK three claims:

  MR-1  The free weapon-bolt is NOT a strictly-better basic attack (it pays on some axis; rule 00.1).
  MR-3  "Bring a mage" has >=2 COMMON losing contexts (it does not strictly dominate the armored half).
  MR-6  Magic does not out-slope physical per stat-point late-game.

METHOD (honest scale-bridging — the crux):
  - Physical damage-on-hit is sim_core.injury() (G=1, subtractive DR, wound mult, pen floor).
  - Physical damage/turn = injury * p_land(skill, defense, facing)   <- the fighter rolls to hit AND the
    target rolls to defend. This two-roll exposure is part of the confrontation (S2).
  - Magic damage-on-hit = base(MA)*spell_power*faith_c*faith_t*element*G_m  (sim_magic_* model).
  - Magic damage/turn  = magic * (1 - magic_evade).  Per R-A, un-invested targets have magic_evade=0,
    so the bolt AUTO-LANDS while the fighter can whiff/be-dodged.
  - sim_core (G=1) and sim_magic_economy (fighter gp=5, G_m=3) live on DIFFERENT scales, so G_m=3 is NOT
    transferable as-is. We CALIBRATE G_m* on sim_core's scale to the design's own balance anchor (11.49:
    "mage per-battle total ~ a fighter's vs SOFT targets"), then ALSO honor the task's literal G_m in
    {2,3,4} and a relative +/-33% sweep. The STRUCTURAL reads (losing contexts, slope, strictly-better)
    are ratio-shaped and largely scale-independent; absolute % HP is read at G_m*.

AXES CROSSED: target {plate, leather, evasive-thief, robe} x stage {early,mid,late} x G_m {2,3,4 & cal
  +/-33%} x bolt_power {0.6,0.8,1.0} x base(MA) slope {0.8,1.0,1.2} x physical base {linear, GURPS-
  diminishing} x fighter loadout {fixed-sword, right-tool} x magic_evade {0=uninvested, dedicated-slot} x
  battle length T {6,10,16} x faith {neutral, band-corners for context}.
AXES SKIPPED (named, with sign of bias):
  - AoE / multi-target: bolt+spells modeled SINGLE-TARGET only. AoE only HELPS magic -> single-target is
    CONSERVATIVE for the 'balanced' claim (a real game tilts further toward magic).
  - Zodiac off-neutral: neutral element only in the headline; weak(x1.30)/resist(x0.70) shown in sweep.
    Resist is a target's counter; neutral is the fair midpoint.
  - Charge/CT vs Speed refresh loop: charge modeled as turns-occupied (economy sim); no full CT-tick guard
    refresh. Interrupt skills (anti-caster) NOT modeled -> CONSERVATIVE for 'balanced' (a real counter to
    magic is omitted).
  - Status/CC, healing: out of scope (these are separate breaks).
  - Reactions (Counter punishes the meleeing fighter, never the ranged bolt): noted, not modeled ->
    slightly favors the FIGHTER here, i.e. conservative against the bolt-dominance break.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_core as core
from sim_core import injury, base_pa, p_land, p_crit, p_le, CONFIG

# ============================================================================
# 0) FIXED placeholders (declared, then swept). Each labeled to a stated tier.
# ============================================================================
# stat tiers: PA for fighters, MA for the mage, matched per stage for apples-to-apples slope.
STAGES = {"early": 8, "mid": 14, "late": 20}     # raw PA/MA (sim_core uses PA 5..12 in tests; MA 16..20)
FIGHTER_SKILL = {"early": 11, "mid": 13, "late": 15}   # on-grade, in the 9-16 band (doc 10), cap 16

# targets: (armor_class, Dodge defense, HP).  HP from sim_magic_stack {robe110,leather150,plate200}.
# Magic Evade = 0 for ALL (none buy the dedicated magic-resist slot -> R-A / the AI-won't-buy-it risk).
TARGETS = {
    "plate":  {"armor": "plate",   "dodge": 8,  "hp": 200},   # knight: heavy, no evasion
    "leather":{"armor": "leather", "dodge": 9,  "hp": 150},   # skirmisher
    "thief":  {"armor": "leather", "dodge": 11, "hp": 130},   # evasive: high Dodge, lighter
    "robe":   {"armor": "robe",    "dodge": 9,  "hp": 110},   # robe mage (as a target)
}

WMOD = CONFIG["wmod"]            # baixo2 medio5 alto9 muito_alto14
GEN_W = WMOD["medio"]           # generic fighter weapon modifier (5)
CRUSH_MULT = CONFIG["crush_wmod_mult"]   # 1.5

# magic spells (sim_magic_economy tiers). bolt = the cantrip/floor tier (a LOW tier) -> the labeled pick.
SP   = {"bolt": 0.8, "Fire": 1.0, "Fira": 1.8, "Firaga": 3.0}
COST = {"bolt": 0,   "Fire": 8,   "Fira": 18,  "Firaga": 30}
CT   = {"bolt": 1,   "Fire": 1,   "Fira": 2,   "Firaga": 2}    # turns occupied
BOLT_SP_DEFAULT = 0.8
MA_SLOPE_DEFAULT = 1.0          # base(MA) = MA_SLOPE * MA (sim_magic_economy: base(MA)=MA)
MP_POOL, MP_TRICK = 80, 2       # ~3 Firaga bursts over T=10 ("a few bursts/battle")

# Faith band [0.70,1.30] centered at mid (sim_magic_faith / sim_magic_stack)
def faith_mult(F, bl=0.70, bh=1.30):
    F_MIN, F_MID, F_MAX = 25, 55, 85
    if F >= F_MID: return 1.0 + (F - F_MID)/(F_MAX - F_MID)*(bh - 1.0)
    return 1.0 + (F - F_MID)/(F_MID - F_MIN)*(1.0 - bl)
F_NEU = faith_mult(55)          # 1.0
ZWEAK, ZNEU, ZRES = 1.30, 1.00, 0.70
SHELL = 0.50

# ============================================================================
# 1) PHYSICAL: trusted sim_core + a GURPS-diminishing base variant for MR-6
# ============================================================================
# GURPS swing damage AVERAGE by ST (canonical, concave). sim_core approximates this as LINEAR slope 1.0
# (base_pa = ST-6). The real table is CONCAVE -> physical scales WORSE late than sim_core's linear model.
GURPS_SWING_AVG = {
    10:3.5,11:4.5,12:5.5,13:6.0,14:7.0,15:8.0,16:9.0,17:9.5,18:10.5,19:11.5,20:12.5,
    21:13.0,22:14.0,23:15.0,24:16.0,25:16.5,26:17.5,27:18.0,28:18.5,29:19.5,30:20.0,
}
def gurps_swing(st):
    if st in GURPS_SWING_AVG: return GURPS_SWING_AVG[st]
    if st < 10: return max(1.0, st - 7.0)
    # extrapolate above 30 at the local ~+0.6/ST diminishing tail
    return GURPS_SWING_AVG[30] + 0.6*(st - 30)

def base_pa_gurps(pa, cfg=CONFIG):
    return max(1.0, gurps_swing(pa + cfg["pa_offset"]))

def injury_base(pa, wmod, dtype, ac, cfg, base_fn, brave="mid", divisor="none"):
    """sim_core.injury re-implemented with a pluggable base(PA) (faithful to the pipeline)."""
    raw = base_fn(pa, cfg) + wmod
    if cfg["brave_apply"] == "raw": raw *= cfg["brave_off"][brave]
    dr = cfg["DR"][ac][dtype] / cfg["armor_divisor"][divisor]
    post = max(0.0, raw - dr)
    floored = max(cfg["pen_floor_frac"]*raw, post)
    out = floored * cfg["wound"][dtype] * cfg["G"]
    if cfg["brave_apply"] == "final": out *= cfg["brave_off"][brave]
    return out

def fighter_onhit(pa, tgt, loadout="right", brave="mid"):
    """Physical damage-on-hit. loadout: 'fixed' = sword/cut always; 'right' = crush vs plate else cut."""
    ac = TARGETS[tgt]["armor"]
    if loadout == "right" and ac == "plate":
        return injury(pa, GEN_W*CRUSH_MULT, "crush", ac, CONFIG, brave=brave)   # right tool vs plate
    return injury(pa, GEN_W, "cut", ac, CONFIG, brave=brave)                    # cut

def fighter_turn(pa, skill, tgt, loadout="right", brave="mid", facing="front"):
    return fighter_onhit(pa, tgt, loadout, brave) * p_land(skill, TARGETS[tgt]["dodge"], facing)

# ============================================================================
# 2) MAGIC: bolt + spells on sim_core's scale
# ============================================================================
def base_ma(ma, ma_slope=MA_SLOPE_DEFAULT): return ma_slope * ma
def spell_onhit(ma, sp, gm, fc=F_NEU, ft=F_NEU, elem=ZNEU, ma_slope=MA_SLOPE_DEFAULT):
    return base_ma(ma, ma_slope) * sp * fc * ft * elem * gm
def bolt_onhit(ma, gm, bolt_sp=BOLT_SP_DEFAULT, **kw):
    return spell_onhit(ma, bolt_sp, gm, **kw)
def magic_turn(onhit, magic_evade=0.0): return onhit * (1.0 - magic_evade)

def mage_burst_battle(ma, gm, T=10, pool=MP_POOL, trick=MP_TRICK, bolt_sp=BOLT_SP_DEFAULT,
                      fc=F_NEU, ft=F_NEU, elem=ZNEU, ma_slope=MA_SLOPE_DEFAULT, magic_evade=0.0):
    """Burst strategy (sim_magic_economy): cast biggest affordable charged spell; else bolt. Returns
    (total_damage, n_bursts, per_turn_list). Charge turns deal 0; Magic Evade applied to every landing."""
    mp = pool; charging = None; t = 0; per = []
    def land(x): return x*(1.0-magic_evade)
    while t < T:
        mp += trick
        if charging is not None:
            per.append(land(spell_onhit(ma, SP[charging], gm, fc, ft, elem, ma_slope))); charging=None; t+=1; continue
        if mp >= COST["Firaga"] and t < T-1:
            mp -= COST["Firaga"]; charging="Firaga"; per.append(0.0)
        elif mp >= COST["Fira"] and t < T-1:
            mp -= COST["Fira"]; charging="Fira"; per.append(0.0)
        else:
            per.append(land(bolt_onhit(ma, gm, bolt_sp, fc=fc, ft=ft, elem=elem, ma_slope=ma_slope)))
        t += 1
    nb = sum(1 for i in range(len(per)) if per[i]>0 and i>0 and per[i-1]==0)
    return sum(per), nb, per

# ============================================================================
# 3) CALIBRATE G_m* on sim_core's scale (anchor 11.49: mage total ~ fighter total vs SOFT/leather, mid)
# ============================================================================
def calibrate_gm(stage="mid", T=10):
    ma = pa = STAGES[stage]; skill = FIGHTER_SKILL[stage]
    fighter_total = fighter_turn(pa, skill, "leather", "right") * T          # vs soft, right tool, w/ p_land
    mage_at1, _, _ = mage_burst_battle(ma, gm=1.0, T=T)                       # magic total at G_m=1 (linear in gm)
    return fighter_total / mage_at1, fighter_total, mage_at1

GM_STAR, FT_CAL, MAGE1_CAL = calibrate_gm()

# ============================================================================
# MAIN
# ============================================================================
def hr(c="="): print(c*92)
if __name__ == "__main__":
    print("CONFRONT MAGIC vs PHYSICAL — built to BREAK 'magic is balanced' (MR-1 / MR-3 / MR-6)")
    hr()
    print(f"stages PA=MA: {STAGES}   fighter skill: {FIGHTER_SKILL}")
    print(f"bolt = cantrip/floor tier SP={BOLT_SP_DEFAULT} (0 MP, range-3, auto-lands vs evade-0)")
    print(f"MP budget: pool {MP_POOL} + trickle {MP_TRICK}/turn over T=10  (~3 Firaga bursts)")
    print(f"CALIBRATION (sim_core scale, anchor 11.49 mage~fighter vs leather, mid):")
    print(f"   fighter total vs leather (mid, right-tool, w/ p_land) = {FT_CAL:.1f}")
    print(f"   mage burst total at G_m=1                              = {MAGE1_CAL:.1f}")
    print(f"   => G_m* = {GM_STAR:.2f}   (this is the calibrated bridge; task's literal {{2,3,4}} are on")
    print(f"      the magic-spine scale and are ALSO run below for completeness)")

    # ----------------------------------------------------------------------
    # BREAK MR-1 : is the free bolt a strictly-better basic attack?
    # ----------------------------------------------------------------------
    hr()
    print("BREAK MR-1 — free weapon-bolt vs FIGHTER basic Attack (damage/turn). bolt auto-lands (evade 0);")
    print("fighter rolls hit+defense. Compare vs each target at each stage. STRICTLY-BETTER = bolt >= fighter")
    print("on EVERY target (incl. soft) => violates 00.1. Design INTENT: bolt > fighter vs plate (anti-armor),")
    print("bolt < fighter vs soft (the bolt's paid-for weakness).")
    for gm_label, gm in [("G_m*", GM_STAR), ("G_m=3 (literal)", 3.0)]:
        hr("-")
        print(f"[{gm_label} = {gm:.2f}]   bolt/turn  vs  fighter/turn (right-tool)   [ratio bolt/ftr]")
        print(f"   {'stage':6} {'target':8} | {'bolt/t':>7} | {'ftr/t':>7} {'(onhit)':>8} {'pland':>6} | {'bolt/ftr':>8}  flag")
        for stage in STAGES:
            ma = pa = STAGES[stage]; sk = FIGHTER_SKILL[stage]
            for tgt in TARGETS:
                b = magic_turn(bolt_onhit(ma, gm))                       # evade 0
                fo = fighter_onhit(pa, tgt, "right"); pl = p_land(sk, TARGETS[tgt]["dodge"])
                f = fo * pl
                r = b/max(f,1e-9)
                flag = "BOLT WINS" if r >= 1.0 else "ftr wins"
                soft = tgt in ("leather","thief","robe")
                if r >= 1.0 and soft: flag += " *soft-too*"
                print(f"   {stage:6} {tgt:8} | {b:7.1f} | {f:7.1f} {fo:8.1f} {pl:6.2f} | {r:8.2f}  {flag}")
    print("\n   READ MR-1: the bolt has a losing context ONLY if 'ftr wins' appears on a SOFT target.")
    print("   A bolt that beats the fighter on plate AND on every soft target = strictly better (break).")

    # bolt cost audit: what does the bolt pay that the fighter does not?
    print("\n   COST AUDIT (rule 00.1 — every advantage paid on another axis):")
    print(f"     - bolt range 3, auto-lands, ignores DR, 0 MP. Fighter pays: hit roll + target defense roll")
    print(f"       (p_land<1), DR subtraction, reach 1 (must close + eats Counter).")
    print(f"     - bolt's stated price: robe-only (DR~0/0/0) caster body, low base-HP, slow Speed, no melee,")
    print(f"       single-target (no AoE here), and Faith glass-jaw. NONE of these reduce bolt DAMAGE/turn ->")
    print(f"       the bolt's advantages are NOT paid on the damage axis; they are paid on SURVIVABILITY.")

    # ----------------------------------------------------------------------
    # BREAK MR-3 : mage full output vs fighter on the armored half; >=2 COMMON losing contexts?
    # ----------------------------------------------------------------------
    hr()
    print("BREAK MR-3 — full mage output (bolt + bursts in MP budget) vs fighter, per-battle (T=10) and")
    print("turns-to-kill (TTK = HP / dmg-per-turn-avg). MAGE DOMINATES if it kills >= as fast on EVERY target.")
    gm = GM_STAR
    print(f"\n[battle totals, G_m*={gm:.2f}, T=10, neutral faith/element, evade 0]")
    print(f"   {'target':8} {'HP':>4} | {'mage tot':>8} {'TTK_m':>6} | {'ftr tot':>8} {'TTK_f':>6} | winner(faster kill)")
    losing = []
    for tgt in TARGETS:
        ma = pa = STAGES["mid"]; sk = FIGHTER_SKILL["mid"]; hp = TARGETS[tgt]["hp"]
        mtot, nb, mper = mage_burst_battle(ma, gm, T=10)
        mdpt = mtot/10.0
        ftot = fighter_turn(pa, sk, tgt, "right")*10.0; fdpt = ftot/10.0
        ttk_m = hp/max(mdpt,1e-9); ttk_f = hp/max(fdpt,1e-9)
        win = "MAGE" if ttk_m <= ttk_f else "fighter"
        if ttk_f < ttk_m: losing.append(("fighter-faster-kill@"+tgt, ttk_f, ttk_m))
        print(f"   {tgt:8} {hp:>4} | {mtot:8.0f} {ttk_m:6.1f} | {ftot:8.0f} {ttk_f:6.1f} | {win}")
    print(f"   (mage bursts/battle = {nb})")

    # Losing context A: evasive thief CLOSES and kills the fragile robe mage (a CT-tick duel).
    hr("-")
    print("LOSING CONTEXT A — evasive thief rushes a LONE robe mage (M6: AI rushes the caster).")
    def thief_duel(start_dist=5, stage="mid", gm=GM_STAR, mage_hp=110, thief_hp=130,
                   thief_speed=10, mage_speed=7, thief_skill=13, bolt_sp=0.8, verbose=False):
        pa = ma = STAGES[stage]
        # thief: dual-wield (2 strikes), backstabs when adjacent (facing back -> no defense roll)
        def thief_hit_dmg(backstab):
            strike = injury(pa, GEN_W, "cut", "robe", CONFIG)     # vs robe DR 1
            pl = p_land(thief_skill, TARGETS["robe"]["dodge"], "back" if backstab else "front")
            return 2*strike*pl                                    # 2 strikes/turn
        # mage: bolt auto-lands on thief (evade 0); can Firaga (burst). thief HP via burst economy.
        ct_t = ct_m = 0; mp = MP_POOL; charging=None; dist=start_dist; mhp=mage_hp; thp=thief_hp
        log=[]
        for tick in range(1, 200):
            ct_t += thief_speed; ct_m += mage_speed
            # mage acts
            if ct_m >= 100 and mhp > 0:
                ct_m -= 100; mp += MP_TRICK
                if charging is not None:
                    thp -= spell_onhit(ma, SP[charging], gm); charging=None
                elif mp >= COST["Firaga"]:
                    mp -= COST["Firaga"]; charging="Firaga"   # 2-turn charge (resolves next mage turn)
                else:
                    thp -= bolt_onhit(ma, gm, bolt_sp)
                if thp <= 0: log.append((tick,"mage kills thief")); return "MAGE", tick, mhp, thp, log
            # thief acts
            if ct_t >= 100 and thp > 0:
                ct_t -= 100
                if dist > 1:
                    dist = max(1, dist - 4)                    # Move ~4 tiles toward mage
                    log.append((tick, f"thief closes -> dist {dist}"))
                else:
                    mhp -= thief_hit_dmg(backstab=True)
                    log.append((tick, f"thief backstab -> mage {mhp:.0f}"))
                if mhp <= 0: log.append((tick,"thief kills mage")); return "THIEF", tick, mhp, thp, log
        return "TIMEOUT", 200, mhp, thp, log
    for sd in (1, 3, 5):
        w, tk, mhp, thp, log = thief_duel(start_dist=sd)
        print(f"   start_dist={sd}: winner={w} at tick {tk}   (mageHP_end={mhp:.0f}, thiefHP_end={thp:.0f})")
        if sd == 5:
            for t,e in log[:10]: print(f"        t{t}: {e}")
    print("   -> if THIEF wins from a realistic start distance, 'bring a lone mage' loses to the rusher (CTX A).")

    # Losing context B: attrition past the MP budget (long battle -> mage decays to the bolt floor).
    hr("-")
    print("LOSING CONTEXT B — attrition: long battle, MP budget spent, mage falls to the bolt floor.")
    print(f"   cumulative damage vs LEATHER (soft), G_m*={GM_STAR:.2f}:  does the fighter total OVERTAKE the mage?")
    ma = pa = STAGES["mid"]; sk = FIGHTER_SKILL["mid"]
    print(f"   {'T':>3} | {'mage cum':>9} | {'ftr cum':>9} | {'mage/ftr':>8}  crossover?")
    cross = None
    for T in (4,6,8,10,12,14,16,20):
        mtot,_,_ = mage_burst_battle(ma, GM_STAR, T=T)
        ftot = fighter_turn(pa, sk, "leather", "right")*T
        r = mtot/max(ftot,1e-9)
        if cross is None and r < 1.0: cross = T
        print(f"   {T:>3} | {mtot:9.0f} | {ftot:9.0f} | {r:8.2f}  {'<-- fighter ahead' if r<1.0 else ''}")
    print(f"   -> fighter overtakes the mage on a soft target at T>={cross} (CTX B): magic front-loads,")
    print(f"      physical out-sustains past the budget. (vs PLATE the mage stays ahead — its real role.)")

    # mage vs PLATE: the anti-armor domination check (is there NO common losing context vs the armored half?)
    print("\n   ANTI-ARMOR check (mage vs fighter, vs PLATE, T=10, G_m*):")
    mtot,_,_ = mage_burst_battle(STAGES['mid'], GM_STAR, T=10)
    ftot_plate = fighter_turn(STAGES['mid'], FIGHTER_SKILL['mid'], "plate", "right")*10
    print(f"      mage {mtot:.0f} vs fighter(right-tool crush) {ftot_plate:.0f}  -> mage/ftr = {mtot/ftot_plate:.2f}x"
          f"  ({'mage dominates plate' if mtot>ftot_plate else 'fighter ok vs plate'})")

    # ----------------------------------------------------------------------
    # BREAK MR-6 : late-game per-point slope, magic (linear MA) vs physical (linear vs GURPS-diminishing)
    # ----------------------------------------------------------------------
    hr()
    print("BREAK MR-6 — per-stat-point slope late-game. d(dmg-on-hit)/d(stat) for magic(MA) vs physical(PA).")
    print("magic base(MA) LINEAR; physical tested BOTH as sim_core-linear AND a true GURPS-diminishing table.")
    def slope(fn, x, h=2): return (fn(x+h) - fn(x-h))/(2*h)
    print(f"\n   physical slope vs LEATHER (cut, ignoring p_land = on-hit only):")
    print(f"   {'stat~':6} | {'phys-linear':>11} {'phys-GURPS':>10} | {'magic bolt':>10} {'magic Fira':>10}  (G_m*)")
    for stage,x in STAGES.items():
        f_lin  = slope(lambda p: injury_base(p, GEN_W, "cut", "leather", CONFIG, base_pa), x)
        f_gur  = slope(lambda p: injury_base(p, GEN_W, "cut", "leather", CONFIG, base_pa_gurps), x)
        m_bolt = slope(lambda a: bolt_onhit(a, GM_STAR), x)
        m_fira = slope(lambda a: spell_onhit(a, SP["Fira"], GM_STAR), x)
        print(f"   {stage:6} | {f_lin:11.2f} {f_gur:10.2f} | {m_bolt:10.2f} {m_fira:10.2f}")
    print("   (slopes are per +1 stat point. magic slope = ma_slope*SP*faith*elem*G_m; physical slope =")
    print("    base_slope*wound in the linear region, and DROPS under the concave GURPS table at high ST.)")
    print("\n   late-game ON-HIT totals (stat=late) and the GAP that the slope opens:")
    x = STAGES["late"]
    print(f"   phys cut/leather: linear {injury_base(x,GEN_W,'cut','leather',CONFIG,base_pa):.1f} | "
          f"GURPS {injury_base(x,GEN_W,'cut','leather',CONFIG,base_pa_gurps):.1f}")
    print(f"   magic bolt {bolt_onhit(x,GM_STAR):.1f} | Fira {spell_onhit(x,SP['Fira'],GM_STAR):.1f} | "
          f"Firaga {spell_onhit(x,SP['Firaga'],GM_STAR):.1f}   (all auto-land; physical still rolls p_land)")

    # ----------------------------------------------------------------------
    # SENSITIVITY SWEEPS (task: G_m{2,3,4}, bolt power +/-, base(MA) slope +/-)
    # ----------------------------------------------------------------------
    hr()
    print("SENSITIVITY — does any conclusion flip? bolt-vs-fighter ratio (mid) vs plate & leather.")
    print(f"   {'G_m':>5} {'bolt_sp':>7} {'ma_slope':>8} | {'bolt/ftr PLATE':>14} {'bolt/ftr LEATHER':>16}  soft-break?")
    pa = ma = STAGES["mid"]; sk = FIGHTER_SKILL["mid"]
    f_plate = fighter_turn(pa, sk, "plate", "right"); f_leu = fighter_turn(pa, sk, "leather", "right")
    for gm in (2.0, 3.0, 4.0, round(GM_STAR*0.67,2), round(GM_STAR,2), round(GM_STAR*1.33,2)):
        for bsp in (0.6, 0.8, 1.0):
            for msl in (0.8, 1.0, 1.2):
                b = bolt_onhit(ma, gm, bsp, ma_slope=msl)
                rp, rl = b/f_plate, b/f_leu
                brk = "SOFT-BREAK" if rl >= 1.0 else ""
                print(f"   {gm:5.2f} {bsp:7.2f} {msl:8.2f} | {rp:14.2f} {rl:16.2f}  {brk}")

    print("\n   dedicated magic-resist slot (R-A counterplay): target buys Shell x0.50 + Magic-Evade 0.50.")
    print(f"   bolt/turn vs that target vs an un-invested target (mid, G_m*):")
    b_un = magic_turn(bolt_onhit(ma, GM_STAR))
    b_inv = magic_turn(bolt_onhit(ma, GM_STAR, elem=SHELL), magic_evade=0.50)   # Shell + 50% evade
    print(f"      un-invested = {b_un:.1f}/turn   |   dedicated-slot = {b_inv:.1f}/turn   "
          f"(slot cuts the bolt to {b_inv/b_un:.0%})")

    # ----------------------------------------------------------------------
    # VERDICT booleans (ground truth printed; prose lives in the READ)
    # ----------------------------------------------------------------------
    hr()
    print("VERDICT FLAGS (computed):")
    # MR-1: strictly-better iff bolt>=fighter on EVERY soft target at calibrated G_m
    strict = True
    for stage in STAGES:
        ma = pa = STAGES[stage]; sk = FIGHTER_SKILL[stage]
        for tgt in ("leather","thief","robe"):
            b = magic_turn(bolt_onhit(ma, GM_STAR)); f = fighter_turn(pa, sk, tgt, "right")
            if b < f: strict = False
    print(f"   MR-1 bolt strictly-better than fighter on ALL soft targets @G_m* : {strict}")
    # MR-3: count COMMON losing contexts
    wA = thief_duel(start_dist=5)[0]; wA3 = thief_duel(start_dist=3)[0]
    mtot16,_,_ = mage_burst_battle(STAGES['mid'], GM_STAR, T=16)
    f16 = fighter_turn(STAGES['mid'], FIGHTER_SKILL['mid'], "leather","right")*16
    ctxA = wA == "THIEF" or wA3 == "THIEF"
    ctxB = mtot16 < f16
    print(f"   MR-3 CTX-A (thief rushes & kills lone mage): {ctxA}  (dist5={wA}, dist3={wA3})")
    print(f"   MR-3 CTX-B (fighter out-sustains vs soft @T16): {ctxB}  (mage {mtot16:.0f} vs ftr {f16:.0f})")
    print(f"   MR-3 >=2 common losing contexts for 'bring mages': {ctxA and ctxB}")
    # MR-6: magic out-slopes physical late
    x = STAGES["late"]
    m_bolt_sl = (bolt_onhit(x+2,GM_STAR)-bolt_onhit(x-2,GM_STAR))/4
    f_lin_sl  = slope(lambda p: injury_base(p, GEN_W, "cut","leather",CONFIG,base_pa), x)
    f_gur_sl  = slope(lambda p: injury_base(p, GEN_W, "cut","leather",CONFIG,base_pa_gurps), x)
    print(f"   MR-6 magic-bolt slope {m_bolt_sl:.2f} vs phys-linear {f_lin_sl:.2f} (out-slopes={m_bolt_sl>f_lin_sl}) "
          f"| vs phys-GURPS {f_gur_sl:.2f} (out-slopes={m_bolt_sl>f_gur_sl})")
    print("\n   (Firaga slope is far steeper still; bolt is the conservative magic line. See READ for the lean.)")

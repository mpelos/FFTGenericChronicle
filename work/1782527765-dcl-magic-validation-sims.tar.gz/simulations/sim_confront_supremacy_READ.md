# sim_confront_supremacy — READ (magic vs physical: caster-supremacy falsification)

**What it does.** Confronts MAGIC against the trusted physical baseline (`sim_core`) on **one common HP
scale** and tries to break three claims: MR‑1 (the free bolt is a strictly‑better basic attack), MR‑3 (the
mage dominates the armored half with no common losing context), MR‑6 (magic out‑slopes physical late‑game).
Physical = `sim_core.injury()` × `p_land` (the fighter rolls **hit + defense**). Magic =
`base(MA)·spell_power·faith·element·G_m` × `(1−Magic_Evade)`; per **R‑A**, un‑invested targets have
Magic‑Evade 0 so the bolt **auto‑lands**. Output of the script is ground truth; this is the read.

---

## THE LOAD‑BEARING FINDING: it all rides on one calibration constant (G_m), and the two sim families are
## on different scales

`sim_core` runs at `G=1`; `sim_magic_economy` calibrated `G_m=3` against a **different fighter** (`gp=5`,
~8× hotter output). So **`G_m=3` is not transferable to `sim_core`'s scale.** Calibrating G_m to the
design's own balance anchor (decision 11.49: *mage per‑battle total ≈ a fighter's vs soft targets*) on
`sim_core`'s scale gives:

```
fighter total vs leather (mid, right-tool, with p_land) = 111.4
mage burst total at G_m=1 (3 Firaga + 4 bolts, T=10)    = 170.8
=> G_m*  = 0.65    (the calibrated bridge on sim_core's scale)
```

**The task's literal G_m∈{2,3,4} sit 3–6× ABOVE this balance point.** Plug `G_m=3` straight into the DCL
physical scale and the bolt **alone** beats a right‑tool fighter by **2.37–6.51× on every target, soft
included** (e.g. mid leather 3.02×, late robe 2.37×, early thief 6.51×) — i.e. **caster supremacy
reproduces catastrophically**, but as a **scale artifact / calibration error**, not an independent
structural break. This is exactly OQ‑23 / philosophy‑M4 made concrete: *multiplicative magic has no
structural damper; the safe band is held entirely by calibration.* Every verdict below is therefore stated
**at the calibrated G_m\*=0.65** (where the design intends to sit) with the sensitivity to G_m called out.

---

## MR‑1 — is the free bolt a strictly‑better basic attack?  → **HOLDS** (calibration‑gated)

At G_m\*, `bolt/fighter` damage‑per‑turn (right‑tool fighter), every soft target loses to the fighter:

| stage | plate | leather | thief | robe |
|------|------|------|------|------|
| early | 0.85 | 0.88 | **1.41** | 0.70 |
| mid   | 0.71 | 0.66 | **1.07** | 0.57 |
| late  | 0.65 | 0.57 | 0.90 | 0.52 |

- **Strictly‑better flag = False.** The bolt is *below* the fighter on leather, robe and (right‑tool) plate
  at every stage. Its only win is vs the **evasive thief** (1.07–1.41×) — and that win is **anti‑evasion**
  (the bolt auto‑lands while the thief dodges the fighter, p_land 0.25–0.39), **not** the advertised
  anti‑armor role.
- **Sub‑revise (honest):** at the balance point the bolt is **not** "≥ a fighter vs plate" (it's 0.65–0.71×
  a **crush** fighter). The advertised "depleted mage = anti‑armor chipper ≥ fighter vs plate" (11.47 /
  economy‑T2) is true only against a **wrong‑tool** (sword/cut) fighter; the crush specialist beats the
  bolt on plate. The bolt's real anti‑role is evasion, and the **burst spells** carry the anti‑armor.
- **Cost audit (00.1):** the bolt's advantages (range‑3, auto‑land, ignores DR, 0 MP) are **not** paid on
  the damage axis — they're paid on **survivability** (robe DR≈0, low base‑HP, slow Speed, no melee, no AoE
  modeled, Faith glass‑jaw). That's a legitimate cross‑axis payment, but see MR‑3: it has to actually bite.

**What would flip MR‑1:** G_m on `sim_core`'s scale rising above ~0.9 (with bolt_sp 0.8, ma_slope ≥1.0) —
the sweep shows the first soft‑break at **G_m≈0.87 / ma_slope 1.2**, and universal soft‑break by **G_m=2**.
A Rod magic‑power mod that lifts the bolt's effective tier (bolt_sp→1.0) pulls that threshold down too.

---

## MR‑3 — does the mage dominate the armored half with no common losing context? → **HOLDS** (≥2 found)

Per‑battle TTK at G_m\* (mid, T=10), `MAGE` = mage kills ≥ as fast:

| target | HP | mage TTK | fighter TTK | winner |
|------|----|------|------|------|
| plate | 200 | 17.9 | 19.4 | MAGE (1.08×, marginal) |
| leather | 150 | 13.5 | 13.5 | tie |
| thief (as target) | 130 | 11.7 | 19.0 | MAGE (auto‑land) |
| robe | 110 | 9.9 | **8.6** | **fighter** |

Mage advantage is confined to **plate** (anti‑armor, marginal 1.08×) and the **evasive thief‑as‑target**
(auto‑land). It does **not** dominate the robe target, and ties leather. Two **common losing contexts**
both reproduce:

- **CTX‑A — evasive thief rushes the lone robe mage (M6).** CT‑tick duel (thief Speed 10 / mage Speed 7,
  dual‑wield backstab vs robe): **THIEF wins from every start distance** (adjacent, 3, 5 tiles), killing the
  110‑HP mage at tick 30–40 while taking only ~27 damage. The slow caster + 2‑turn Firaga charge + 110 HP
  can't out‑race the rusher. **This is the scale‑robust break** — it survives up to **G_m≈3** (at G_m=3 the
  thief still wins, ending at 4 HP) and only **flips to the mage at G_m≈4** (one Firaga one‑shots the thief
  before its 2nd backstab). It's an **action‑economy/fragility** loss, not a damage‑ratio one.
- **CTX‑B — attrition past the MP budget.** Cumulative damage vs leather: the fighter **overtakes** the
  mage at **T≥12** (T16: mage 157 vs fighter 178; T20: 186 vs 223). Magic front‑loads 3 bursts then decays
  to the bolt floor; physical out‑sustains. **This one is scale‑sensitive** — it evaporates at high G_m
  (the front‑load gets too large to catch).

**R‑A counterplay works when bought:** a dedicated magic‑resist slot (Shell ×0.50 + Magic‑Evade 0.50) cuts
the bolt from 7.3 → **1.8/turn (25%)**. The open risk stays that the AI won't buy it — but CTX‑A shows the
AI's *other* answer (rush the caster) needs no purchase and works.

**What would flip MR‑3:** G_m ≈ 4 on `sim_core`'s scale erases CTX‑A (caster out‑bursts the rusher) and any
G_m well above balance erases CTX‑B — i.e. the same mis‑scaling that breaks MR‑1 also removes the losing
contexts. Giving the mage Speed/charge relief would independently kill CTX‑A.

---

## MR‑6 — does magic out‑slope physical late‑game? → **HOLDS for the floor / WATCH the burst**

Per‑stat‑point slope of damage‑on‑hit (constant across stages because both bases are linear):

```
phys cut/leather:  linear 1.50   GURPS-diminishing 1.31
magic bolt (G_m*): 0.52          magic Fira (G_m*): 1.17     magic Firaga (G_m*): ~1.95
```

- The **bolt does NOT out‑slope physical** (0.52 ≪ 1.31–1.50): at the balance point the magic *floor*
  scales **softer** per point than a fighter.
- The task's premise that "physical rides a diminishing GURPS table" is only **mildly** true in‑band: the
  real concave swing table is **13% below** sim_core's linear approximation (1.31 vs 1.50), not a cliff.
  (Late on‑hit: GURPS cut 27.0 vs linear 30.0.)
- **But the burst tier out‑slopes physical even at G_m\*:** Firaga's slope (~1.95) > physical (1.31–1.50),
  because slope = `ma_slope·spell_power·G_m` scales with the spell tier. So the mage's **spike** sharpens
  per point faster than a fighter while its **sustain** lags — a reasonable spike/sustain shape, *gated by
  MP*. Magic's slope is **entirely a G_m·spell_power artifact** (no structural anchor), so it's calibration,
  not geometry, holding it.

**What would flip MR‑6 into a real late break:** loosening MP‑gating (more Firagas/battle at high level) so
the >physical burst slope dominates the battle average, or G_m drifting up — both make late‑game tilt to
magic. The floor is safe; the burst is on a calibration leash.

---

## Sensitivity (axes crossed) and what was skipped

**Crossed:** target {plate, leather, evasive‑thief, robe} × stage {early/mid/late} × G_m {2,3,4 + cal
±33%} × bolt_sp {0.6,0.8,1.0} × base(MA) slope {0.8,1.0,1.2} × physical base {sim_core‑linear,
GURPS‑diminishing} × fighter loadout {fixed‑sword, right‑tool} × Magic‑Evade {0, dedicated‑slot} × battle
length T {4…20} × CT‑duel start‑distance {1,3,5}. The **G_m sweep is decisive**: every conclusion is a
monotone function of G_m, and the calibrated point (0.65) and the literal points (2–4) land on **opposite
sides** of every threshold.

**Skipped (named, with bias sign):** AoE/multi‑target (single‑target only → **conservative**, favors the
"balanced" claim; real AoE tilts toward magic); Zodiac off‑neutral (neutral in headline; weak ×1.30 /
resist ×0.70 only in sweep); full CT guard‑refresh + **interrupt skills** (omitted → **conservative**, a
real anti‑caster counter is left out); status/CC and healing (separate breaks); reactions/Counter (would
punish the meleeing fighter, not the bolt → slightly favors the fighter here).

---

## Bottom line

| break | reproduces? | lean | evidence |
|------|------|------|------|
| **MR‑1** bolt strictly‑better | No, at G_m\* | **HOLDS** (calibration‑gated) | bolt < fighter on all soft targets (0.52–0.88×); only beats the *evasive* target, via auto‑land |
| **MR‑3** mage dominates armored half | No, at G_m\* | **HOLDS** | ≥2 common losing contexts: rush‑the‑caster (THIEF wins all distances) + attrition (fighter ahead at T≥12) |
| **MR‑6** magic out‑slopes physical | Floor: no. Burst: yes | **HOLDS (floor) / REVISE‑WATCH (burst)** | bolt slope 0.52 < phys 1.31–1.50; Firaga ~1.95 > phys, MP‑gated |
| **META** caster supremacy | **Yes, if G_m mis‑scaled** | **BREAK on calibration discipline** | at literal G_m=3 the bolt alone is 2.4–6.5× the fighter on every target |

**The design is structurally sound *only* conditional on G_m being re‑calibrated to the physical scale**
(~0.65 here, **not** the 3 inherited from `sim_magic_economy`, which lives on a ~8× hotter fighter). The
single biggest risk is not any one mechanic — it's that the two sim families never shared a scale, so the
"validated" G_m=3 would import caster supremacy wholesale if pasted onto the DCL physical numbers.

**One‑line flip for the whole verdict:** raise G_m on `sim_core`'s scale from ~0.65 toward ~2–4 (or let a
Rod mod lift bolt_sp) and all three breaks reproduce together — accuracy‑free auto‑landing magic that
out‑damages, out‑scales, and out‑survives its own losing contexts.

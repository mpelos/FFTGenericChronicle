#!/usr/bin/env python3
"""
sim_confront_tempo.py — P9 (action economy) falsification: does the free bolt make MP
irrelevant (M5), and does Speed give a caster degenerate pure-upside tempo (S3)?

Built to BREAK two claims, honest both ways:
  (a) the always-on, 0-MP weapon-bolt does NOT make MP irrelevant for sustained pressure (M5).
  (b) Speed does not re-import the FFT "Speed-stacking" degeneracy on the magic axis (S3 / P9).

It also tests (c) the only unset action-economy brake on big spells — CHARGE time — and how
fragile the whole P9-magic verdict is to that one knob (MR-8).

----------------------------------------------------------------------------------------------
MODEL REUSE (per directive)
  - Magic damage spine, fighter baseline, tiers, G_m, MA: from sim_magic_economy.py
        magic dmg  = MA * spell_power * G_m         (neutral Faith/element, FLAT vs armor)
        fighter/tn = max(pen*R, R-DR)*wound*gp  -> F_LEATHER 90, F_PLATE 37.5
        G_m = 3 (sim_magic_economy evidence), tiers bolt .8 / Fire 1.0 / Fira 1.8 / Firaga 3.0
  - Speed -> turns: FFT CT model from sim_speed.py (reimplemented to avoid that module's
        import-time prints). turns_per_window(speed,100) == speed turns. POST-FIX design:
        Dodge is DECOUPLED from Speed (register 04.6/B1) -> Speed = turn-frequency ONLY.
        A caster has NO depleting guard (Magic Evade never depletes, off Speed, 11.37/04.11),
        so guard-refresh does nothing for it; a fighter's Speed-defense is ONLY the situational
        guard-refresh (04.8) -> modelled as 0 in the common no-focus-fire case (conservative:
        it can only WIDEN the fighter's Speed value, never the caster's).

PLACEHOLDERS — declared, then SWEPT (no single magic value drives a verdict):
  - BOLT_SP   weapon-bolt spell_power   base 0.8   sweep {0.5, 0.65, 0.8, 1.0}
  - CHARGE    charge turns on big spells base 1     sweep {0, 1, 2}   (CT = 1+charge)
  - POOL/TRICK MP budget                 base 80/2  sweep pool{40,80,120} trick{2,4}
  - CLUSTER   AoE targets per big spell   base 1     sweep {1,2,3}
  - phases early/mid/late = which top spell is online + MA + pool (ratio bolt/spell is
        MA-INDEPENDENT since MA cancels; phases differ by tier mix + pool, not by MA).

AXES CROSSED: action-economy (Speed/CT/charge) x magic-economy (MP budget + bolt floor) x
              AoE (N-for-1) x range-safety (noted, not damage-scored).
AXES HELD NEUTRAL (skipped, to isolate tempo): Faith band, Zodiac/element, Magic Evade landing
              (assume the design's common case: un-invested target, magic lands — 11.36), Shell,
              healing, status/CC, robe-fragility/rush-the-caster (M6/P10), interrupt counterplay.
              These are named in the READ as the unscored axes the tempo verdict does NOT cover.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sim_magic_economy import fighter, F_LEATHER, F_PLATE, G_M   # reuse physical baseline + bridge

# ---- spell table (sp, mp, is_AoE). bolt & Fire single-target/instant; big spells AoE+charged ---
SPELLS = {
    "Fire":   dict(sp=1.0, mp=8,  aoe=False),   # cheap, instant (CT1) — the sustain tier
    "Fira":   dict(sp=1.8, mp=18, aoe=True),    # big, charged, AoE
    "Firaga": dict(sp=3.0, mp=30, aoe=True),    # bigger, charged, AoE
}
def mdmg(sp_power, ma, gm=G_M):      # mirrors sim_magic_economy.magic() but takes a float power
    return ma * sp_power * gm

# ---- generalized battle: total damage over `turns`, given strategy/charge/cluster -------------
def battle(turns, pool, trickle, ma, bolt_sp, top, charge, cluster=1, strategy="burst"):
    mp = pool; t = 0; total = 0.0; charging = None
    while t < turns:
        mp += trickle
        if charging is not None:                      # resolving a charged spell
            name, left = charging; left -= 1
            if left == 0:
                s = SPELLS[name]
                total += mdmg(s["sp"], ma) * (cluster if s["aoe"] else 1)
                charging = None
            else:
                charging = (name, left)
            t += 1; continue
        cast = None
        if strategy == "burst":
            if mp >= SPELLS[top]["mp"] and (charge == 0 or t < turns - charge):
                cast = top
            elif mp >= SPELLS["Fire"]["mp"]:
                cast = "Fire"
        elif strategy == "cheap":
            if mp >= SPELLS["Fire"]["mp"]:
                cast = "Fire"
        # strategy == "bolt" -> cast stays None
        if cast is None:                              # the free, always-on, single-target bolt
            total += mdmg(bolt_sp, ma); t += 1; continue
        s = SPELLS[cast]; mp -= s["mp"]
        c = charge if s["aoe"] else 0
        if c == 0:
            total += mdmg(s["sp"], ma) * (cluster if s["aoe"] else 1); t += 1
        else:
            charging = (cast, c); t += 1              # this turn = first 0-dmg charge turn
    return total

def mp_optimal(turns, pool, trickle, ma, bolt_sp, top, charge, cluster=1):
    b = battle(turns, pool, trickle, ma, bolt_sp, top, charge, cluster, "burst")
    c = battle(turns, pool, trickle, ma, bolt_sp, top, charge, cluster, "cheap")
    return max(b, c), ("burst" if b >= c else "cheap"), b, c

def bolt_only(turns, ma, bolt_sp):
    return turns * mdmg(bolt_sp, ma)

# Speed -> turns (FFT CT; from sim_speed, reimplemented). ticks=100 => turns == speed.
def turns_per_window(speed, ticks=100):
    ct = 0; turns = 0
    for _ in range(ticks):
        ct += speed
        if ct >= 100: ct -= 100; turns += 1
    return turns

# phases: (label, ma, pool, trickle, top_spell)
PHASES = [("early", 10, 40, 2, "Fire"), ("mid", 16, 80, 2, "Fira"), ("late", 22, 120, 3, "Firaga")]
BOLT_BASE, CHG_BASE, T_BATTLE = 0.8, 1, 10

# ==============================================================================================
if __name__ == "__main__":
    print("="*94)
    print("sim_confront_tempo — P9: free-bolt vs MP relevance (M5), caster Speed tempo (S3),")
    print("                     charge as the only brake (MR-8). Built to FALSIFY both claims.")
    print("="*94)
    print(f"reuse: G_m={G_M}, fighter/turn leather={F_LEATHER:.0f} plate={F_PLATE:.0f}; "
          f"base bolt_sp={BOLT_BASE}, base charge={CHG_BASE}, battle={T_BATTLE} turns")

    # ------------------------------------------------------------------------------------------
    print("\n" + "="*94)
    print("SUB-TEST 1 — BOLT FLOOR vs MP RELEVANCE (M5).  single-target sustained pressure.")
    print("  ratio = (bolt-only total) / (best MP strategy total). HIGH ratio => MP is a weak gate.")
    print("="*94)
    print(f"  {'phase':5} {'top':7} | {'bolt-only':>9} {'mp-best':>8} {'(strat)':>7} | "
          f"{'ratio':>6} | {'MP gain x':>9}")
    print("  " + "-"*72)
    for lbl, ma, pool, trick, top in PHASES:
        bo = bolt_only(T_BATTLE, ma, BOLT_BASE)
        best, strat, _, _ = mp_optimal(T_BATTLE, pool, trick, ma, BOLT_BASE, top, CHG_BASE)
        print(f"  {lbl:5} {top:7} | {bo:9.0f} {best:8.0f} {strat:>7} | "
              f"{bo/best:6.0%} | {best/bo:8.2f}x")
    print("  READ: ratio is the share of a mage's single-target output the FREE bolt already covers.")
    print("        'MP gain x' = how much the whole MP budget multiplies single-target damage.")

    print("\n  [1-sweep A] bolt_sp (the load-bearing knob), mid phase, charge=1:")
    print(f"     {'bolt_sp':>7} | {'bolt-only':>9} {'mp-best':>8} {'ratio':>6} | "
          f"{'bolt vs ftr-leather':>19} {'vs plate':>9}")
    for bsp in (0.5, 0.65, 0.8, 1.0):
        ma, pool, trick, top = 16, 80, 2, "Fira"
        bo = bolt_only(T_BATTLE, ma, bsp)
        best, *_ = mp_optimal(T_BATTLE, pool, trick, ma, bsp, top, CHG_BASE)
        bolt_pt = mdmg(bsp, ma)
        print(f"     {bsp:7.2f} | {bo:9.0f} {best:8.0f} {bo/best:6.0%} | "
              f"{bolt_pt/F_LEATHER:18.0%} {bolt_pt/F_PLATE:9.0%}")
    print("     (depleted-mage dead-weight check: bolt vs fighter. ~30%+ vs leather AND >=100% vs")
    print("      plate = a real action; that same strength is what raises the MP-irrelevance ratio.)")

    print("\n  [1-sweep B] MP pool (mid, Fira, bolt_sp 0.8, charge 1) — does a bigger budget bite?")
    print(f"     {'pool':>5} {'trick':>6} | {'bolt-only':>9} {'mp-best':>8} {'ratio':>6} {'MP gain x':>9}")
    for pool, trick in ((40,2),(80,2),(120,2),(120,4)):
        bo = bolt_only(T_BATTLE, 16, 0.8)
        best, *_ = mp_optimal(T_BATTLE, pool, trick, 16, 0.8, "Fira", CHG_BASE)
        print(f"     {pool:5} {trick:6} | {bo:9.0f} {best:8.0f} {bo/best:6.0%} {best/bo:8.2f}x")

    # ------------------------------------------------------------------------------------------
    print("\n" + "="*94)
    print("SUB-TEST 2 — CASTER SPEED TEMPO (S3).  Does a fast caster get STRICTLY MORE from Speed")
    print("  than a fighter? Speed=turns only (Dodge decoupled). Caster bursts are MP-capped, so")
    print("  Speed's extra turns fall to the BOLT floor; every fighter turn is a full attack.")
    print("="*94)
    SLOW, FAST = 6, 12     # Speed 6 vs 12 -> turns_per_window(.,100) = 6 vs 12 turns (2.0x)
    ma, pool, trick = 16, 80, 2
    print(f"  turns: Speed{SLOW}->{turns_per_window(SLOW)}  Speed{FAST}->{turns_per_window(FAST)} "
          f"(2.0x actions, linear). fighter is the 2.0x reference.\n")
    print(f"  {'unit':30} {'slow(Spd6)':>11} {'fast(Spd12)':>12} {'fast/slow':>10} {'Δ/extra-turn':>13}")
    print("  " + "-"*80)
    def row(name, slow, fast):
        dpt = (fast-slow)/(FAST-SLOW)
        print(f"  {name:30} {slow:11.0f} {fast:12.0f} {fast/slow:9.2f}x {dpt:12.1f}")
    row("fighter vs leather (reference)", SLOW*F_LEATHER, FAST*F_LEATHER)
    row("fighter vs plate", SLOW*F_PLATE, FAST*F_PLATE)
    # caster, cheap nuke (Fira 18MP) = TIME-bound: pool funds a spell every slot -> Speed = 2.0x
    cf_s = battle(SLOW, pool, trick, ma, 0.8, "Fira", CHG_BASE, 1, "burst")
    cf_f = battle(FAST, pool, trick, ma, 0.8, "Fira", CHG_BASE, 1, "burst")
    row("caster Fira (cheap, time-bound)", cf_s, cf_f)
    # caster, expensive nuke (Firaga 30MP) = MP-bound: pool caps bursts -> extra turns are bolts
    cg_s = battle(SLOW, pool, trick, ma, 0.8, "Firaga", CHG_BASE, 1, "burst")
    cg_f = battle(FAST, pool, trick, ma, 0.8, "Firaga", CHG_BASE, 1, "burst")
    row("caster Firaga (exp., MP-bound)", cg_s, cg_f)
    cg_s3 = battle(SLOW, pool, trick, ma, 0.8, "Firaga", CHG_BASE, 3, "burst")
    cg_f3 = battle(FAST, pool, trick, ma, 0.8, "Firaga", CHG_BASE, 3, "burst")
    row("caster Firaga AoE x3 cluster", cg_s3, cg_f3)
    print("  READ: caster fast/slow is EQUAL to the fighter (cheap/time-bound nuke) or LESS (expensive/")
    print("        MP-bound nuke: extra turns fall to the weak bolt) — never STRICTLY MORE. The MP")
    print("        budget caps burst-tempo, so Speed can't re-import as pure-upside on the magic axis.")
    print("        AoE x3 lifts the LEVEL, not the SLOPE (extra turns are single-target bolts).")

    print("\n  [2-sweep] what would FLIP the MP-bound caster (Firaga) toward/past the fighter's 2.0x?")
    print(f"     {'knob':30} {'caster fast/slow':>16}")
    for desc, kw in [
        ("base (bolt0.8, pool80, tr2)",  dict(bolt_sp=0.8, pool=80,  trickle=2)),
        ("strong bolt 1.0",              dict(bolt_sp=1.0, pool=80,  trickle=2)),
        ("fighter-tier bolt 1.9",        dict(bolt_sp=1.9, pool=80,  trickle=2)),
        ("fat pool 200",                 dict(bolt_sp=0.8, pool=200, trickle=2)),
        ("fat trickle 16",               dict(bolt_sp=0.8, pool=80,  trickle=16)),
    ]:
        s = battle(SLOW, kw["pool"], kw["trickle"], ma, kw["bolt_sp"], "Firaga", CHG_BASE, 1, "burst")
        f = battle(FAST, kw["pool"], kw["trickle"], ma, kw["bolt_sp"], "Firaga", CHG_BASE, 1, "burst")
        print(f"     {desc:30} {f/s:15.2f}x")
    print("     (Caster Speed only reaches/exceeds the fighter's 2.0x if the bolt is fighter-tier, OR")
    print("      pool/trickle is fat enough that extra turns buy extra BURSTS — the SAME knobs as")
    print("      sub-test 1. A bigger pool RAISES the slope: more MP to spend over more Speed-turns.)")

    # ------------------------------------------------------------------------------------------
    print("\n" + "="*94)
    print("SUB-TEST 3 — CHARGE AS THE ONLY BRAKE (MR-8).  charge in {0,1,2}; how fragile is P9?")
    print("="*94)
    for lbl, ma, pool, trick, top in [("mid", 16, 80, 2, "Firaga"), ("late", 22, 120, 3, "Firaga")]:
        bolt_pt = mdmg(0.8, ma)
        print(f"\n  [{lbl}] top={top}, MA={ma}, pool={pool}; bolt={bolt_pt:.0f}/turn, "
              f"fighter-leather={F_LEATHER:.0f}/turn")
        print(f"     {'charge':>6} {'nuke/turn':>9} {'nuke/bolt':>9} {'mage total':>10} "
              f"{'mage/ftr-leath':>14} {'mage/ftr-plate':>14}")
        nuke_full = mdmg(SPELLS[top]["sp"], ma)
        for chg in (0, 1, 2):
            nuke_pt = nuke_full / (1 + chg)
            mt = battle(T_BATTLE, pool, trick, ma, 0.8, top, chg, cluster=1, strategy="burst")
            print(f"     {chg:6} {nuke_pt:9.0f} {nuke_pt/bolt_pt:8.2f}x {mt:10.0f} "
                  f"{mt/(F_LEATHER*T_BATTLE):13.0%} {mt/(F_PLATE*T_BATTLE):14.0%}")
    print("\n  [3-scorecard] action-economy at charge=0 (mid, Firaga) — 'strictly best in game?'")
    ma = 16; nuke = mdmg(3.0, ma); bolt = mdmg(0.8, ma)
    print(f"     free bolt:   {bolt:.0f}/turn, range 3, DR-ignoring, 0 MP, every turn (no other class")
    print( "                  has a free always-on ranged DR-ignoring action)")
    print(f"     nuke @c=0:   {nuke:.0f} in ONE turn, range 3, AoE->x N, DR-ignoring, no telegraph")
    print(f"                  fighter needs {nuke/F_LEATHER:.1f} melee turns + exposure to match one nuke vs leather,")
    print(f"                  {nuke/F_PLATE:.1f} turns vs plate — and only single-target.")
    print( "     => at charge=0 magic's action economy is STRICTLY best-in-game (instant+ranged+AoE+")
    print( "        DR-bypass, over a free floor). charge>=1 is the ONLY thing buying a telegraph turn.")
    print( "     => P9-magic is HIGHLY sensitive to this one unset knob: c0 breaks, c1 borderline")
    print( "        (rests entirely on the telegraph being punishable — M6/P10, unscored here), c2 safe.")

    print("\n" + "="*94)
    print("NEEDLE — the three sub-tests are one tension on ONE knob (bolt power) + charge:")
    print("  a strong/free bolt makes the mage heroic (never dead weight) BUT weakens the MP gate (1)")
    print("  and could re-couple Speed to high-value output (2); low charge makes the nuke best-in-game (3).")
    print("  Healthy window (from the sweeps): bolt_sp ~0.6-0.8 (real action, ~33-43% of a soft-target")
    print("  fighter, >=100% vs plate, MP still ~1.5-1.9x late) AND charge>=1 on damage nukes.")
    print("="*94)

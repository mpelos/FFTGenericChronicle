# sim_confront_tempo — read (P9 action economy: bolt vs MP (M5), caster Speed (S3), charge (MR-8))

**Question.** Two P9 claims, tried to break, honest both ways:
(a) the free always-on weapon-bolt does NOT make MP irrelevant (M5);
(b) Speed does not give a caster a degenerate pure-upside tempo (S3 / re-importing Speed-stacking on
the magic axis). Plus (c) charge time is the only unset action-economy brake on big spells — how
fragile is P9 to it (MR-8)?

**Model.** Reuses `sim_magic_economy` (dmg = MA·spell_power·G_m, flat vs armor; fighter 90 leather /
37.5 plate; G_m 3; tiers bolt .8 / Fire 1.0 / Fira 1.8 / Firaga 3.0) and `sim_speed`'s FFT CT
(turns ∝ Speed). **Post-fix Speed = turn-frequency only** (Dodge decoupled, reg. 04.6/B1); a caster
has no depleting guard, a fighter's only Speed-defense is the *situational* guard-refresh — modelled
as **0** (conservative: it can only widen the fighter's Speed value, never the caster's).

**Axes crossed:** action-economy (Speed/CT/charge) × magic-economy (MP budget + bolt floor) × AoE
(N-for-1). **Held neutral / skipped:** Faith band, Zodiac/element, Magic-Evade *landing* (assume the
design's common case — un-invested target, magic lands, 11.36), Shell, healing, status/CC,
robe-fragility & rush-the-caster (M6/P10), interrupt. The per-turn **safety asymmetry** (caster bolts
from range 3 with no counter/exposure; a fighter must enter melee) is noted but **not damage-scored** —
it is a real caster edge that lives *outside* the Speed/MP tempo axis this sim isolates.

Placeholders FIXED then SWEPT: bolt_sp {0.5/0.65/**0.8**/1.0}, charge {0/**1**/2}, pool {40/**80**/120},
trickle {**2**/4/8/16}, cluster {**1**/2/3}; phases early/mid/late = which top spell is online (the
bolt÷spell ratio is **MA-independent** — MA cancels — so phases differ by tier+pool, not MA).

---

## Sub-test 1 — does the free bolt make MP irrelevant? → **REVISE (claim needs a qualifier)**

Single-target **sustained** output. ratio = (bolt-only total) / (best MP strategy); high ratio = weak gate.

| phase | top spell | bolt-only | MP-best | **bolt share** | MP multiplies single-target by |
|---|---|--:|--:|--:|--:|
| early | Fire | 240 | 282 | **85%** | 1.18× |
| mid | Fira | 384 | 480 | **80%** | 1.25× |
| late | Firaga | 528 | 924 | **57%** | 1.75× |

The free bolt already delivers **57–85%** of a mage's single-target output, and the *entire* MP budget
multiplies sustained single-target damage by only **1.18–1.75×**. For sustained single-target *chip*,
**MP is a weak gate, and its relevance is back-loaded to the Firaga tier** (early/mid magic is
bolt-dominated). The claim "the bolt doesn't make MP irrelevant" holds **only if MP's value is counted
as burst-timing + AoE + element exploitation** (the other layers) — *not* as sustained single-target
pressure, where the bolt does most of the work.

Sensitivity (mid): bolt_sp 0.5→0.65→0.8→1.0 gives ratio **50%→65%→80%→100%**; but at bolt_sp 0.5 the
depleted mage is only **27%** of a leather-fighter (re-opens the dead-weight / un-heroic failure), and
at 0.8 it is 43% leather / **102% plate** (a real anti-armor action). Pool 40→120 barely moves the mid
ratio (80–85%) — mid isn't MP-bound; only the Firaga tier is.

**What would flip this to a clean HOLD:** a damage nuke whose *per-turn* value stays ≥ ~1.5× the bolt
**across all phases** (not just late), so MP buys real sustained pressure early too — OR accept by
design that early/mid magic is bolt-floored and MP's teeth are explicitly AoE/burst/element. Dropping
bolt_sp to make MP bite (ratio→50%) re-opens the dead-weight failure — the two are the same knob.

## Sub-test 2 — degenerate caster Speed tempo? → **HOLDS (refuted)**

Speed 6 vs 12 = 2.0× turns. Fighter is the 2.0× reference (every turn a full attack).

| unit | slow | fast | **fast/slow** | Δ/extra-turn |
|---|--:|--:|--:|--:|
| fighter vs leather (ref) | 540 | 1080 | **2.00×** | 90.0 |
| caster Fira (cheap, time-bound) | 259 | 518 | **2.00×** | 43.2 |
| caster Firaga (expensive, MP-bound) | 432 | 672 | **1.56×** | 40.0 |
| caster Firaga AoE ×3 | 1296 | 1536 | **1.19×** | 40.0 |

A fast caster's Speed-slope is **equal to** the fighter's (cheap/time-bound nuke) or **below** it
(expensive/MP-bound nuke) — **never strictly more.** Mechanism: the MP budget caps burst count, so a
caster's *extra* Speed-turns fall to the weak bolt floor (40/turn) while every fighter turn is a full
attack (90). AoE ×3 lifts the **level** massively (1296) but flattens the **slope** to 1.19× — Speed is
the *worst* buy for an AoE-bound, MP-capped caster (it only stacks single-target bolts on an
already-spent burst budget). Add the fighter's unscored guard-refresh and the fighter's Speed edge only
grows. **The "Speed-stacking re-imported on the magic axis" fear is inverted: Speed is a weaker buy for
a caster than for a fighter.**

**What would flip this:** a fighter-tier bolt (sp 1.9 → 2.17×) or a fat pool/trickle (pool 200 or
trickle 16 → 2.0×) — i.e. extra Speed-turns must buy extra *bursts* or *fighter-weight bolts*. Same
load-bearing knobs as sub-test 1.

## Sub-test 3 — charge as the only brake → **BREAK at charge=0; HOLDS at charge≥1, comfortable at 2**

mid (Firaga, MA16) and late (MA22), per-turn nuke vs the 38–53 bolt:

| charge | nuke/turn | **nuke/bolt** | mid total (vs ftr-leather / plate) | late total (vs ftr-leather / plate) |
|--:|--:|--:|--|--|
| **0** | 144 / 198 | **3.75×** | 643 (**71%** / 172%) | 1148 (**128%** / 306%) |
| 1 | 72 / 99 | 1.87× | 595 (66% / 159%) | 924 (103% / 246%) |
| 2 | 48 / 66 | 1.25× | 480 (53% / 128%) | 660 (73% / 176%) |

**P9-magic is highly sensitive to this one unset knob.** At **charge=0** the nuke is 3.75× the bolt
*per turn*, instant, range 3, AoE (×N), DR-ignoring — over a free always-on bolt floor. A fighter needs
1.6 melee turns + exposure to match one nuke vs leather (3.8 vs plate), single-target only; the late
mage hits **128% of a fighter on soft targets AND 306% vs plate AND safely AND in an AoE.** That is
**strictly best-in-game action economy → P9 breaks.** charge≥1 is the *only* thing that buys a
telegraph turn; at charge=2 the nuke's sustained value collapses to 1.25× the bolt (MP buys
burst-timing/AoE, not sustained pressure) and the soft-target total drops below a fighter (53–73%).

**What would flip / settle this:** lock **charge ≥ 1 on all damage nukes** AND verify the telegraph
turn is actually punishable by the AI (interrupt / rush the fragile caster — M6/P10, **unscored here**).
charge=1 is *borderline* and rests entirely on that telegraph being exploitable; charge=2 is robust on
the tempo axis alone.

---

## The needle (why the three sub-tests are one problem)

All three pivot on **two knobs — bolt power and charge:**
- A **strong/free bolt** makes the mage heroic (never dead weight, anti-armor floor) **but** weakens
  the MP gate (sub-1) and, if pushed to fighter-tier, re-couples Speed to high-value output (sub-2).
- **Low charge** makes the nuke best-in-game (sub-3).

**Healthy window from the sweeps:** bolt_sp ≈ **0.6–0.8** (a real action — 33–43% of a soft-target
fighter, ≥100% vs plate — while MP still gains 1.5–1.9× at the Firaga tier) **AND** charge ≥ 1 on
damage nukes. Inside that window: M5 holds *with the qualifier* (MP's teeth are burst/AoE/element, not
single-target chip), S3 holds (caster Speed ≤ fighter Speed), and the charge brake holds. **Outside it
(bolt fighter-tier, or charge=0) all three fail together.**

## Honest lean
- **M5 (bolt vs MP):** REVISE — for sustained single-target the bolt covers 57–85% and MP is a weak,
  back-loaded gate; the claim is true only when MP's value is read as AoE/burst/element.
- **S3 (caster Speed):** HOLDS — degenerate caster tempo refuted; Speed is a *weaker* buy for a caster
  than a fighter because the MP budget caps burst-tempo.
- **MR-8 (charge):** BREAK at charge=0 (magic action economy strictly best-in-game), HOLDS at
  charge≥1, comfortable at charge=2 — and P9-magic is currently **undecidable** while charge is unset.

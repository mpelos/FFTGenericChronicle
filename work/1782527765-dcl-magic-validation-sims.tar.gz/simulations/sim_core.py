#!/usr/bin/env python3
"""
DCL core combat simulation — built to FALSIFY, not confirm.

Encodes the deterministic damage pipeline (doc 02), damage types/armor (03),
and the 3d6 hit/defense contest (04). The MECHANISM is faithful to the docs;
the NUMBERS are open calibration (doc 12) and are declared in CONFIG with the
rationale for each placeholder, then varied in a sensitivity sweep so that no
single magic value is allowed to drive a conclusion.

Run:  python3 sim_core.py
Output is ground truth; the prose read lives in the .md alongside.
"""

from itertools import product

# ----------------------------------------------------------------------------
# 3d6 distribution (exact)
# ----------------------------------------------------------------------------
def p_le(n):
    """P(3d6 <= n)."""
    if n < 3: return 0.0
    if n > 18: return 1.0
    c = sum(1 for a in range(1,7) for b in range(1,7) for d in range(1,7) if a+b+d <= n)
    return c / 216.0

# crit = nat 3/4 always; 5 if skill>=15; 6 if skill>=16  (doc 04)
def p_crit(skill):
    ways = 0
    # count 3d6 combos summing to each natural total
    from collections import Counter
    tot = Counter(a+b+d for a in range(1,7) for b in range(1,7) for d in range(1,7))
    crit_totals = {3,4}
    if skill >= 15: crit_totals.add(5)
    if skill >= 16: crit_totals.add(6)
    return sum(tot[t] for t in crit_totals)/216.0

# fumble = nat 18 always; 17 if skill<=15
def p_fumble(skill):
    from collections import Counter
    tot = Counter(a+b+d for a in range(1,7) for b in range(1,7) for d in range(1,7))
    f = tot[18]
    if skill <= 15: f += tot[17]
    return f/216.0

# ----------------------------------------------------------------------------
# CONFIG — placeholder numbers (each justified; swept below)
# ----------------------------------------------------------------------------
CONFIG = {
    # base(PA): strength damage number, TYPE-INDEPENDENT (doc 02). One number from PA.
    # GURPS swing-avg of ST=PA+offset. We model base(PA) ~ linear in PA.
    "pa_offset": 4,          # ST = PA + 4 (doc 02-09), open knob
    "base_slope": 1.0,       # base(PA) = base_slope*(ST-6) clamped>=1  (GURPS-swing-ish)
    # wmod tiers (flat additive). baixo/medio/alto/muito_alto. Open (doc 12).
    "wmod": {"baixo":2, "medio":5, "alto":9, "muito_alto":14},
    "crush_wmod_mult": 1.5,  # crush carries ~1.5x wmod (doc 03-07)
    # wound multipliers (doc 03) — these are FIXED design, not calibration
    "wound": {"cut":1.5, "thrust":2.0, "crush":1.0, "missile":1.0},
    # subtractive DR by armor class x type (doc 03 full-plate rule). Open numbers.
    # plate: high cut/thrust, low crush. leather/robe: thin all. mail: middling.
    "DR": {
        "plate":   {"cut":10, "thrust":8, "crush":3, "missile":9},
        "mail":    {"cut":6,  "thrust":5, "crush":4, "missile":5},
        "leather": {"cut":3,  "thrust":3, "crush":2, "missile":3},
        "robe":    {"cut":1,  "thrust":1, "crush":1, "missile":1},
    },
    "armor_divisor": {"none":1.0, "bow":1.0, "crossbow":1.5, "gun":2.0},  # divides DR (doc 03-12)
    "pen_floor_frac": 0.20,  # 15-33% of raw always lands (doc 02-08)
    "G": 1.0,                # global scalar; irrelevant to RATIOS, set 1 for readability
    # Brave offense multiplier range (doc 07-17). APPLICATION POINT is ambiguous (DB-Brave-app):
    #   'raw'  -> scales [base+wmod] BEFORE DR (high Brave helps punch armor)
    #   'final'-> scales injury AFTER everything (high Brave doesn't help vs DR)
    "brave_off": {"low":0.76, "mid":1.0, "high":1.56},
    "brave_apply": "raw",
}

# ----------------------------------------------------------------------------
# Damage pipeline (doc 02 model d)
# ----------------------------------------------------------------------------
def base_pa(pa, cfg):
    st = pa + cfg["pa_offset"]
    return max(1.0, cfg["base_slope"] * (st - 6))

def injury(pa, wmod, dtype, armor_class, cfg, brave="mid", divisor="none"):
    raw = base_pa(pa, cfg) + wmod
    if cfg["brave_apply"] == "raw":
        raw *= cfg["brave_off"][brave]
    dr = cfg["DR"][armor_class][dtype] / cfg["armor_divisor"][divisor]
    post = max(0.0, raw - dr)
    floored = max(cfg["pen_floor_frac"] * raw, post)
    out = floored * cfg["wound"][dtype] * cfg["G"]
    if cfg["brave_apply"] == "final":
        out *= cfg["brave_off"][brave]
    return out

# ----------------------------------------------------------------------------
# Hit/defense landing probability (doc 04)
# land = hit AND (crit OR not-defended); crit bypasses defense
# ----------------------------------------------------------------------------
def p_land(skill, defense, facing="front"):
    if facing == "back":
        defense_eff = -99           # no defense roll
    elif facing == "side":
        defense_eff = defense - 2
    else:
        defense_eff = defense
    ph = p_le(skill)
    pc = p_crit(skill)
    pdef = p_le(defense_eff)
    # P(land) = P(hit & crit) + P(hit & not crit & not defended)
    # crit requires a hit (crit totals <= skill always since skill>=9). So:
    p_hit_noncrit = max(0.0, ph - pc)
    return pc + p_hit_noncrit * (1 - pdef)

# ============================================================================
# TESTS
# ============================================================================
def test_chip_zero(cfg):
    """Weakest weapon vs heaviest armor must be >0 but not too generous."""
    print("\n[CHIP-ZERO] weak cutting (baixo wmod, low PA) vs plate")
    for pa in (5, 8, 12):
        dmg = injury(pa, cfg["wmod"]["baixo"], "cut", "plate", cfg)
        post = max(0.0, base_pa(pa,cfg)+cfg["wmod"]["baixo"] - cfg["DR"]["plate"]["cut"])
        print(f"  PA{pa}: injury={dmg:.1f}  (post-DR before floor/mult={post:.1f})  -> floor active={post < cfg['pen_floor_frac']*(base_pa(pa,cfg)+cfg['wmod']['baixo'])}")

def test_sharpness(cfg):
    """Right tool ~+35% over neutral; wrong tool ~2x tankier (you do ~half). doc 03-14"""
    print("\n[SHARPNESS] vs PLATE, PA10, alto-tier weapons (crush gets 1.5x wmod)")
    pa = 10
    w = cfg["wmod"]["alto"]
    wc = w * cfg["crush_wmod_mult"]
    d_cut    = injury(pa, w,  "cut",     "plate", cfg)
    d_thrust = injury(pa, w,  "thrust",  "plate", cfg)
    d_crush  = injury(pa, wc, "crush",   "plate", cfg)
    d_gun    = injury(pa, cfg["wmod"]["medio"], "missile", "plate", cfg, divisor="gun")
    print(f"  cut={d_cut:.1f}  thrust={d_thrust:.1f}  crush={d_crush:.1f}  gun(div2)={d_gun:.1f}")
    print(f"  crush/cut ratio = {d_crush/max(d_cut,0.01):.2f}x  (crush is the right tool vs plate)")
    print("\n[SHARPNESS] vs LEATHER (unarmored-ish), same weapons")
    d_cut_l    = injury(pa, w,  "cut",    "leather", cfg)
    d_crush_l  = injury(pa, wc, "crush",  "leather", cfg)
    print(f"  cut={d_cut_l:.1f}  crush={d_crush_l:.1f}  cut/crush = {d_cut_l/max(d_crush_l,0.01):.2f}x (cut better vs light)")

def test_thrust_vs_swing(cfg):
    """DB11: is thrust (x2) strictly better than swing (x1.5) when base(PA) is weapon-independent?
    Hold wmod EQUAL and compare across armors. If thrust>swing everywhere, swing weapons MUST
    carry higher wmod to compensate — check what compensation is needed."""
    print("\n[THRUST vs SWING] equal wmod (medio), PA10, across armor classes")
    pa = 10; w = cfg["wmod"]["medio"]
    print(f"  {'armor':9} {'swing(x1.5)':>12} {'thrust(x2)':>11} {'thrust/swing':>13}")
    worst = 0
    for ac in ("robe","leather","mail","plate"):
        s = injury(pa, w, "cut", ac, cfg)
        t = injury(pa, w, "thrust", ac, cfg)
        ratio = t/max(s,0.01)
        worst = max(worst, ratio)
        print(f"  {ac:9} {s:12.1f} {t:11.1f} {ratio:13.2f}")
    print(f"  -> thrust dominates by up to {worst:.2f}x at EQUAL wmod. For swing to break even vs thrust,")
    # how much extra wmod does swing need to match thrust on plate?
    ac="plate"; t = injury(pa, w, "thrust", ac, cfg)
    need = w
    while injury(pa, need, "cut", ac, cfg) < t and need < 200:
        need += 0.5
    print(f"     a swing weapon needs wmod≈{need:.1f} (vs thrust's {w}) to match thrust on {ac} — a +{need-w:.1f} wmod tax.")

def test_hit_regimes(cfg):
    """doc 04: open target front >50% (got 55-67%); turtle ~31%."""
    print("\n[HIT REGIMES]")
    # open: skill 12 vs Dodge 8
    print(f"  open (skill12 vs Dodge8) front: {p_land(12,8)*100:.0f}%  [target >50%]")
    print(f"  open skill 13,14: {p_land(13,8)*100:.0f}%, {p_land(14,8)*100:.0f}%")
    # turtle: shield+parry best defense ~ 11; plus crit bypass
    for dfn in (10,11,12):
        print(f"  turtle (skill12 vs best-defense{dfn}) front: {p_land(12,dfn)*100:.0f}%  [target ~31%]")
    # facing
    print(f"  flank skill12 vs def11 (side -2): {p_land(12,11,'side')*100:.0f}%")
    print(f"  back  skill12 vs def11 (no defense): {p_land(12,11,'back')*100:.0f}%")
    print(f"  crit floor (skill16, any defense, front): {p_crit(16)*100:.1f}% always bypasses")

def sweep():
    """Sensitivity: vary the open knobs and re-check the thrust-vs-swing conclusion
    and sharpness. If conclusions hold across the sweep, numbers didn't drive them."""
    print("\n================ SENSITIVITY SWEEP ================")
    base = dict(CONFIG)
    print("\n[SWEEP] thrust/swing plate-ratio at equal medio wmod, varying pen_floor & plate cut-DR")
    for pf, cutdr in product((0.15,0.20,0.33),(8,10,12)):
        cfg = {**base, "pen_floor_frac":pf,
               "DR":{**base["DR"], "plate":{**base["DR"]["plate"], "cut":cutdr}}}
        pa=10; w=cfg["wmod"]["medio"]
        s=injury(pa,w,"cut","plate",cfg); t=injury(pa,w,"thrust","plate",cfg)
        print(f"  pen_floor={pf:.2f} plate_cutDR={cutdr}: swing={s:.1f} thrust={t:.1f} ratio={t/max(s,0.01):.2f}")

if __name__ == "__main__":
    cfg = CONFIG
    print("DCL core sim — CONFIG placeholders (open calibration, swept below)")
    test_chip_zero(cfg)
    test_sharpness(cfg)
    test_thrust_vs_swing(cfg)
    test_hit_regimes(cfg)
    sweep()

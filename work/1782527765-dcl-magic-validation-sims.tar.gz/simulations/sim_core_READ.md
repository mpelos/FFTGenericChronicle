# sim_core.py — read (2026-06-26)

Setup: deterministic pipeline (doc 02) + 3d6 hit/defense (04) + type/armor DR (03). Placeholder
constants documented in `CONFIG`, varied in a sensitivity sweep. Script output is ground truth.

## Findings

### ✅ Hit/defense two-regime design HOLDS (D04-18/19/20, D05-3/4)
- Open target, skill 12 vs Dodge 8, front = **55%** (skill 13/14 → 63/68%). Target ">50%" ✓.
- Turtle, skill 12 vs best-defense 11 (shield+parry) = **29%**. Target "~31%" ✓ (def 10 → 38%, def 12 → 21%).
- Flank (side −2) vs def 11 = **47%** (big jump from 29 — the lever works). Back (no defense) = **74%**.
- Crit-floor at skill 16 = **9.3%** always bypasses defense — the un-turtle-able pressure, as designed.
- **Verdict:** the core contest math is sound and tunable to the stated regimes. Not fragile (regimes hold across defense 10–12).

### ✅ Chip-zero tamed, not over-generous (D02-8)
- Weak cutting (baixo wmod) vs plate: PA5→1.5, PA8→2.4, PA12→3.6. pen_floor active, >0, small. ✓

### ✅ Sharpness roughly on target (D03-14), with one caveat
- vs plate: crush 18.5 / cut 10.5 = **1.76×** (cut does ~57% of crush ≈ "wrong tool ~2× tankier" ✓). vs leather cut≈crush (1.08×). Tunable to +35%/2×.
- **Caveat:** thrust vs plate = 18.0 ≈ crush 18.5. Thrust is nearly as good an anti-plate tool as crush → erodes crush's "the tool vs plate" identity (feeds DB11).

### ⚠️ DB11 CONFIRMED — thrust (×2) ≥ swing (×1.5), strictly, at equal wmod
- thrust/swing ratio: robe/leather **1.33×**, mail **1.52×**, plate **2.22×** — thrust is never worse, and the edge WIDENS through subtractive DR (plate resists cut more than thrust).
- Holds across the full sweep (pen_floor 0.15–0.33 × plate cut-DR 8–12 → ratio 1.33–3.42, never ≤1).
- For a swing weapon to merely *match* thrust on plate at médio tier, it needs **+4 wmod** (≈ double) — i.e. swing must jump a full tier to break even.
- **Root cause:** the stated type principle (D03-2/3/8) gives thrust the highest multiplier but specifies NO offsetting cost (it lumps cutting+impaling as "small wmod, big ×"). Nothing in the *rules* stops a high-wmod thrust weapon from being strictly best.
- **Roster mitigation (must be sim-confirmed):** thrust is currently rationed to the Knife (baixo wmod, low parry, finisher) and Spear (2H, reach-2 with point-blank weakness, médio wmod). Swing owns parry (Sword/Katana best), 1H-flexibility, and top raw (Knight Sword). So at the ROSTER level P1′ may hold — but the **Spear (thrust+reach-2, médio wmod) vs Sword (swing+parry, médio wmod, 1H)** comparison is the stress case: Spear does ~1.33× damage AND outranges; its only offsets are 2H/point-blank/lower-parry. Needs the full-kit weapon-matchup sim (accuracy + parry + reach + hands).

## Implications for Phase D
- D04 hit/defense regimes, D02-8 pen_floor, D03-14 sharpness → trending HOLD (sim-backed), pending full-kit confirmation.
- **D03-2/3/8 (type principle) → REVISE candidate:** add an explicit rule that thrust is rationed (lower wmod than same-class swing, or an accuracy/availability cost), mirroring crush's stated 1.5× wmod. Otherwise latent strictly-better trap.
- Next sims: full-kit weapon matchup (Spear vs Sword, Knife vs Ninja Blade, Flail vs Axe), armor triangle, Speed economy (P9), Brave régua, Weight curve.

#!/usr/bin/env python3
"""
sim_magic_economy.py — Q5: the magic cost model (MP budget + a free CANTRIP floor).

Refined Q5 (heroic theme: a mage must be able to use MAGIC the whole battle). Proposal to FALSIFY:
  - MP is a per-battle BUDGET (tight, small trickle) that gates the BIG spells (the bursts).
  - A free, always-available **cantrip** (tier-0 spell, 0 MP, instant) is the mage's true basic attack —
    the OFFENSIVE analogue of the physical Dodge floor. So the mage never runs out of *magic*; worst case
    it is casting the cantrip (weak, but real, and scaling with MA/Faith + ignoring DR).
  - Two sustain paths (the player's choice): spend MP on bursts then fall to the cantrip floor, OR
    stretch MP with cheap spells. Healing is NOT free (no heal-cantrip) so sustain stays meaningful.

Claims to break:
  T1 heroic floor: after MP depletes the mage still casts magic EVERY turn (output never ~0).
  T2 not dead weight: the cantrip floor is a meaningful share of a fighter's turn — and because magic
     ignores DR, the depleted mage is the ANTI-ARMOR chipper (>= fighter vs plate).
  T3 not dominating: mage per-battle total ~ fighter total (trades single-target-vs-soft for front-load
     + anti-armor + AoE), not a runaway.
  T4 MP actually bites: the budget (not just CT) limits the number of bursts.
  Bonus: what G_m balances mage~fighter per battle? (informs the Q2 G_m calibration, still deferred.)
"""

# ---- spells (spell_power tiers; cantrip = tier-0) ----------------------------
SP   = {"cantrip": 0.8, "Fire": 1.0, "Fira": 1.8, "Firaga": 3.0}
COST = {"cantrip": 0,   "Fire": 8,   "Fira": 18,  "Firaga": 30}   # MP
CT   = {"cantrip": 1,   "Fire": 1,   "Fira": 2,   "Firaga": 2}    # turns occupied (1=instant, 2=charge+resolve)

MA   = 16
G_M  = 3.0          # calibrated below so neutral magic ~ fighter (vs the placeholder 8 of earlier sims)
def magic(sp, ma=MA, gm=G_M):   # neutral faith/element; FLAT across armor (ignores DR)
    return ma * SP[sp] * gm

# ---- fighter baseline (physical, from the armor/shape sims) -------------------
def fighter(dr, R=14, wound=1.5, gp=5, pen=0.20):
    return max(pen*R, R-dr) * wound * gp
F_LEATHER = fighter(2)      # 90
F_PLATE   = fighter(9)      # 37.5  (DR collapses the sword)

# ---- battle simulators -------------------------------------------------------
def sim_burst(T, mp_pool, trickle, ma=MA, gm=G_M):
    """Cast the biggest affordable charged spell; when the budget is dry, cantrip every turn."""
    mp = mp_pool; charging = None; trace = []
    t = 0
    while t < T:
        mp += trickle
        if charging is not None:
            trace.append((t, "resolve " + charging, magic(charging, ma, gm), mp)); charging = None; t += 1; continue
        if mp >= COST["Firaga"] and t < T - 1:
            mp -= COST["Firaga"]; charging = "Firaga"; trace.append((t, "charge Firaga", 0.0, mp))
        elif mp >= COST["Fira"] and t < T - 1:
            mp -= COST["Fira"]; charging = "Fira"; trace.append((t, "charge Fira", 0.0, mp))
        else:
            trace.append((t, "cantrip (floor)", magic("cantrip", ma, gm), mp))
        t += 1
    return trace

def sim_cheap(T, mp_pool, trickle, ma=MA, gm=G_M):
    """Stretch MP with the cheap spell; fall to cantrip only when even that is unaffordable."""
    mp = mp_pool; per = []
    for t in range(T):
        mp += trickle
        if mp >= COST["Fire"]:
            mp -= COST["Fire"]; per.append(magic("Fire", ma, gm))
        else:
            per.append(magic("cantrip", ma, gm))
    return per

# ============================================================================
if __name__ == "__main__":
    T, POOL, TRICK = 10, 80, 2
    print("="*84)
    print(f"setup: MA {MA}, G_m {G_M}, battle {T} turns, MP pool {POOL} + trickle {TRICK}/turn "
          f"(total MP {POOL+TRICK*T})")
    print(f"  spell dmg (neutral, flat vs armor): " +
          "  ".join(f"{k}={magic(k):.0f}" for k in SP))
    print(f"  fighter/turn: vs leather {F_LEATHER:.0f}   vs plate {F_PLATE:.0f}")

    print("\n" + "="*84)
    print("PART A — battle trace (burst strategy): does the mage cast MAGIC every turn?")
    print("="*84)
    trace = sim_burst(T, POOL, TRICK)
    print(f"   {'turn':>4} | {'action':>18} | {'dmg':>5} | {'MP':>4}")
    print("   " + "-"*42)
    for t, act, dmg, mp in trace:
        print(f"   {t:>4} | {act:>18} | {dmg:>5.0f} | {mp:>4.0f}")
    n_big = sum(1 for _, a, _, _ in trace if a.startswith("resolve"))
    n_floor = sum(1 for _, a, _, _ in trace if a.startswith("cantrip"))
    zero_turns = sum(1 for _, a, d, _ in trace if d == 0 and not a.startswith("charge"))
    print(f"\n   bursts landed = {n_big}   cantrip-floor turns = {n_floor}   "
          f"idle(non-charge 0-dmg) turns = {zero_turns}")
    print("   the only 0-dmg turns are CHARGE turns (a burst lands next turn); once MP is dry the mage")
    print("   casts the cantrip every turn — never a stick-poke, never idle. (T1)")

    print("\n" + "="*84)
    print("PART B — per-battle totals: mage vs fighter, vs leather AND plate (the role profile)")
    print("="*84)
    mage_total = sum(d for _, _, d, _ in trace)        # flat vs armor
    print(f"   {'':>14} | {'vs leather':>11} | {'vs plate':>10}")
    print("   " + "-"*42)
    print(f"   {'mage (burst)':>14} | {mage_total:>11.0f} | {mage_total:>10.0f}   (flat: ignores DR)")
    print(f"   {'fighter':>14} | {F_LEATHER*T:>11.0f} | {F_PLATE*T:>10.0f}")
    print(f"   {'mage / fighter':>14} | {mage_total/(F_LEATHER*T):>10.0%} | {mage_total/(F_PLATE*T):>9.0%}")
    print("\n   vs soft targets the mage is BELOW a fighter single-target (it trades that for front-loaded")
    print("   burst + AoE, not modelled here); vs plate it is well ABOVE (anti-armor). A distinct role,")
    print("   not a strict win or loss. (T3)")

    print("\n" + "="*84)
    print("PART C — the floor check: is the depleted mage dead weight?")
    print("="*84)
    floor = magic("cantrip")
    print(f"   cantrip (floor) = {floor:.0f}/turn, flat vs any armor")
    print(f"     vs a fighter hitting leather ({F_LEATHER:.0f}): {floor/F_LEATHER:>4.0%}")
    print(f"     vs a fighter hitting plate   ({F_PLATE:.0f}): {floor/F_PLATE:>4.0%}  (>= 100% -> the")
    print("     depleted mage is the anti-PLATE chipper — always a role). (T2)")

    print("\n" + "="*84)
    print("PART D — two sustain paths (the player's choice the user asked for)")
    print("="*84)
    cheap = sim_cheap(T, POOL, TRICK); cheap_total = sum(cheap)
    print(f"   burst-then-floor : total {mage_total:.0f}  (front-loaded: big bursts, then cantrip tail)")
    print(f"   cheap-spell-sustain: total {cheap_total:.0f}  (smooth: a cheap spell most turns)")
    print("   bursting wins on total damage; cheap-sustain is smoother + keeps MP for a clutch moment.")
    print("   Both keep the mage casting magic all battle — the budget shapes STYLE, not on/off. ")

    print("\n" + "="*84)
    print("BONUS — what G_m balances mage ~ fighter per battle? (informs the Q2 G_m calibration)")
    print("="*84)
    print(f"   {'G_m':>4} | {'mage total':>10} | {'vs fighter-leather':>18} | {'Firaga vs plate(200hp)':>22}")
    print("   " + "-"*64)
    for gm in (2.0, 3.0, 4.0, 8.0):
        tr = sim_burst(T, POOL, TRICK, gm=gm); mt = sum(d for _, _, d, _ in tr)
        firaga_plate = magic("Firaga", gm=gm)
        print(f"   {gm:>4.1f} | {mt:>10.0f} | {mt/(F_LEATHER*T):>17.0%} | {firaga_plate:>9.0f} ({firaga_plate/200:>4.0%} of 200hp)")
    print("\n   G_m ~ 3 puts the mage's per-battle total near a fighter's (vs soft) while a single Firaga")
    print("   is ~72% of a plate-tank's HP (a heavy hit, not a one-shot of a tank). The old placeholder")
    print("   8 is way too hot (one-shots everyone — the Q2 finding). This is EVIDENCE toward G_m~3,")
    print("   not a lock (full calibration still deferred; the burst CORNER still bursts squishies, as")
    print("   intended).")

    print("\n" + "="*84)
    print("SENSITIVITY — MP budget, cantrip power, battle length")
    print("="*84)
    print(f"   {'pool':>5} {'trick':>6} {'cantrip_sp':>11} {'T':>3} | {'bursts':>7} {'mage/ftr-leather':>16} {'floor/ftr-leather':>17}")
    print("   " + "-"*70)
    for pool, trick, csp, TT in [(80,2,0.8,10),(60,2,0.8,10),(120,4,0.8,10),(80,2,0.6,10),(80,2,1.0,10),(80,2,0.8,6),(80,2,0.8,16)]:
        SP["cantrip"] = csp
        tr = sim_burst(TT, pool, trick); mt = sum(d for _, _, d, _ in tr)
        nb = sum(1 for _, a, _, _ in tr if a.startswith("resolve"))
        fl = magic("cantrip")
        print(f"   {pool:>5} {trick:>6} {csp:>11.2f} {TT:>3} | {nb:>7} {mt/(F_LEATHER*TT):>15.0%} {fl/F_LEATHER:>16.0%}")
    SP["cantrip"] = 0.8
    print("\n   READ: MP budget controls the number of bursts (60->fewer, 120/trickle4->more) -> MP bites,")
    print("   not just CT (T4). cantrip_sp is the floor knob (0.6=33% / 0.8=43% / 1.0=53% of a soft-target")
    print("   fighter, all >100% vs plate). Longer battles dilute burst toward the floor (the mage tends")
    print("   to its cantrip baseline) — exactly the heroic 'always casting, never dominating' shape.")

    print("\n" + "="*84)
    print("VERDICT: MP-as-battle-budget + a free cantrip floor holds. The mage casts magic every turn")
    print("(heroic), the floor is a real anti-armor contribution (not dead weight), the budget gates")
    print("bursts (not just CT), and totals sit near a fighter's without dominating. Magnitudes (pool,")
    print("trickle, cantrip_sp, G_m) are calibration; the SHAPE — budget + always-on cantrip — stands.")

# sim_magic_economy — read (Q5: MP budget + the cantrip floor)

**Question.** How is casting paid for, such that the Q4-bounded burst (~2.2×) is gated to a fair
*frequency* — **without** the heroic-theme failure of a depleted mage becoming dead weight? Proposal to
falsify: MP is a **per-battle budget** gating the **big spells**, over a free always-available
**cantrip** (tier-0, 0 MP, instant) = the mage's true basic attack (the offensive analogue of the
physical Dodge floor). Provisional: MA 16, G_m 3, pool 80 + trickle 2, cantrip `spell_power` 0.8.

## T1 — heroic floor: the mage casts magic every turn  → CONFIRMED

Battle trace (burst strategy, 10 turns): 3 Firagas (turns 0–5, charge+resolve), then **cantrip every
remaining turn** (38 dmg). The *only* zero-output turns are **charge** turns; once MP is dry the mage is
still casting magic, never poking with a staff, never idle.

## T2 — the floor is not dead weight (it's the anti-armor chipper)  → CONFIRMED

cantrip = 38/turn, **flat vs any armor** (magic ignores DR):

| vs a fighter hitting… | fighter/turn | cantrip as % |
|---|---:|---:|
| leather | 90 | 43% |
| plate | 38 | **102%** |

So even fully depleted the mage is ~43% of a fighter against soft targets and **matches-or-beats** one
against plate — a distinct anti-armor role, not a wasted turn.

## T3 — not dominating  → CONFIRMED

Mage per-battle total (586) = **65% of a fighter vs leather**, **156% vs plate**. The mage trades
single-target-vs-soft damage for front-loaded burst + anti-armor + AoE (AoE not even modeled here, which
would push the mage up in group fights). A distinct role, not a strict win or loss.

## T4 — MP actually bites (not just CT)  → CONFIRMED

The budget allows **3** Firagas (90 MP of a 100 total); CT alone would allow 5. Sweep: pool 60 → fewer
bursts, pool 120/trickle 4 → 5. So the *resource* is a real throttle, independent of the *time* throttle.

## Two sustain paths (the player choice the directive asked for)

- **Burst then floor:** total 586, front-loaded (kill key targets, then cantrip tail).
- **Cheap-spell sustain:** total 480, smooth (a cheap Fire most turns, save a burst for a clutch moment).

Both keep the mage casting magic all battle; the budget shapes **style**, not on/off.

## Bonus — evidence toward the Q2 `G_m`

| G_m | mage total | vs fighter-leather | Firaga vs plate (200 HP) |
|---:|---:|---:|---:|
| 2 | 390 | 43% | 48% |
| **3** | **586** | **65%** | **72%** |
| 4 | 781 | 87% | 96% |
| 8 (old placeholder) | 1562 | 174% | 192% (one-shot) |

**G_m ≈ 3** balances the mage's per-battle total near a fighter's while a single Firaga is ~72% of a
plate-tank's HP — a heavy hit, *not* a one-shot of a tank. The placeholder 8 (used in the shape/stack
sims to surface the one-shot risk) is far too hot. This is **evidence toward G_m ≈ 3**, not a lock —
full calibration is deferred, and the burst *corner* (faith×weakness) still bursts squishies, as
intended.

## Sensitivity

MP budget controls burst count (T4); `cantrip_sp` is the floor knob (0.6 = 33% / 0.8 = 43% / 1.0 = 53%
of a soft-target fighter, all > 100% vs plate); longer battles dilute the burst toward the cantrip
baseline (the heroic "always casting, never dominating" shape). Structure holds across the sweep.

## Verdict

**Adopt** MP-as-per-battle-budget + a free always-on cantrip floor. Heroic (magic all battle), the floor
is a real anti-armor contribution, the budget gates bursts, totals sit near a fighter's. Recorded in
`11` (*The magic economy*), `12`. Magnitudes (pool, trickle, cantrip_sp, G_m≈3) are calibration.

## Open sub-decisions

- Is the cantrip **per-element** (carries a Zodiac element) or a **neutral arcane bolt**? (per-element =
  respects the mage's identity + Zodiac interplay; neutral = simplest, dodges the resist game on the
  free action).
- **Healing has no free floor** (recommended): the cantrip is damage/utility only; restoration stays
  MP-gated so a healer's sustain is a real budget.

## What would flip this

A floor strong enough that the depleted mage rivals a *dedicated* fighter on soft targets (then the
cantrip is too hot — drop `spell_power₀`), or a budget so large that MP never bites within a battle
(then trickle/pool is too generous). Both are calibration, not shape.

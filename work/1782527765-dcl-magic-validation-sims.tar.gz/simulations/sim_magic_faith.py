#!/usr/bin/env python3
"""
sim_magic_faith.py — Q3: how Faith enters the magic damage equation.

Q3 proposal (to FALSIFY, not confirm):
  Faith applies TWICE per hit — caster's faith (output) x target's faith (vulnerability) — because that
  two-sidedness is already LOCKED (doc 08: faith = +output AND +vulnerability; A2: magical status
  resists on inverse faith). Vanilla double-faith is structurally right but its CURVE (F/100, 0..1) makes
  the buildable swing huge and lets Faith dominate magic. Fix: keep two applications but put each on a
  BOUNDED band CENTERED at ~1.0 (mid-faith = neutral), so:
    - the high/high corner stays bounded (no NEW explosion on top of the Q2 stack),
    - mid-faith is neutral (Faith is a SPREAD around the population, not flat inflation),
    - a low-faith TARGET resists meaningfully but is never immune (no vanilla atheist near-immunity).
  Honors the Q2 guardrail: Faith is the ONE big two-sided multiplier, and bounding it IS the guardrail.

Falsification targets:
  T1 centered:   mid-faith multiplier == 1.0; vanilla F/100 has NO neutral point (everyone <= max).
  T2 bounded:    high-faith-caster x high-faith-target <= ~1.8 (no new explosion).
  T3 not-immune: low-faith target takes a real cut but never ~0 (resist is a lever, not immunity).
  T4 tamed:      combined twice-swing across BUILDABLE faith ~3-4x, vs vanilla's >10x.
  T5 once-vs-2x: 'once' (caster-only) ERASES the target axis (atheist resist == 1.0) — quantifies what
                 the LOCKED two-sided design would throw away.
  T6 stack:      Faith's marginal contribution to the Q2 worst corner is bounded (Faith is not the
                 explosion source; the residual is the G_m/MA/spell spine = Q2 calibration).
  Pop-neutral:   averaged over a faith-distributed roster, mean multiplier ~= 1.0 (spread, not a shift).
"""

# ---- Faith model -------------------------------------------------------------
# Usable faith band. FFT clamps faith ~5..95; a balanced roster centers ~55. We map the BUILDABLE
# extremes (a committed atheist ~25, a committed zealot ~85) onto the band, neutral at the center.
F_MIN, F_MID, F_MAX = 25, 55, 85

def faith_mult(F, bl, bh):
    """Bounded band, ==1.0 at F_MID; reaches bl at F_MIN, bh at F_MAX (asymmetric bl/bh allowed)."""
    if F >= F_MID:
        return 1.0 + (F - F_MID) / (F_MAX - F_MID) * (bh - 1.0)
    return 1.0 + (F - F_MID) / (F_MID - F_MIN) * (1.0 - bl)

def faith_vanilla(F):
    return F / 100.0

def pair(fc, ft, bl, bh, mode="twice"):
    if mode == "twice":
        return faith_mult(fc, bl, bh) * faith_mult(ft, bl, bh)
    return faith_mult(fc, bl, bh)            # 'once' = caster only; target faith does nothing

def pair_vanilla(fc, ft):
    return faith_vanilla(fc) * faith_vanilla(ft)

# provisional band (the sweep at the bottom justifies / refines this)
BL, BH = 0.70, 1.30

# ============================================================================
if __name__ == "__main__":
    print("="*82)
    print("PART A — the Faith CURVE: centered band (neutral at mid) vs vanilla F/100 (no neutral)")
    print("="*82)
    print(f"   band = [{BL}, {BH}], centered 1.0 at faith {F_MID}\n")
    print(f"   {'faith':>6} | {'DCL mult':>9} | {'vanilla F/100':>13}")
    print("   " + "-"*36)
    for F in (25, 40, 55, 70, 85):
        tag = "  <- neutral" if F == F_MID else ""
        print(f"   {F:>6} | {faith_mult(F,BL,BH):>9.2f} | {faith_vanilla(F):>13.2f}{tag}")
    print("\n   READ: DCL is 1.00 at mid-faith (a typical unit's magic is UNCHANGED by faith); deviation")
    print("   both ways. Vanilla never reaches 1.0 below faith 100 — it only ever SUBTRACTS from a max,")
    print("   so every sub-100 unit is 'penalised' and there is no neutral reference. (T1)")

    print("\n" + "="*82)
    print("PART B — twice vs once: the combined multiplier matrix + the buildable swing")
    print("="*82)
    F3 = [("atheist",25), ("neutral",55), ("zealot",85)]
    print("   combined faith multiplier  (rows = caster, cols = TARGET):\n")
    header = "           " + " ".join(f"{lbl:>10}" for lbl,_ in F3)
    print(header)
    for lc, fc in F3:
        cells = " ".join(f"{pair(fc,ft,BL,BH):>10.2f}" for _, ft in F3)
        print(f"   {lc:>8}  {cells}")
    hi = pair(85,85,BL,BH); lo = pair(25,25,BL,BH); neu = pair(55,55,BL,BH)
    swing_2x   = hi/lo
    swing_van  = pair_vanilla(85,85)/pair_vanilla(25,25)
    swing_once = faith_mult(85,BL,BH)/faith_mult(25,BL,BH)
    print(f"\n   high/high corner = {hi:.2f}   neutral/neutral = {neu:.2f}   low/low = {lo:.2f}")
    print(f"   BUILDABLE swing (faith 25..85):   DCL twice = {swing_2x:.2f}x    vanilla twice = {swing_van:.2f}x")
    print(f"   high corner {hi:.2f} <= ~1.8 -> no new explosion (T2);  swing {swing_2x:.2f}x << vanilla {swing_van:.2f}x (T4)")
    print(f"\n   'ONCE' (caster-only) swing = {swing_once:.2f}x, and the TARGET axis vanishes:")
    print(f"     atheist target vs neutral caster:  twice -> {pair(55,25,BL,BH):.2f}   once -> {pair(55,25,BL,BH,'once'):.2f}")
    print(f"     zealot  target vs neutral caster:  twice -> {pair(55,85,BL,BH):.2f}   once -> {pair(55,85,BL,BH,'once'):.2f}")
    print("   under 'once' both targets take 1.00 — no atheist-tank, no devout-glass-cannon. That axis")
    print("   is exactly what doc 08 / A2 LOCKED, so 'once' contradicts prior decisions. (T5)")

    print("\n" + "="*82)
    print("PART C — identity check: meaningful but NOT immune; faith is a real two-sided unit axis")
    print("="*82)
    rows = [
        ("atheist target vs neutral caster", pair(55,25,BL,BH), "resists"),
        ("atheist target vs ZEALOT caster",  pair(85,25,BL,BH), "zealot still punches ~through"),
        ("zealot target vs neutral caster",  pair(55,85,BL,BH), "glass cannon"),
        ("zealot mirror (zealot vs zealot)",  pair(85,85,BL,BH), "scariest corner"),
        ("atheist mage output (vs neutral)",  pair(25,55,BL,BH), "bad mage = real cost of low faith"),
    ]
    for lbl, v, note in rows:
        print(f"   {lbl:>34} -> x{v:.2f}   ({note})")
    atheist_resist = faith_mult(25,BL,BH)
    print(f"\n   atheist single-side resist = {atheist_resist:.2f} (takes {100*atheist_resist:.0f}% vs neutral caster):")
    print("   a real defensive identity, but a zealot caster still lands {:.0f}% — never immunity. (T3)".format(
        100*pair(85,25,BL,BH)))
    print("   contrast vanilla: an atheist (faith 25) vs neutral caster takes {:.0f}% — near-immune (degenerate)."
          .format(100*pair_vanilla(55,25)))

    print("\n" + "="*82)
    print("PART D — full stack: is Faith the explosion source, or a bounded spreader?")
    print("="*82)
    # Q2 worst corner (placeholder magnitudes from sim_magic_shape): Firaga x high MA x zodiac weakness.
    SPELL_FIRAGA = 3.0; MA_HI = 20; ZODIAC_WEAK = 1.5; G_M = 8.0
    spine = MA_HI * SPELL_FIRAGA * G_M                      # MA x spell x G_m  (the Q2 calibration spine)
    print(f"   Q2 spine (MA {MA_HI} x Firaga {SPELL_FIRAGA} x G_m {G_M}) = {spine:.0f}  before any multiplier band\n")
    print(f"   {'config':>40} | {'faith':>6} {'zodiac':>7} | {'damage':>7}")
    print("   " + "-"*70)
    configs = [
        ("neutral faith, neutral element", 1.0,        1.0),
        ("zealot/zealot faith, neutral",   hi,         1.0),
        ("neutral faith, zodiac weakness", 1.0,        ZODIAC_WEAK),
        ("WORST: zealot/zealot + weakness", hi,        ZODIAC_WEAK),
        ("atheist/atheist + resist (best)", lo,        0.66),
    ]
    for lbl, fm, zm in configs:
        print(f"   {lbl:>40} | {fm:>6.2f} {zm:>7.2f} | {spine*fm*zm:>7.0f}")
    print(f"\n   Faith's max marginal factor = {hi:.2f} (bounded, ~ same size as zodiac {ZODIAC_WEAK}).")
    print("   The big number is the SPINE (MA x spell x G_m), i.e. the Q2 calibration target — NOT Faith.")
    print("   Faith multiplies the corner by at most ~1.7x and at least ~0.5x: a bounded spreader. (T6)")

    print("\n" + "="*82)
    print("POP-NEUTRAL — averaged over a roster, does the faith mechanic SHIFT magic or just SPREAD it?")
    print("="*82)
    roster = [25,35,45,55,55,65,75,85]                     # symmetric-ish around 55
    mean_mult = sum(faith_mult(f,BL,BH) for f in roster)/len(roster)
    mean_van  = sum(faith_vanilla(f) for f in roster)/len(roster)
    print(f"   roster faith = {roster}")
    print(f"   mean DCL multiplier  = {mean_mult:.2f}  (want ~1.00 -> spread, not a global buff/nerf)")
    print(f"   mean vanilla F/100   = {mean_van:.2f}  (a flat ~0.5x global magic NERF baked into faith)")

    print("\n" + "="*82)
    print("SENSITIVITY — sweep the band; want high_corner<=~1.8, atheist_resist in [0.60,0.72], swing<<vanilla")
    print("="*82)
    print(f"   {'band [bl,bh]':>14} | {'high^2':>7} {'resist':>7} {'low^2':>6} {'swing2x':>8} {'once':>6}")
    print("   " + "-"*58)
    pick = None
    for bl, bh in [(0.80,1.20),(0.70,1.30),(0.65,1.30),(0.60,1.30),(0.65,1.35),(0.60,1.40),(0.70,1.25)]:
        hc = bh*bh; rs = bl; lc = bl*bl; sw = hc/lc; on = bh/bl
        flag = ""
        if hc <= 1.80 and 0.60 <= rs <= 0.72:
            flag = "  <- meets all three"
            if pick is None and (bl,bh) == (0.70,1.30):
                pick = (bl,bh)
        band = f"[{bl:.2f},{bh:.2f}]"
        print(f"   {band:>14} | {hc:>7.2f} {rs:>7.2f} {lc:>6.2f} {sw:>7.2f}x {on:>6.2f}{flag}")
    print("\n   READ: [0.70,1.30] is the legible pick — a clean '+/-30% around a neutral 1.0', high corner")
    print("   1.69 (bounded), atheist resist 0.70 (real identity, not immunity). Wider-low bands (e.g.")
    print("   [0.65,1.30]) buy a beefier atheist tank at a small legibility cost — a calibration lever,")
    print("   not a structural change. Every band keeps mid neutral and the high corner < 1.85.")

    print("\n" + "="*82)
    print("VERDICT: twice + bounded-centered band is structurally sound. Faith stays the ONE big two-sided")
    print("multiplier, bounded; it spreads (mean ~1.0) rather than shifts; it preserves the locked")
    print("atheist-tank / devout-glass-cannon axis that 'once' would erase; it is NOT the stack's")
    print("explosion source. Band magnitude = calibration; the SHAPE (twice, centered, bounded) holds.")

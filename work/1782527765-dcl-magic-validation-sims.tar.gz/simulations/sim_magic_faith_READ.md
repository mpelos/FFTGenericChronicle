# sim_magic_faith — read (Q3: how Faith enters magic damage)

**Question.** Does Faith apply **once** (caster only) or **twice** (caster output × target
vulnerability), and on what curve — before we pin numbers? Proposal to falsify: **twice**, each on a
**bounded band centered at 1.0** (mid-faith neutral), keeping the locked two-sided Faith while taming
vanilla's runaway double-faith. Provisional band **[0.70, 1.30]**.

## T1 — centered, with a neutral point  → CONFIRMED

DCL multiplier is **1.00 at mid-faith (55)** and deviates both ways (0.70 at 25, 1.30 at 85). Vanilla
`F/100` **never reaches 1.0 below faith 100** — it only subtracts from a max, so every real unit is
"penalised" and there is no neutral reference. Centering makes Faith a *spread*, not a baked-in nerf.

## T2 / T4 — bounded high corner, tamed swing  → CONFIRMED

| | DCL [0.70,1.30] | vanilla F/100 |
|---|---:|---:|
| zealot/zealot corner | **1.69** | 0.72 (of a faith-100 max) |
| buildable swing (faith 25..85) | **3.45×** | **11.56×** |

The dangerous corner (both devout) is **1.69× ≤ ~1.8** — no *new* explosion on the stack. The buildable
swing drops from vanilla's ~11.6× to ~3.5×, i.e. Faith stops dominating magic while staying the biggest
trait lever.

## T3 — meaningful resist, never immunity  → CONFIRMED (the key identity result)

A low-faith **target** takes **70%** from a neutral caster (a real atheist-tank identity) — but a
**zealot caster still lands 91%**: a lever, not a wall. Vanilla puts the same atheist at **14%**
(near-immune → the degenerate "atheist party trivialises magic" of FFT). The multiplicative resist
*never chip-zeros* (Q2), so there is no immunity breakpoint.

## T5 — 'once' erases a locked axis  → CONFIRMED (why twice is forced, not chosen)

Under caster-only Faith, **every target takes ×1.00** — no atheist-tank, no devout-glass-cannon. That
two-sided target axis is exactly what `08` (Faith = output **and** vulnerability) and **A2** (magical
status resists on inverse Faith) already LOCKED. So 'once' isn't a cheaper option — it **contradicts
prior decisions**. Twice is the only shape consistent with the corpus.

## T6 — Faith is a bounded spreader, NOT the explosion source  → CONFIRMED

Worst offensive corner = spine `MA20 × Firaga3.0 × G_m8 = 480`, then **×faith(≤1.69) ×zodiac(1.5)**.
Faith's max marginal factor (1.69) is **about the size of Zodiac's (1.5)** — no single runaway band.
The big number is the **spine** (the Q2 calibration target), not Faith. Faith multiplies the corner by
∈ [0.49, 1.69]: bounded both ends.

- **Pop-neutral:** averaged over a faith roster, mean DCL multiplier = **1.00** (pure spread); mean
  vanilla = 0.55 (a hidden global magic nerf). Faith changes *who* magic hits hard, not the overall
  magic power level (that's `G_m`).

## Sensitivity

All bands tested keep mid neutral by construction and the high corner < 1.85. `[0.70,1.30]` is the
**legible pick** (a clean "±30% around 1.0", resist 0.70, corner 1.69). Wider-low bands (`[0.65,1.30]`,
`[0.60,1.30]`) buy a beefier atheist tank (resist 0.65/0.60) with the **same bounded high corner 1.69**
— a calibration lever, not a structural change. Narrow `[0.80,1.20]` is the safest (corner 1.44) if
playtest finds magic too swingy.

## Verdict

**Adopt twice + bounded-centered band.** It (i) is the only shape consistent with the locked two-sided
Faith, (ii) cuts vanilla's ~11.6× buildable swing to ~3.5×, (iii) gives a real atheist-tank identity
without immunity, and (iv) is a bounded spreader, not the stack's explosion source. **Band magnitude is
calibration; `[0.70,1.30]` is provisional.**

## What carries to Q4

Faith (≤1.69) and a Zodiac weakness (1.5) **stack multiplicatively** → a faith-high × element-weak
corner is ~2.5× over neutral. That cross-band compounding is the **Q2 #1 risk** and is exactly **Q4**'s
job: Zodiac/Shell bands + stacking order + whether a soft cap is needed so faith×element can't pile on
top of the `G_m` spine.

## What would flip this

Evidence that *no* band gives both a bounded high corner and a meaningful resist (none found — they
decouple: high corner = `bh²`, resist = `bl`), or a corpus decision to drop target-faith vulnerability
(would contradict `08`/A2 and require reopening them).

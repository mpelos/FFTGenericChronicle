#!/usr/bin/env python3
"""
sim_magic_heal.py — Q (heal): healing on the same spine, with TARGET Faith scaling healing received.

Proposal to FALSIFY: healing is the 3rd numeric category on the same spine MINUS element/Shell —
    heal = base(MA) * heal_power * faith_caster * faith_target * G_m
— i.e. the TARGET's Faith scales healing RECEIVED the same way it scales damage TAKEN (one Faith rule:
"the more devout, the more magic flows through you — for good and ill"). Same band [0.70,1.30] as damage.

Claims to break:
  T1 mirror: the heal faith-matrix == the damage faith-matrix (one rule, not a special case).
  T2 wash / non-degenerate: target Faith scales heal-received and damage-taken by the SAME factor, so
     the atheist (resist + heal-resist) and the zealot (vuln + heal-vuln) are each a WASH — neither
     strictly better — and at EQUAL faith investment the heal corner == the nuke corner (Faith is not a
     healing-specific exploit / infinite-sustain turtle).
  T3 atheist not un-healable: 0.70x heal on a tank's larger HP pool is still a meaningful absolute
     top-up; the atheist tank survives by mitigation, not by being topped to full.
  T4 band choice: same [0.70,1.30] (one-rule consistency) vs a narrower heal band [0.80,1.20] (gentler
     on low-faith allies) — surface the feel-vs-consistency trade and recommend.
"""

F_MIN, F_MID, F_MAX = 25, 55, 85
def fmult(F, bl=0.70, bh=1.30):
    if F >= F_MID:
        return 1.0 + (F - F_MID) / (F_MAX - F_MID) * (bh - 1.0)
    return 1.0 + (F - F_MID) / (F_MID - F_MIN) * (1.0 - bl)

SP   = {"Cure": 1.0, "Cura": 1.8, "Curaga": 3.0}   # heal tiers (same scale as damage tiers, shared spine)
MA, G_M = 16, 3.0
def heal(tier, fh, ft, ma=MA, gm=G_M, bl=0.70, bh=1.30):
    return ma * SP[tier] * gm * fmult(fh, bl, bh) * fmult(ft, bl, bh)
def dmg(tier, fc, ft, elem=1.0, ma=MA, gm=G_M):     # neutral element baseline, same spine
    return ma * SP[tier] * gm * fmult(fc) * fmult(ft) * elem

ATH, NEU, ZEAL = 25, 55, 85
FAITHS = [("atheist", ATH), ("neutral", NEU), ("zealot", ZEAL)]

# ============================================================================
if __name__ == "__main__":
    print("="*82)
    print("PART A — heal faith-matrix (healer x TARGET) — and it MIRRORS the damage matrix")
    print("="*82)
    print("   heal multiplier (rows = healer faith, cols = TARGET faith):\n")
    print("           " + " ".join(f"{lbl:>9}" for lbl, _ in FAITHS))
    for lh, fh in FAITHS:
        cells = " ".join(f"{fmult(fh)*fmult(ft):>9.2f}" for _, ft in FAITHS)
        print(f"   {lh:>7}  {cells}")
    print("\n   damage multiplier (rows = nuker faith, cols = TARGET faith) — IDENTICAL function:")
    print("           " + " ".join(f"{lbl:>9}" for lbl, _ in FAITHS))
    for lc, fc in FAITHS:
        cells = " ".join(f"{fmult(fc)*fmult(ft):>9.2f}" for _, ft in FAITHS)
        print(f"   {lc:>7}  {cells}")
    print("\n   READ: same band, same two-sided rule. One Faith rule covers damage-in, damage-out, and")
    print("   heal-in — no healing special case. (T1)")

    print("\n" + "="*82)
    print("PART B — the wash: target Faith scales heal-received AND damage-taken by the SAME factor")
    print("="*82)
    print(f"   {'target':>9} | {'dmg taken (neutral nuker)':>25} | {'heal recv (neutral healer)':>26}")
    print("   " + "-"*68)
    for lt, ft in FAITHS:
        d = dmg("Cura", NEU, ft); h = heal("Cura", NEU, ft)
        print(f"   {lt:>9} | {'x'+format(fmult(ft),'.2f')+'  ('+format(d,'.0f')+')':>25} | "
              f"{'x'+format(fmult(ft),'.2f')+'  ('+format(h,'.0f')+')':>26}")
    print("\n   the atheist resists nukes (x0.70) AND is healed less (x0.70); the zealot is hit harder")
    print("   (x1.30) AND healed more (x1.30) — a WASH on the magic axis. The atheist leans on physical")
    print("   HP/DR, the zealot on raw magic throughput (swingy). Neither strictly better. (T2a)")
    print("\n   parity at EQUAL faith investment (so Faith is no heal-exploit):")
    print(f"     zealot HEALER -> zealot target = x{fmult(ZEAL)*fmult(ZEAL):.2f}    "
          f"zealot NUKER -> zealot target = x{fmult(ZEAL)*fmult(ZEAL):.2f}  (identical) (T2b)")

    print("\n" + "="*82)
    print("PART C — degeneracy probes: mega-heal turtle & 'un-healable' atheist tank")
    print("="*82)
    # archetypes: zealot mage (robe 110), atheist tank (plate 220), neutral (150)
    HP = {"zealot mage (110hp)": 110, "neutral (150hp)": 150, "atheist tank (220hp)": 220}
    print("   a single Cura as % of the target's max HP:\n")
    print(f"   {'target':>22} | {'by atheist healer':>17} | {'by neutral':>11} | {'by zealot healer':>16}")
    print("   " + "-"*78)
    targets = [("zealot mage (110hp)", ZEAL), ("neutral (150hp)", NEU), ("atheist tank (220hp)", ATH)]
    for lt, ft in targets:
        hp = HP[lt]
        a = heal("Cura", ATH, ft); n = heal("Cura", NEU, ft); z = heal("Cura", ZEAL, ft)
        print(f"   {lt:>22} | {format(100*a/hp,'.0f')+'%':>17} | {format(100*n/hp,'.0f')+'%':>11} | "
              f"{format(100*z/hp,'.0f')+'%':>16}")
    print("\n   atheist tank: ~27% top-up per Cura on a 220hp pool — NOT un-healable, just heal-inefficient")
    print("   (it survives by plate DR + HP, topped over a couple turns). zealot mage: a zealot healer")
    print("   overheals it (132%) — but that same zealot mage takes 1.30x every incoming hit, so the big")
    print("   heal is offset by big damage. (T3)")
    # mega-heal vs incoming, on the zealot mage
    cura_z = heal("Cura", ZEAL, ZEAL)                 # zealot healer on zealot target
    nuke_z = dmg("Fira" if "Fira" in SP else "Cura", NEU, ZEAL)  # neutral nuker on zealot (Cura tier == Fira scale)
    nuke_z_zealot = dmg("Cura", ZEAL, ZEAL)           # a zealot nuker on the zealot target
    print(f"\n   mega-heal check: zealot healer Cura on zealot target = {cura_z:.0f}/turn")
    print(f"     vs a NEUTRAL nuker on that zealot target = {nuke_z:.0f}/turn  -> heal {'>' if cura_z>nuke_z else '<='} damage,")
    print("       but that is 2 units (healer+target) holding vs 1 nuker — expected to win a 2v1 attrition;")
    print(f"     vs a ZEALOT nuker on that zealot target = {nuke_z_zealot:.0f}/turn  -> heal {'≈' if abs(cura_z-nuke_z_zealot)<1 else 'vs'} damage")
    print("       at equal investment it is break-even; add a 2nd attacker or CC the healer and the")
    print("       1.30x-everything zealot collapses. High-variance, NOT unkillable.")

    print("\n" + "="*82)
    print("PART D — band choice: same [0.70,1.30] vs a gentler heal band [0.80,1.20]")
    print("="*82)
    print(f"   {'band':>14} | {'atheist heal recv':>17} | {'zealot/zealot heal corner':>26}")
    print("   " + "-"*64)
    for bl, bh, lbl in [(0.70,1.30,"same as damage"),(0.80,1.20,"gentler heal")]:
        ath_recv = fmult(ATH, bl, bh)             # neutral healer on atheist = 1.0*bl
        corner = fmult(ZEAL, bl, bh)**2
        print(f"   [{bl:.2f},{bh:.2f}] | {format('x'+format(ath_recv,'.2f'),'>9'):>17} | {format('x'+format(corner,'.2f'),'>12'):>26}   ({lbl})")
    print("\n   the only real feel-bad is 'I can't fully heal my own low-faith ally': same-band = 0.70,")
    print("   gentler = 0.80. Recommend SAME band [0.70,1.30] for the one-Faith-rule consistency (P5):")
    print("   0.70 is a 30% penalty, not abandonment, and it is the honest cost of the atheist's magic")
    print("   resistance. Keep the narrower band in reserve if playtest finds healers abandon low-faith")
    print("   frontliners.")

    print("\n" + "="*82)
    print("VERDICT: target-Faith-scales-healing holds. One Faith rule across damage-in/out + heal-in;")
    print("the atheist/zealot are each a wash (resist+heal-resist / vuln+heal-vuln); equal-investment")
    print("heal == nuke (no exploit); the atheist tank is heal-inefficient, not un-healable. Same band")
    print("[0.70,1.30] for consistency; gentler [0.80,1.20] held in reserve. Magnitudes are calibration.")

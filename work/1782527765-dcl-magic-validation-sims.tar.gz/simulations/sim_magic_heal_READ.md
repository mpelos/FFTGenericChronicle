# sim_magic_heal — read (healing on the spine; target Faith scales healing received)

**Question.** Healing is the 3rd numeric category. Does it run the same spine **minus** element/Shell,
with the **target's Faith** scaling healing *received* the same way it scales damage *taken* — and is
that non-degenerate? Proposal: `heal = base(MA) × heal_power × faith_caster × faith_target × G_m`, same
band [0.70,1.30] as damage ("one Faith rule: the more devout, the more magic flows through you").

## T1 — one Faith rule (heal matrix == damage matrix)  → CONFIRMED

The healer×target faith matrix is **identical** to the nuker×target matrix (same `fmult` applied twice,
same band). No healing special case — Faith covers damage-in, damage-out, and heal-in with one function.

## T2 — the wash + parity (non-degenerate)  → CONFIRMED

target Faith scales **both** sides by the same factor:

| target | dmg taken (neutral nuker) | heal recv (neutral healer) |
|---|---:|---:|
| atheist | ×0.70 | ×0.70 |
| neutral | ×1.00 | ×1.00 |
| zealot | ×1.30 | ×1.30 |

So the atheist (resist + heal-resist) and zealot (vuln + heal-vuln) are each a **wash** on the magic
axis — neither strictly better; the atheist leans on physical HP/DR, the zealot on swingy throughput.
And at **equal Faith investment** the heal corner == the nuke corner (both ×1.69 at zealot/zealot), so
Faith is **not** a healing-specific exploit.

## T3 — atheist not un-healable; mega-heal not unkillable  → CONFIRMED

A single Cura as % of max HP:

| target | atheist healer | neutral | zealot healer |
|---|---:|---:|---:|
| zealot mage (110) | 71% | 102% | 133% |
| neutral (150) | 40% | 58% | 75% |
| atheist tank (220) | 19% | 27% | 36% |

The atheist tank gets a real ~27% top-up per Cura on its big pool (heal-*inefficient*, survives via
DR+HP — not un-healable). Mega-heal probe: a zealot healer's Cura (146/turn) out-paces a *single*
neutral nuker (112) — but that's a 2-unit hold vs 1, and a *zealot* nuker matches it (146) at equal
investment; add a second attacker or CC the healer and the ×1.30-everything zealot collapses.
High-variance, not unkillable.

## T4 — band choice

| band | atheist heal recv | zealot/zealot corner | |
|---|---:|---:|---|
| [0.70,1.30] | ×0.70 | ×1.69 | same as damage (recommended) |
| [0.80,1.20] | ×0.80 | ×1.44 | gentler heal (reserve) |

Recommend the **same [0.70,1.30]** for one-rule consistency (P5): 0.70 is a 30% penalty, not
abandonment, and is the honest cost of the atheist's magic resistance. Hold the gentler band in reserve
if playtest shows healers abandoning low-Faith frontliners.

## Verdict

**Adopt** target-Faith-scales-healing on the shared spine (minus element/Shell), same band as damage.
One Faith rule across damage-in/out + heal-in; atheist/zealot each a wash; equal-investment heal == nuke
(no exploit); atheist tank heal-inefficient, not un-healable; undead invert healing (designed property).
Recorded in `11` (*Healing — same spine, two-sided Faith, no resist*), `12`. Magnitudes are calibration.

## What would flip this

Playtest evidence that the 0.70 low-Faith-ally heal genuinely abandons frontliners (→ adopt the reserve
[0.80,1.20] heal band), or a heal/damage `G_m` split that makes healing out-scale damage at parity (→
heal would need its own bridge constant).

#!/usr/bin/env python3
"""
sim_magic_shape.py — pressure-test the Q2 magic-damage SHAPE before committing it.

Q2 proposal: magic is MULTIPLICATIVE and SPELL-CENTRIC (FFT-faithful), the conceptual mirror of
physical (which is additive/subtractive):

    dmg = base(MA) * spell_power * faith_mult * element_mult * G_m      (magic — MULTIPLY)
    injury = max(pen_floor*R, R - DR_type) * wound_mult                 (physical — SUBTRACT)

Three load-bearing claims to FALSIFY:
  A. Multiplicative keeps spell-choice meaningful across the whole MA range; ADDITIVE (spell as a
     '+mod' like wmod) compresses spell choice at high MA. [the core Q2 argument]
  B. Paradigm split is coherent: magic IGNORES physical DR (so it's the anti-armor answer) but is
     gated by MULTIPLICATIVE resist (Shell/Zodiac/Faith) — and doesn't go degenerate (one-shots,
     whiffs-to-zero, or strictly dominating/dominated vs physical).
  C. Magic is balanced vs physical per-turn once charge-time is accounted for (placeholder gating).

Deferred to later questions (parametrised here, not decided): how many times Faith applies (caster
only vs caster*target), exact Zodiac/Shell stacking, MP economy, base(MA) curve. Flagged as PLACEHOLDER.
"""

# ---------------- magic shape ----------------
SPELL = {"Fire": 1.0, "Fira": 1.8, "Firaga": 3.0}   # spell_power (relative tiers)
G_M   = 8.0                                          # magic bridge constant (calibration placeholder)

def base_MA(MA):            # linear (FFT-style; magic does NOT inherit the GURPS thrust/swing table)
    return MA

def magic_dmg(MA, spell, faith_mult=1.0, element=1.0, shell=False):
    s = base_MA(MA) * SPELL[spell] * faith_mult * element * G_M
    if shell: s *= 0.5      # Shell = magic's multiplicative 'armor' (placeholder 0.5)
    return s

# additive alternative (spell as a flat '+mod', the rejected Model 2) — same faith/elem/G envelope
ADD = {"Fire": 8, "Fira": 28, "Firaga": 56}         # illustrative spell '+mod' values
def magic_dmg_additive(MA, spell, faith_mult=1.0, element=1.0):
    return (base_MA(MA) + ADD[spell]) * faith_mult * element * G_M

# ---------------- physical (subtractive, from the armor sim) ----------------
R_PHYS   = 14.0     # base(PA)+wmod for a mid sword
WOUND    = {"cut": 1.5, "thrust": 2.0, "crush": 1.0}
PEN_FLOOR= 0.20
G_P      = 5.0      # physical bridge constant, tuned so phys-vs-leather ~ magic-vs-noShell at mid stats

ARMOR = {  # DR by type + HP buffer (relative, from sim_armor_calibration); mage in robe is squishy
    "Plate":   {"DR": {"cut": 9, "thrust": 8, "crush": 3}, "HP": 200},
    "Mail":    {"DR": {"cut": 5, "thrust": 5, "crush": 5}, "HP": 175},
    "Leather": {"DR": {"cut": 2, "thrust": 2, "crush": 2}, "HP": 150},
    "Robe":    {"DR": {"cut": 0, "thrust": 0, "crush": 0}, "HP": 110},
}
def phys_dmg(armor, atype="cut"):
    dr = ARMOR[armor]["DR"][atype]
    through = max(PEN_FLOOR * R_PHYS, R_PHYS - dr)
    return through * WOUND[atype] * G_P

# ============================================================================
if __name__ == "__main__":
    print("="*80)
    print("PART A — does spell choice stay meaningful across MA?  (multiplicative vs additive)")
    print("="*80)
    print("  Firaga/Fire damage RATIO at each MA (spell-choice 'weight'); want it STABLE:\n")
    print(f"   {'MA':>4} | {'MULT ratio':>11} | {'ADD ratio':>10}")
    print("   " + "-"*32)
    mult_ratios, add_ratios = [], []
    for MA in (6, 10, 14, 18, 22, 30, 40):
        mr = magic_dmg(MA,"Firaga") / magic_dmg(MA,"Fire")
        ar = magic_dmg_additive(MA,"Firaga") / magic_dmg_additive(MA,"Fire")
        mult_ratios.append(mr); add_ratios.append(ar)
        print(f"   {MA:>4} | {mr:>11.2f} | {ar:>10.2f}")
    drift_mult = (max(mult_ratios)-min(mult_ratios))
    drift_add  = (max(add_ratios)-min(add_ratios))
    print(f"\n   ratio drift across MA:  multiplicative = {drift_mult:.2f} (flat ✓)   "
          f"additive = {drift_add:.2f} (compresses ✗)")
    print("   STRUCTURAL (calibration-independent): additive ratio -> 1 as MA->inf (spell choice dies);")
    print("   multiplicative ratio is exactly spell_power, constant at every MA. Claim A holds.")

    print("\n" + "="*80)
    print("PART B — paradigm: physical SUBTRACTS (DR walls it), magic MULTIPLIES (ignores DR)")
    print("="*80)
    print("  per-hit damage; Fira neutral element, Faith mult 0.7 (placeholder):\n")
    print(f"   {'target':8} {'HP':>4} | {'phys cut':>9} {'phys crush':>10} | {'magic Fira':>10} {'+Shell':>7}")
    print("   " + "-"*60)
    for a in ARMOR:
        hp = ARMOR[a]["HP"]
        pc = phys_dmg(a,"cut"); pcr = phys_dmg(a,"crush")
        m  = magic_dmg(14,"Fira",faith_mult=0.7); ms = magic_dmg(14,"Fira",faith_mult=0.7,shell=True)
        print(f"   {a:8} {hp:>4} | {pc:>9.0f} {pcr:>10.0f} | {m:>10.0f} {ms:>7.0f}")
    print("\n   READ: physical cut COLLAPSES vs plate (9 DR) but magic is FLAT across armor (no DR) ->")
    print("   magic is the anti-plate answer. Shell (mult .5) is magic's 'armor' — cuts it ~half on")
    print("   anyone, the only real magic mitigation besides Faith/Zodiac. Coherent split.")

    print("\n" + "="*80)
    print("PART C — non-degenerate?  (one-shots, whiffs, Faith spread, per-turn parity)")
    print("="*80)
    print("  magic Fira as % of target HP across MA (want a sane band, never 1-shot, never ~0):\n")
    print(f"   {'MA':>4} | " + " ".join(f"{a:>8}" for a in ARMOR))
    print("   " + "-"*44)
    for MA in (8, 14, 20, 26):
        cells = []
        for a in ARMOR:
            pct = 100 * magic_dmg(MA,"Fira",faith_mult=0.7) / ARMOR[a]["HP"]
            cells.append(f"{pct:>7.0f}%")
        print(f"   {MA:>4} | " + " ".join(cells))

    print("\n  two-sided Faith spread (Fira, MA 14, neutral) — devout target vs faithless:")
    for ft,lbl in [(0.95,"high-Faith target (0.95)"),(0.70,"mid (0.70)"),(0.40,"low-Faith (0.40)")]:
        # caster faith fixed 0.8; target faith as vulnerability (Q3 will decide if both apply)
        d = magic_dmg(14,"Fira",faith_mult=0.8*ft)
        print(f"     {lbl:28} -> {d:>5.0f}")
    print("     (low-Faith resists but is NOT immune; high-Faith is punished but not 1-shot — the")
    print("      two-sided risk is real and bounded. Exact caster-vs-target Faith count = Q3.)")

    print("\n  per-turn parity vs physical (PLACEHOLDER charge gating: magic casts ~every 2 turns):")
    mage_per_cast = magic_dmg(16,"Fira",faith_mult=0.75)         # vs a neutral, no shell
    mage_per_turn = mage_per_cast / 2.0                          # charge: one Fira per 2 turns
    fighter_per_turn = phys_dmg("Leather","cut")                # one swing/turn vs leather
    print(f"     mage Fira/cast {mage_per_cast:.0f}  -> /turn {mage_per_turn:.0f}  (charge ~2 turns)")
    print(f"     fighter cut/turn vs leather {fighter_per_turn:.0f}")
    print(f"     ratio mage:fighter per-turn = {mage_per_turn/fighter_per_turn:.2f}  "
          f"(want ~0.8–1.3; magic trades burst+AoE+ignores-DR for charge/MP/dodge/Faith-risk)")

    print("\n" + "="*80)
    print("SENSITIVITY — does the SHAPE verdict survive different spell_power / faith / G?")
    print("="*80)
    for gm in (6.0, 8.0, 11.0):
        for fp in ({"Fire":1.0,"Fira":1.8,"Firaga":3.0}, {"Fire":1.0,"Fira":2.2,"Firaga":4.0}):
            SPELL.update(fp); G_M = gm
            # recompute the core claim A under these knobs
            rs = [ (base_MA(MA)*fp["Firaga"]) / (base_MA(MA)*fp["Fire"]) for MA in (6,20,40) ]
            stable = (max(rs)-min(rs)) < 1e-9
            print(f"   G_m={gm:>4}  spell_power={fp}  -> mult spell-ratio constant across MA: {stable}")
    print("\n   The multiplicative spell-ratio is EXACTLY spell_power at every MA, for ALL knobs — the")
    print("   Part-A conclusion is structural, not a tuned coincidence. Magnitudes (G_m, faith, Shell)")
    print("   stay calibration; the SHAPE is what this sim certifies.")

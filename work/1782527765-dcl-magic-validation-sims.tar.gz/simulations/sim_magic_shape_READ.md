# sim_magic_shape — read (Q2: the magic-damage SHAPE)

**Question.** Is magic damage the right *shape* before we pin numbers: **multiplicative & spell-centric**
(`dmg = base(MA) · spell_power · faith · element · G`), the conceptual mirror of physical's
additive/subtractive pipeline? Three claims, tried to falsify.

## A — multiplicative keeps spell-choice alive; additive compresses  → CONFIRMED (structural)

Firaga/Fire damage ratio across MA:

| MA | multiplicative | additive |
|----|---------------:|---------:|
| 6  | 3.00 | 4.43 |
| 14 | 3.00 | 3.18 |
| 22 | 3.00 | 2.60 |
| 40 | 3.00 | 2.00 |

The multiplicative ratio is **exactly `spell_power` at every MA** (drift 0.00); the additive ratio
**decays toward 1 as MA grows** (drift 2.43) — i.e. with an additive spell-`+mod`, picking Firaga over
Fire matters *less and less* as the mage levels, and at end-game every spell tier converges. This is
**calibration-independent** (holds for all swept `G_m`/`spell_power`). The core Q2 argument stands:
multiplicative = spell choice stays meaningful the whole game.

## B — paradigm "physical subtracts / magic multiplies"  → CONFIRMED coherent

Per-hit, mid stats:

| target | phys cut | magic Fira | magic +Shell |
|--------|---------:|-----------:|-------------:|
| Plate  | 38 | 141 | 71 |
| Leather| 90 | 141 | 71 |
| Robe   | 105 | 141 | 71 |

Physical cut **collapses vs plate** (DR 9 walls it) but magic is **flat across all armor** (ignores
DR) → magic is the anti-plate answer, exactly its intended role. **Shell** (×0.5) is magic's
multiplicative "armor" — the only real mitigation besides Faith/Zodiac, and being multiplicative it
**never chip-zeros** (no physical-style wall) the way subtractive DR can. Clean, distinct paradigm.

## C — the real finding: multiplicative magic has NO structural damping

This is what the sim was for. With placeholder `G_m=8`, magic Fira as % of target HP:

| MA | Plate | Leather | Robe |
|----|------:|--------:|-----:|
| 8  | 40% | 54% | 73% |
| 14 | 71% | 94% | **128%** |
| 20 | **101%** | **134%** | **183%** |

A single *mid-tier* Fira **one-shots a robe mage at MA 14 and one-shots everyone (incl. plate) at
MA 20.** Two caveats and one real lesson:

- **Caveat (fairness):** the table holds HP *fixed* while sweeping MA 8→26; in play MA and HP grow
  together, so the true knob is keeping MA-growth ∝ HP-growth. The absolute one-shots are a `G_m`
  placeholder artifact (lower `G_m` → sane band).
- **Real structural lesson:** unlike physical — which has **built-in damping** (subtractive DR caps
  the high end relative to armor; `pen_floor` caps the low end) — multiplicative magic has **no
  natural ceiling or floor**. Its safe band is held *entirely by calibration* (`G_m` + the Faith/
  Shell/Zodiac multipliers), and **stacked multipliers compound**: `MA · spell_power · Faith ·
  Zodiac-weakness` can multiply into a one-shot (Firaga × high-MA × ×1.5 weakness × low-Faith target).
  This is the **magic flavor of the physical B7 "hidden/compounding multiplier" risk.**

**Per-turn parity** vs a fighter came out ~0.96 — but at the same overtuned `G_m`, so it's
calibration-coincidental, not evidence.

## Verdict

**Adopt the Q2 shape** (multiplicative, spell-centric, subtract-vs-multiply paradigm) — claims A & B
are sound and A is structural. **Carry one guardrail into Q3/Q4:** keep the count of *large*
multipliers small and bounded so the stack can't explode — ideally **Faith is the single big two-sided
multiplier**, with Zodiac/Shell as modest bounded bands, and a soft cap held in reserve. Record "magic's
band is calibration-held (no structural damper) — watch multiplier stacking" as the **#1 magic
calibration risk**.

## What would flip this

A shape where spell-choice stays meaningful *without* multiplication (none found — additive provably
compresses), or evidence that the compounding-multiplier risk is unmanageable even with few terms
(then magic would need a structural damper baked into the shape, e.g. diminishing spell_power or a
Faith soft-cap — deferred unless Q3/Q4 calibration can't hold the band).

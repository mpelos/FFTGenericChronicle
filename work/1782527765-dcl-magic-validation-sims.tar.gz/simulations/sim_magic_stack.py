#!/usr/bin/env python3
"""
sim_magic_stack.py — Q4: how Zodiac (elemental affinity) and Shell band & stack on top of Faith.

Q4 proposal (to FALSIFY): the magic mitigations are MODEST multiplicative bands, all-multiplicative
(commutative — "stacking order" is a non-issue), with big swings (x2 weak / absorb) kept as DESIGNED
EXCEPTIONS and a soft cap only in RESERVE. Concretely:
    zodiac:  weak x1.30 / neutral x1.00 / resist x0.70     (single application, < Faith's two-app effect)
    shell:   x0.50      (strong but temporary, costs a buff turn)
    stack = faith_caster x faith_target x zodiac x shell   (x G_m spine)   — all multiplicative

The Q2/Q3 carried risk is the COMPOUNDING CORNER: faith-high x element-weak. Q4 must show that corner
stays bounded AND that defense mirrors offense (each offensive multiplier has an inverse counter), with
no degenerate one-shot and no unkillable turtle.

Falsification targets:
  T1 bounded corner: worst REALISTIC offensive stack (zealot/zealot x weak x no-shell) <= ~2.3x.
  T2 defense mirrors offense: stacking Shell + resist + low-faith pulls a burst back multiplicatively
     to a hard-but-finite floor (never 0 -> no immunity; multiplicative resist never chip-zeros).
  T3 turtle is beatable: the attacker has OUTS vs the max turtle (switch element, spiritual, wait-out
     Shell) — so the defensive stack is conditional, not an auto-win.
  T4 exceptions must stay exceptions: vanilla-style x2 weak / absorb in the EVERYDAY band blows the
     corner past one-shot -> justifies keeping them rare designed properties.
  T5 soft-cap is reserve, not load-bearing: with modest bands the product max (~2.2x) sits UNDER any
     sane cap (~2.5x) — the cap is dormant unless calibration later widens a band.
"""

# ---- Faith (from Q3, band [0.70,1.30]) ---------------------------------------
F_MIN, F_MID, F_MAX = 25, 55, 85
def faith_mult(F, bl=0.70, bh=1.30):
    if F >= F_MID:
        return 1.0 + (F - F_MID) / (F_MAX - F_MID) * (bh - 1.0)
    return 1.0 + (F - F_MID) / (F_MID - F_MIN) * (1.0 - bl)
ATH, NEU, ZEAL = faith_mult(25), faith_mult(55), faith_mult(85)   # 0.70, 1.00, 1.30

# ---- Zodiac + Shell bands ----------------------------------------------------
ZWEAK, ZNEU, ZRES = 1.30, 1.00, 0.70          # modest everyday band (recommended)
SHELL = 0.50
def zodiac(m, weak=ZWEAK, res=ZRES):
    return {"weak": weak, "neutral": ZNEU, "resist": res}[m]

def stack(fc, ft, zmatch="neutral", shell=False, cap=None, zweak=ZWEAK, zres=ZRES, shv=SHELL):
    s = faith_mult(fc) * faith_mult(ft) * zodiac(zmatch, zweak, zres)
    if shell: s *= shv
    if cap is not None:
        s = min(s, cap)
    return s

# ---- spine (from sim_magic_shape; G_m is a Q2 PLACEHOLDER) --------------------
SPELL = {"Fire": 1.0, "Fira": 1.8, "Firaga": 3.0}
G_M = 8.0
def spine(MA, spell): return MA * SPELL[spell] * G_M

# ============================================================================
if __name__ == "__main__":
    print("="*84)
    print("PART A — the realistic stack corners (RELATIVE multiplier over a neutral exchange)")
    print("="*84)
    corners = [
        ("neutral exchange (ref)",            stack(55,55,"neutral")),
        ("MAX OFFENSE  zealot->zealot, weak", stack(85,85,"weak")),
        ("zealot->zealot, neutral elem",      stack(85,85,"neutral")),
        ("neutral->neutral + Shell",          stack(55,55,"neutral",shell=True)),
        ("MAX DEFENSE  neutral->atheist, resist+Shell", stack(55,25,"resist",shell=True)),
    ]
    for lbl,v in corners:
        print(f"   {lbl:>46} -> x{v:.2f}")
    off = stack(85,85,"weak"); deff = stack(55,25,"resist",shell=True)
    print(f"\n   offensive corner x{off:.2f}  (<= ~2.3 ? {'YES' if off<=2.3 else 'NO'})  — the earned burst window (T1)")
    print(f"   defensive corner x{deff:.2f}  (> 0 ? {'YES' if deff>0 else 'NO'})  — hard turtle, never immune (multiplicative)")
    print(f"   full legible spread {off/deff:.1f}x, every step an independent % the player can read.")

    print("\n" + "="*84)
    print("PART B — defense MIRRORS offense: one neutral caster (Firaga) vs a ladder of target defenses")
    print("="*84)
    print(f"   {'target defense':>44} | {'mult':>5} | {'vs neutral target':>18}")
    print("   " + "-"*74)
    ladder = [
        ("zealot + weak element (squishiest)", stack(55,85,"weak")),
        ("zealot, neutral element",            stack(55,85,"neutral")),
        ("neutral target (reference)",         stack(55,55,"neutral")),
        ("neutral + Shell",                    stack(55,55,"neutral",shell=True)),
        ("atheist (low faith)",                stack(55,25,"neutral")),
        ("atheist + resists element",          stack(55,25,"resist")),
        ("atheist + resist + Shell (turtle)",  stack(55,25,"resist",shell=True)),
    ]
    ref = stack(55,55,"neutral")
    for lbl,v in ladder:
        print(f"   {lbl:>44} | {v:>5.2f} | {'x'+format(v/ref,'.2f'):>18}")
    print("\n   Each defensive layer (low faith / resist / Shell) is an INDEPENDENT multiplicative cut —")
    print("   offense stacks multipliers, defense stacks the inverses. No additive bookkeeping. (T2)")

    print("\n" + "="*84)
    print("PART C — is the max turtle (atheist+resist+Shell, x0.24) a wall? the attacker's OUTS")
    print("="*84)
    base_turtle = stack(55,25,"resist",shell=True)
    outs = [
        ("do nothing (the turtle holds)",            base_turtle),
        ("OUT: switch to the target's WEAK element",  stack(55,25,"weak",shell=True)),
        ("OUT: cast spiritual (Holy/Dark, no zodiac)",stack(55,25,"neutral",shell=True)),  # zodiac drops out
        ("OUT: wait out Shell (temporary), hit weak", stack(55,25,"weak",shell=False)),
        ("OUT: a zealot caster instead of neutral",   stack(85,25,"resist",shell=True)),
    ]
    for lbl,v in outs:
        mark = "" if lbl.startswith("do nothing") else f"   (x{v/base_turtle:.2f} vs holding)"
        print(f"   {lbl:>46} -> x{v:.2f}{mark}")
    print("\n   The turtle costs a buff turn + a low-faith build (bad mage) + the right matchup, and the")
    print("   attacker beats it by switching element / going spiritual / waiting Shell out. Conditional,")
    print("   not an auto-win — magic is never fully walled and never free. (T3)")

    print("\n" + "="*84)
    print("PART D — why x2-weak / absorb must stay EXCEPTIONS, not the everyday band")
    print("="*84)
    print(f"   {'everyday weak band':>22} | {'zealot/zealot x weak':>22}")
    print("   " + "-"*50)
    for zw,lbl in [(1.30,"modest x1.30 (recommended)"),(1.50,"x1.50"),(2.00,"vanilla-ish x2.00")]:
        v = stack(85,85,"weak",zweak=zw)
        print(f"   {lbl:>22} | {'x'+format(v,'.2f'):>22}")
    print("   absorb (x -1): a full Firaga HEALS the target — a coin-flip swing if it were common.")
    print("   => x1.30 keeps the corner at 2.20; x2.00 pushes it to 3.38 (toward one-shot). Big elemental")
    print("   swings are fine as RARE designed properties (a known flan, a cursed item), degenerate as the")
    print("   default sign-compat band. Keep everyday modest. (T4)")

    print("\n" + "="*84)
    print("PART E — soft cap is RESERVE, not load-bearing")
    print("="*84)
    CAP = 2.5
    print(f"   candidate soft cap on the product = {CAP}x\n")
    for zw,lbl in [(1.30,"modest bands (recommended)"),(1.50,"widened weak x1.50")]:
        raw = stack(85,85,"weak",zweak=zw)
        capped = stack(85,85,"weak",zweak=zw,cap=CAP)
        bites = "BITES" if capped < raw else "inert (dormant)"
        print(f"   {lbl:>28}: raw corner x{raw:.2f} -> capped x{capped:.2f}  [{bites}]")
    print(f"\n   With the recommended x1.30 band the max corner (2.20) sits UNDER the 2.5 cap -> the cap")
    print("   never fires. It only earns its keep if calibration later widens a band. Reserve, not")
    print("   structural. (T5)")

    print("\n" + "="*84)
    print("ABSOLUTE sanity (PLACEHOLDER G_m — absolute one-shots are the Q2 calibration target, not Q4)")
    print("="*84)
    HP = {"robe mage":110, "leather":150, "plate":200}
    print(f"   Fira (MA 16) as % HP at the offensive vs defensive corners (relative shape is the result):\n")
    for lbl, mult in [("max offense (x2.20)", stack(85,85,"weak")),
                      ("neutral (x1.00)",     stack(55,55,"neutral")),
                      ("max turtle (x0.24)",  stack(55,25,"resist",shell=True))]:
        dmg = spine(16,"Fira")*mult
        cells = " ".join(f"{lbl2}={100*dmg/hp:.0f}%" for lbl2,hp in HP.items())
        print(f"   {lbl:>20}: dmg {dmg:>5.0f} | {cells}")
    print("\n   The absolute band is held by G_m (Q2). Q4's certified result is the RELATIVE structure:")
    print("   modest multiplicative bands keep the compounding corner ~2.2x and let defense mirror it.")

    print("\n" + "="*84)
    print("SENSITIVITY — sweep zodiac weak/resist + Shell; want corner<=~2.3, turtle in (0,~0.35]")
    print("="*84)
    print(f"   {'zweak':>6} {'zres':>5} {'shell':>6} | {'off corner':>10} {'turtle':>7}")
    print("   " + "-"*46)
    for zw in (1.25, 1.30, 1.50):
        for zr in (0.70, 0.75):
            for sh in (0.50, 0.60):
                oc = stack(85,85,"weak",zweak=zw,zres=zr,shv=sh)
                tt = stack(55,25,"resist",shell=True,zweak=zw,zres=zr,shv=sh)
                ok = "  ok" if oc<=2.3 and 0<tt<=0.35 else ""
                print(f"   {zw:>6.2f} {zr:>5.2f} {sh:>6.2f} | {oc:>10.2f} {tt:>7.2f}{ok}")
    print("\n   READ: modest weak (1.25-1.30) keeps the offensive corner <= 2.2 with a hard-but-finite")
    print("   turtle (~0.24-0.29). weak x1.50 pushes the corner to ~2.5 (where the reserve cap would")
    print("   start to matter). Shell 0.5 vs 0.6 is a pure turtle-depth knob. Structure holds across the")
    print("   plausible band; magnitudes are calibration.")

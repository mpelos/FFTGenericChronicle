# sim_magic_stack — read (Q4: how Zodiac & Shell band and stack on top of Faith)

**Question.** The Q2/Q3 carried risk is the **compounding corner** (faith-high × element-weak). Do the
other magic mitigations — Zodiac (elemental affinity) and Shell — combine as **modest multiplicative
bounded bands** (commutative, big swings reserved as exceptions, soft-cap in reserve), keeping that
corner bounded and lettable defense mirror offense? Recommendation to falsify, with provisional bands
Zodiac weak ×1.30 / resist ×0.70, Shell ×0.50.

## T1 — the compounding corner is bounded  → CONFIRMED

Worst *realistic* offensive stack (zealot caster → zealot target, element-weak, no Shell) =
**×2.20** over a neutral exchange (≤ ~2.3). Faith (≤1.69) × a modest weak band (1.30) does **not**
explode. The earned burst window — and it cost charge + MP + a Faith build + a favorable matchup.

## T2 — defense mirrors offense (multiplicatively)  → CONFIRMED

One neutral caster (Firaga) vs a ladder of target defenses, each layer an independent fraction:

| target | mult | vs neutral |
|---|---:|---:|
| zealot + weak element | 1.69 | ×1.69 |
| zealot, neutral | 1.30 | ×1.30 |
| neutral (ref) | 1.00 | ×1.00 |
| neutral + Shell | 0.50 | ×0.50 |
| atheist | 0.70 | ×0.70 |
| atheist + resist | 0.49 | ×0.49 |
| **atheist + resist + Shell** | **0.24** | **×0.24** |

Offense stacks multipliers; defense stacks the inverses. No additive bookkeeping, every step a legible
independent %. The turtle floor (×0.24) is **hard but finite** — a multiplicative resist never
chip-zeros, so there is **no immunity breakpoint**.

## T3 — the turtle is beatable (conditional, not an auto-win)  → CONFIRMED

Vs the ×0.24 turtle the attacker has outs: **switch to the target's weak element** (×1.86 → 0.45),
**wait Shell out** (×3.71 → 0.91), **cast spiritual** (Holy/Dark ignore Zodiac → 0.35). And the turtle
*cost* a buff turn + a low-Faith build (a bad mage) + the right matchup. Magic is never fully walled and
never free.

## T4 — big swings must stay exceptions  → CONFIRMED

| everyday weak band | zealot/zealot × weak |
|---|---:|
| ×1.30 (recommended) | **2.20** |
| ×1.50 | 2.54 |
| ×2.00 (vanilla-ish) | **3.38** (toward one-shot) |

`absorb` (×−1) heals the target for a full hit — a coin-flip if common. So ×2 / absorb are fine as
**rare, built-around designed properties** (a known flan, a cursed item), degenerate as the default
sign-compat number. The everyday wheel stays modest; the extremes are content.

## T5 — the soft cap is reserve, not load-bearing  → CONFIRMED

A ~2.5× cap on the product is **dormant** under the recommended bands (max corner 2.20 < 2.5 → never
fires); it only **bites** if a band is later widened (weak ×1.50 → 2.54 → capped 2.50). So it is a
safety valve held in reserve, not a structural part of the everyday math.

## Sensitivity

Modest weak (1.25–1.30) keeps the offensive corner ≤ 2.20 with a hard-but-finite turtle (0.24–0.31);
Shell 0.50 vs 0.60 is a pure turtle-depth knob; weak ×1.50 is where the reserve cap starts to matter.
The **structure holds across the whole plausible band** — magnitudes are calibration.

## Absolute caveat

With placeholder `G_m=8`, even a neutral Fira reads as a one-shot of a robe mage — that is the **Q2**
`G_m` calibration artifact, **not** Q4. Q4's certified result is the **relative** structure: modest
multiplicative bands keep the compounding corner ~2.2× and let defense mirror offense.

## Verdict

**Adopt** modest multiplicative bands (Zodiac weak ~1.30 / resist ~0.70, Shell ~0.50),
all-multiplicative & commutative (no stacking order), big swings as designed exceptions, soft-cap in
reserve. The magic stack is **self-correcting** and the compounding corner is bounded. Recorded in `11`
(*Zodiac, Shell, and how the bands stack*), `09` (*Magnitude — a modest band*), `12`.

## What would flip this

A band wide enough that the corner one-shots *even with* the reserve cap engaged (then magic needs a
structural damper baked into the shape — diminishing spell_power or a hard total cap), or a corpus
decision to make ×2/absorb the *everyday* zodiac band (would reopen this and likely force the cap to be
load-bearing).

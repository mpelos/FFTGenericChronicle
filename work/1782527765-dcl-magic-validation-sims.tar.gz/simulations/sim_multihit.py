#!/usr/bin/env python3
"""
sim_multihit.py — crit-bypass x multi-hit: does it void the defense roll too often? (B6, D04-21/22/24)
The peer correctly noted crit bypasses the DEFENSE ROLL (dodge/parry/block), not DR. So a turtle's
investment in active defense is what crit-bypass erodes. With K strikes/turn (dual-wield, multi-hit),
P(>=1 crit bypass) = 1-(1-p_crit)^K. Built to FALSIFY two claims:
  (1) B6: a high-skill multi-hitter voids a turtle's defense ~1/3 of turns via crit alone.
  (2) D04: dual-wield is NOT strictly better than a single big hit vs an OPEN target.
Also checks the turtle case: how much effective damage leaks through pure crit-bypass.
"""
from sim_core import p_crit, p_le, p_land, injury, CONFIG

print("="*72)
print("A) P(at least one crit-bypass) by skill and #strikes/turn")
print("="*72)
print(f"  {'skill':>6}{'p_crit':>9}" + "".join(f"{f'K={k}':>9}" for k in (1,2,3,4)))
for skill in (11,12,13,15,16,17):
    pc = p_crit(skill)
    row = "".join(f"{(1-(1-pc)**k)*100:8.1f}%" for k in (1,2,3,4))
    print(f"  {skill:6d}{pc*100:8.1f}%{row}")
print("  -> at skill 16 (crit on nat 3-6), even K=2 strikes bypasses the FULL defense roll a large")
print("     share of turns. The turtle's parry/block/dodge simply does not get to roll.")

print("\n"+"="*72)
print("B) B6 claim: a skill-16 dual-wielder voids a turtle's defense how often per turn?")
print("="*72)
for skill in (15,16,17):
    pc = p_crit(skill)
    for K in (2,3):
        print(f"  skill {skill}, K={K}: P(>=1 bypass)/turn = {(1-(1-pc)**K)*100:.0f}%  "
              f"(turtle defended by RNG-immune crit, not by positioning)")

print("\n"+"="*72)
print("C) Dual-wield (K=2 small) vs single big hit — vs OPEN target and vs TURTLE")
print("="*72)
# open target: low defense (Dodge 8). turtle: best-defense 11. PA10.
PA=10
single_wmod = CONFIG["wmod"]["alto"]      # one big hit
dual_wmod   = CONFIG["wmod"]["medio"]     # two smaller hits (dual-wield penalty)
skill=14
def exp_dmg_vs(defense, facing="front"):
    pc=p_crit(skill)
    # single big strike
    inj_s = injury(PA, single_wmod, "cut", "leather", CONFIG)
    land_s = p_land(skill, defense, facing)
    single = inj_s*land_s
    # dual: two strikes, each smaller
    inj_d = injury(PA, dual_wmod, "cut", "leather", CONFIG)
    land_d = p_land(skill, defense, facing)
    dual = 2*inj_d*land_d
    return single, dual
for label,defense in [("OPEN (Dodge8)",8),("TURTLE (def11)",11)]:
    s,d = exp_dmg_vs(defense)
    print(f"  {label:16}: single-big={s:.1f}  dual-wield={d:.1f}  -> "
          f"{'DUAL better' if d>s else 'single better'} ({d/s:.2f}x)")
print("  (If dual-wield is also better vs the turtle via crit-stacking, multi-hit is a turtle-solvent.)")

print("\n"+"="*72)
print("SENSITIVITY — vary dual-wield penalty (how small the 2 hits are) & skill")
print("="*72)
for dual_tier in ("baixo","medio","alto"):
    dw = CONFIG["wmod"][dual_tier]
    for sk in (12,14,16):
        pc=p_crit(sk)
        inj_s = injury(PA, single_wmod, "cut","leather",CONFIG); ls=p_land(sk,8)
        inj_d = injury(PA, dw, "cut","leather",CONFIG); ld=p_land(sk,8)
        ratio = (2*inj_d*ld)/(inj_s*ls)
        print(f"  dual tier={dual_tier:6} skill={sk}: dual/single vs open = {ratio:.2f}x  "
              f"crit-bypass/turn(K2)={(1-(1-pc)**2)*100:.0f}%")

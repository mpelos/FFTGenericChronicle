# sim_multihit.py — read (2026-06-26)

Tests B6 / D04-21/22/24: crit-bypass × multi-hit. The peer correctly clarified crit bypasses the
**defense roll** (dodge/parry/block), not DR — so multi-hit erodes a turtle's *active-defense* investment.

## Findings (ground truth)
- **Crit-bypass stacks with #strikes.** At skill 16 (crit on nat 3–6, p_crit 9.3%): P(≥1 crit-bypass)/turn
  = **18% (K=2), 25% (K=3), 32% (K=4)**. A multi-hitter voids the FULL defense roll that often by crit
  alone — the turtle's parry/block/dodge never gets to roll. At skill ≤13 it's small (≤5.5%); the problem
  is **high-skill** multi-hitters specifically. **B6 confirmed structural at high skill.**
- **Dual-wield expected damage** vs single-big: with a medium per-hit penalty, **1.43×** vs BOTH the open
  target and the turtle. Sensitivity on the penalty: **baixo** (steep penalty) → 1.00× (break-even);
  **medio** → 1.43×; **alto** (no penalty) → 2.00×. So dual-wield dominance is **calibration-gated on the
  per-hit penalty steepness** — a light penalty makes dual-wield strictly better (more damage *and* more
  crit-bypass chances).

## Verdict
- **B6 (crit × multi-hit voids defense) — CONFIRMED** as a structural risk for high-skill units: a turtle
  is beaten by RNG-immune crit, not by positioning, 18–32% of turns. Fix is a design change: make
  crit-bypass *partial* (e.g. halve defense instead of skip it) or cap multi-hit crit rolls (report §F).
- **D04-21/22/24 (dual-wield) — calibration-gated:** holds only if the per-hit wmod penalty is steep
  enough; with a light penalty dual-wield strictly dominates single-big vs every target. The design must
  set (and the eventual weapon tables must honor) a steep dual-wield penalty.
- **What would flip B6:** capping the crit window at high skill, or partial crit-bypass, drops the
  per-turn void rate below a meaningful threshold.

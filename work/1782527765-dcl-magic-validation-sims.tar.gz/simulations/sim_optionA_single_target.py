#!/usr/bin/env python3
"""
sim_optionA_single_target.py — Option A guard-rail: lowering G_m must NOT make the mage useless
SINGLE-TARGET, and (the hard floor) the mage MUST still do good damage vs PLATE.

CONTEXT (decision already made by the designer — NOT re-litigated here):
  The caster-supremacy fix is OPTION A: a pure GLOBAL G_m reduction, with NO per-target MP cost
  (lambda = 0). Option B (per-target MP) was rejected. The mage's signature spells are AoE and the
  realistic cluster is E[k] ~ 1.3, so G_m is re-anchored DOWN from the single-target value 0.65
  toward the E[k]=1.3 parity (~0.53). With Option A the cluster (k>=2) is deliberately an UNBRAKED
  reward — accepted; this sim adds NO AoE cost.

THE QUESTION (the guard-rail this sim answers):
  Lowering G_m also lowers SINGLE-TARGET output. Does Option A make the mage useless vs one target?
  And does the mage still do GOOD DAMAGE VS PLATE (its anti-armor identity: magic ignores physical DR)?
  Designer's hard floor: "no maximo o mago tem que dar um bom dano em plates" — good-vs-plate is
  non-negotiable; slightly-weak-vs-soft-single-target is acceptable, useless is not.

METHOD — reuse the trusted machinery UNCHANGED:
  - physical baseline:  sim_core.injury / p_land            (subtractive DR, wound mult, pen floor)
  - magic + economy:    sim_confront_supremacy (bolt/Fira/Firaga burst economy, GM_STAR=0.652 anchor)
  - group/AoE + monk:   sim_confront_aoe.mage_group (LAMBDA=0 by default => Option A), cluster_multiple
  All single-target numbers use mage_group(..., k=1) with NO levers (pt_mp=0 => lambda=0). The k=2/k=3
  cluster columns are FOR REFERENCE only (the accepted unbraked reward); no cost is applied to them.

  KEY MODEL FACT exploited below: magic damage is DR-blind and (vs uninvested foes) auto-lands, so the
  mage's per-turn / per-battle output is IDENTICAL across target archetypes. The archetype only changes
  (a) the FIGHTER's damage (DR, dodge, right/wrong tool) -> the ratio denominators, and (b) target HP
  -> TTK. So "vs soft" vs "vs plate" differences are entirely about what the FIGHTER does to that target.

THRESHOLDS (stated, then tested):
  - "Dead weight"        = bolt floor (MP-0, DR-ignoring) < 0.50 of a fighter's per-turn dmg.
  - "Useless 1-target"   = per-battle single-target total < 0.55 of a fighter's per-battle total
                           (heroic-floor pick: a mage may be a WEAK duelist but must be a real
                            contributor; 0.55 is the low end of the task's 0.55-0.60 band).
  - "Good vs plate"      = mage per-turn/per-battle vs plate >= a WRONG-tool (cut) fighter's, AND
                           within reach of the RIGHT-tool (crush) specialist's.

AXES CROSSED: G_m in {0.48,0.50,0.53,0.55,0.58,0.60,0.65} x stage {early,mid,late} x archetype
  {leather,robe,plate,monk,thief} x metric {bolt-floor, full-nuke spike, per-battle total, TTK} x
  plate base-model {linear, GURPS-concave} x (reference) cluster k {1,2,3}.
AXES SKIPPED (named, with sign of bias on THIS question = "is the single-target mage still useful/
  good-vs-plate"):
  - AoE cost / per-target MP: NONE by design (lambda=0). Adding any would only LOWER cluster output,
    never single-target -> irrelevant to this guard-rail.
  - Zodiac off-neutral, Faith off-mid: headline at neutral/mid; corners shown in sensitivity. Resist
    (x0.70) would hurt the mage on a SPECIFIC foe -> the single-target floor is read at neutral (fair).
  - magic-evade slot: 0 for all (uninvested). A bought slot only HURTS the mage -> headline at evade 0
    is the GENEROUS read for the mage; noted, not swept here (covered in supremacy/aoe sims).
  - Healing / status / CC / reactions / interrupts: out of scope (separate breaks). Counter punishes
    the meleeing FIGHTER, never the ranged bolt -> omitting it slightly favors the fighter here =
    CONSERVATIVE for the mage's relative standing.
  - Live FFT AI / map geometry: Windows-only; the cluster E[k]~1.3 is a designer assumption, not read
    from ENTD. This sim takes E[k] as given and asks only the single-target/plate guard-rail.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_confront_supremacy as S
import sim_confront_aoe as A                 # importing injects 'monk' into S.TARGETS; gives mage_group etc.
from sim_core import injury, p_land, CONFIG

# ---- bound machinery (all reused, unchanged) ----
STAGES   = S.STAGES                          # {'early':8,'mid':14,'late':20}  raw PA=MA
FSK      = S.FIGHTER_SKILL                   # {'early':11,'mid':13,'late':15}
TARGETS  = S.TARGETS                         # plate/leather/thief/robe (+ monk injected by aoe import)
GEN_W    = S.GEN_W                           # generic weapon modifier (medio=5)
CRUSH    = S.CRUSH_MULT                      # 1.5  (crush carries 1.5x wmod = the right-tool-vs-plate buff)
SP, COST = S.SP, S.COST
GM_STAR  = S.GM_STAR                         # 0.652 single-target anchor (decision 11.49)
spell_onhit  = S.spell_onhit
bolt_onhit   = S.bolt_onhit
fighter_turn = S.fighter_turn
mage_group   = A.mage_group                  # lambda=0 (pt_mp=0) by default => OPTION A

T_BATTLE  = 10
GM_SWEEP  = [0.48, 0.50, 0.53, 0.55, 0.58, 0.60, 0.65]
SOFT      = ("leather", "robe", "monk", "thief")
ARCHE     = ("leather", "robe", "plate", "monk", "thief")
STG       = ("early", "mid", "late")

# thresholds (declared above)
THR_DEAD    = 0.50      # bolt floor < this  => dead weight
THR_USELESS = 0.55      # per-battle ST vs soft < this => useless single-target

# ============================================================================
# helpers — all single-target metrics use k=1, lambda=0 (Option A)
# ============================================================================
def mage_total(gm, stage, T=T_BATTLE):
    """Per-battle single-target mage output (bursts in MP budget + bolt on the rest). DR-blind/auto-land
    => identical vs every archetype. (== S.mage_burst_battle; self-checked at import in aoe.)"""
    return mage_group(STAGES[stage], gm, T, 1)[0]            # pt_mp=0 default => lambda=0

def mage_dpt(gm, stage, T=T_BATTLE):
    return mage_total(gm, stage, T) / T

def bolt_abs(gm, stage):
    return bolt_onhit(STAGES[stage], gm)

def nuke_abs(gm, stage):
    return spell_onhit(STAGES[stage], SP["Firaga"], gm)       # full nuke on-hit (the spike)

def ftr_dpt(stage, tgt, loadout="right"):
    return fighter_turn(STAGES[stage], FSK[stage], tgt, loadout)

# wrong-tool (cut) and right-tool (crush) vs plate, with a pluggable base(PA) model so we can test the
# plate floor under BOTH sim_core's default LINEAR scaling and the more-realistic GURPS-concave table.
def plate_ftr_dpt(stage, tool, base="linear"):
    pa = STAGES[stage]; sk = FSK[stage]; d = TARGETS["plate"]["dodge"]
    base_fn = S.base_pa if base == "linear" else S.base_pa_gurps
    if tool == "wrong":   onhit = S.injury_base(pa, GEN_W,        "cut",   "plate", CONFIG, base_fn)
    else:                 onhit = S.injury_base(pa, GEN_W*CRUSH,  "crush", "plate", CONFIG, base_fn)
    return onhit * p_land(sk, d)

# leather fighter (the dead-weight benchmark) with the same pluggable base model, so the bolt-floor
# crossover can be read under BOTH scalings consistently (A.bolt_floor_ratio only knows the linear one).
def leather_ftr_dpt(stage, base="linear"):
    pa = STAGES[stage]; sk = FSK[stage]; d = TARGETS["leather"]["dodge"]
    base_fn = S.base_pa if base == "linear" else S.base_pa_gurps
    return S.injury_base(pa, GEN_W, "cut", "leather", CONFIG, base_fn) * p_land(sk, d)

def bolt_floor_r(gm, stage, base="linear"):
    return bolt_abs(gm, stage) / leather_ftr_dpt(stage, base)

# sanity: the linear injury_base path must reproduce fighter_turn (the trusted function)
assert abs(plate_ftr_dpt("mid","wrong","linear") - ftr_dpt("mid","plate","fixed")) < 1e-9
assert abs(plate_ftr_dpt("mid","right","linear") - ftr_dpt("mid","plate","right")) < 1e-9
assert abs(bolt_floor_r(0.53,"mid","linear") - 0.53*A.bolt_floor_ratio(1.0,"mid")) < 1e-9

def solve_gm(ratio_at_gm1, target):
    """Everything mage-side is linear in G_m; fighter side is G_m-independent. So any ratio
    mage(G_m)/fighter == G_m * ratio_at_gm1. Return the G_m that hits `target`."""
    return float("inf") if ratio_at_gm1 <= 0 else target / ratio_at_gm1

def hr(c="="): print(c*108)

# ============================================================================
if __name__ == "__main__":
    print("OPTION A — SINGLE-TARGET & PLATE GUARD-RAIL  (pure global G_m reduction, lambda=0, k=1)")
    hr()
    print(f"physical baseline = sim_core (G=1).  single-target anchor GM_STAR = {GM_STAR:.4f} (decision 11.49)")
    print(f"economy: pool {S.MP_POOL} + {S.MP_TRICK}/turn over T={T_BATTLE}  (~3 Firaga bursts).  bolt sp={S.BOLT_SP_DEFAULT} (0 MP).")
    print(f"stages PA=MA {STAGES}; fighter skill {FSK}.  fighter benchmark = right-tool, with p_land (rolls to hit).")
    print(f"MAGE IS DR-BLIND + AUTO-LANDS (evade 0): its per-turn/per-battle output is the SAME vs every archetype;")
    print(f"the archetype only moves the FIGHTER's number (DR/dodge/tool) and the target HP (TTK).")
    print(f"thresholds: dead-weight bolt<{THR_DEAD:.2f} | useless ST<{THR_USELESS:.2f} | good-vs-plate: mage>=wrong-tool & near right-tool")

    # ------------------------------------------------------------------
    # 1) HEADLINE TABLE (mid stage = the calibration anchor)
    # ------------------------------------------------------------------
    hr()
    print("1) HEADLINE — pick G_m by eye (MID stage). All ratios are mage / fighter.")
    print("   boltflr   = bolt floor / fighter-per-turn (vs leather)         [dead weight if < 0.50]")
    print("   nuke/sw   = full Firaga on-hit SPIKE / one fighter swing (vs leather)   [amortized/2 in 3)]")
    print("   ST/soft   = per-battle single-target total / fighter total (vs leather) [useless if < 0.55]")
    print("   plate(wr) = mage per-turn / WRONG-tool (cut) fighter per-turn, vs plate [good-vs-plate if >=1]")
    print("   plate(rt) = mage per-turn / RIGHT-tool (crush) fighter per-turn, vs plate [near 1 = competitive]")
    print("   k2 vs ftr = (REFERENCE, unbraked reward) mage k=2 AoE total / fighter total, vs leather")
    print()
    hdr = f"   {'G_m':>5} | {'boltflr':>7} | {'nuke/sw':>7} | {'ST/soft':>7} | {'plate(wr)':>9} | {'plate(rt)':>9} | {'k2 vs ftr':>9} | flags"
    print(hdr); print("   " + "-"*(len(hdr)-3))
    f_leu = ftr_dpt("mid","leather","right")
    pw_mid = plate_ftr_dpt("mid","wrong"); pr_mid = plate_ftr_dpt("mid","right")
    for gm in GM_SWEEP:
        bf  = bolt_abs(gm,"mid")/f_leu
        nk  = nuke_abs(gm,"mid")/f_leu
        st  = mage_total(gm,"mid")/(f_leu*T_BATTLE)
        pw  = mage_dpt(gm,"mid")/pw_mid
        pr  = mage_dpt(gm,"mid")/pr_mid
        k2  = A.vs_fighter(gm, 2, tgt="leather")           # lambda=0 (no lever) reference reward
        flags = []
        if bf < THR_DEAD: flags.append("DEAD-WEIGHT-bolt")
        if st < THR_USELESS: flags.append("USELESS-ST")
        if pw < 1.0: flags.append("plate<wrong")
        if abs(gm-0.53) < 1e-9: flags.append("<= designer 0.53")
        if abs(gm-GM_STAR) < 0.01 or abs(gm-0.65)<1e-9: flags.append("(old single-anchor)")
        print(f"   {gm:5.2f} | {bf:7.2f} | {nk:7.2f} | {st:7.2f} | {pw:9.2f} | {pr:9.2f} | {k2:9.2f} | {', '.join(flags)}")
    print("   READ: ST/soft & plate(wr)/plate(rt) scale linearly with G_m (mage is linear in G_m; fighter is")
    print("   G_m-independent). k2-vs-ftr is the accepted unbraked cluster reward. cluster MULTIPLE is G_m-")
    print(f"   independent: k2={A.cluster_multiple(0.53,2):.2f}x / k3={A.cluster_multiple(0.53,3):.2f}x of the mage's own single-target.")

    # ------------------------------------------------------------------
    # 2) BOLT FLOOR (the dead-weight guard) — per stage, abs + ratio
    # ------------------------------------------------------------------
    hr()
    print("2) BOLT FLOOR (free, MP-0, DR-ignoring) — the depleted-mage dead-weight guard.  ratio vs a")
    print("   leather-fighter's per-turn dmg (the fighter's STRONG matchup => a hard test for the bolt).")
    print(f"   {'G_m':>5} | " + " | ".join(f"{s+' abs':>9}" for s in STG) + " || " + " | ".join(f"{s+' ratio':>9}" for s in STG))
    for gm in GM_SWEEP:
        abss = [f"{bolt_abs(gm,s):9.1f}" for s in STG]
        rats = []
        for s in STG:
            r = bolt_abs(gm,s)/ftr_dpt(s,"leather","right"); tag = "" if r>=THR_DEAD else "!"
            rats.append(f"{r:8.2f}{tag}")
        print(f"   {gm:5.2f} | " + " | ".join(abss) + " || " + " | ".join(rats))
    # dead-weight crossover under BOTH base models (the linear-late row is the same artifact as the plate floor)
    gm_dead = {(b, s): solve_gm(bolt_floor_r(1.0, s, b), THR_DEAD) for b in ("linear","gurps") for s in STG}
    gm_dead_lin = max(gm_dead[("linear", s)] for s in STG)
    gm_dead_gur = max(gm_dead[("gurps",  s)] for s in STG)
    for b in ("linear","gurps"):
        print(f"   dead-weight crossover G_m (bolt floor == 0.50), base={b:6}: " +
              ", ".join(f"{s}={gm_dead[(b,s)]:.3f}" for s in STG))
    print(f"   -> BINDING dead-weight floor: linear(optimistic-late) = {gm_dead_lin:.3f} | gurps(realistic) = {gm_dead_gur:.3f}")
    print(f"   READ: '!' marks bolt floor < 0.50 (measured vs LEATHER = the fighter's BEST soft matchup, so this")
    print(f"   is the bolt's worst case; vs plate/thief the DR-ignoring auto-landing bolt still beats the fighter).")
    print(f"   The floor binds at LATE (the linear fighter out-scales the linear bolt); concave scaling relaxes it.")

    # ------------------------------------------------------------------
    # 3) FULL NUKE (the MP-spent spike) — per stage, abs + ratio + amortized
    # ------------------------------------------------------------------
    hr()
    print("3) FULL NUKE — Firaga on-hit (the spike) vs one fighter swing (leather).  raw = when it lands;")
    print("   amort = raw/2 (2-turn charge) for a fair per-turn read.  The honest economy is in 4) (per-battle).")
    print(f"   {'G_m':>5} | " + " | ".join(f"{s+' abs':>9}" for s in STG) + " || " +
          " | ".join(f"{s+' raw/sw':>9}" for s in STG) + " || " + " | ".join(f"{s+' amort':>9}" for s in STG))
    for gm in GM_SWEEP:
        abss  = [f"{nuke_abs(gm,s):9.1f}" for s in STG]
        raw   = [f"{nuke_abs(gm,s)/ftr_dpt(s,'leather','right'):9.2f}" for s in STG]
        amort = [f"{(nuke_abs(gm,s)/2)/ftr_dpt(s,'leather','right'):9.2f}" for s in STG]
        print(f"   {gm:5.2f} | " + " | ".join(abss) + " || " + " | ".join(raw) + " || " + " | ".join(amort))
    print("   READ: even at the lowest G_m the nuke SPIKE is multiples of a fighter swing; amortized over its")
    print("   charge it stays >= a fighter turn. The nuke is never the weak link — the bolt floor is.")

    # ------------------------------------------------------------------
    # 4) PER-BATTLE SINGLE-TARGET TOTAL (the main 'is the mage useful 1v1' number)
    # ------------------------------------------------------------------
    hr()
    print("4) PER-BATTLE SINGLE-TARGET TOTAL / fighter total — the headline usefulness number, per stage,")
    print("   vs EACH archetype (the ratio changes only because the FIGHTER's number changes).")
    print(f"   {'stage':5} {'G_m':>5} | " + " | ".join(f"{t:>8}" for t in ARCHE) + "   (mage total)")
    for s in STG:
        for gm in GM_SWEEP:
            mt = mage_total(gm,s); cells=[]
            for t in ARCHE:
                ld = "right" if t!="plate" else "right"      # right-tool fighter benchmark (crush vs plate)
                r = mt/(ftr_dpt(s,t,ld)*T_BATTLE)
                tag = "" if (t=="plate" or r>=THR_USELESS) else "!"
                cells.append(f"{r:7.2f}{tag}")
            print(f"   {s:5} {gm:5.2f} | " + " | ".join(cells) + f"   ({mt:6.0f})")
        print()
    # binding 'useless' crossover = the softest archetype for the mage (= hardest-hitting fighter = robe)
    print("   useless-ST crossover G_m (per-battle ST == 0.55) by SOFT archetype (mid):")
    gm_useless = {}
    for t in SOFT:
        ratio1 = mage_total(1.0,"mid")/(ftr_dpt("mid",t,"right")*T_BATTLE)
        gm_useless[t] = solve_gm(ratio1, THR_USELESS)
        print(f"      vs {t:8}: {gm_useless[t]:.3f}")
    print(f"   -> BINDING (worst soft archetype = highest fighter dmg) = {max(gm_useless.values()):.3f}.")
    print(f"   READ: '!' marks per-battle ST < 0.55 vs that soft target. Across the WHOLE sweep [0.48..0.65]")
    print("   no soft cell trips it (the bolt floor binds long before the per-battle total does).")

    # ------------------------------------------------------------------
    # 5) TTK single-target — mage vs fighter, every archetype (mid)
    # ------------------------------------------------------------------
    hr()
    print("5) TTK single-target (MID) = HP / per-turn dmg; lower kills faster. mage TTK is the SAME on-")
    print("   number-but-different-HP across archetypes (DR-blind). plate shows mage vs BOTH fighter tools.")
    print(f"   {'G_m':>5} | " + " | ".join(f"{t[:4]+' m/f':>10}" for t in SOFT) + " || " +
          f"{'plate m':>8} {'p wrong':>8} {'p right':>8}")
    for gm in GM_SWEEP:
        md = mage_dpt(gm,"mid")
        cells=[]
        for t in SOFT:
            hp=TARGETS[t]["hp"]; tm=hp/md; tf=hp/ftr_dpt("mid",t,"right")
            cells.append(f"{tm:4.1f}/{tf:4.1f}")
        hp=TARGETS["plate"]["hp"]
        tmp=hp/md; tpw=hp/pw_mid; tpr=hp/pr_mid
        print(f"   {gm:5.2f} | " + " | ".join(cells) + f" || {tmp:8.1f} {tpw:8.1f} {tpr:8.1f}")
    print("   READ (m/f): mage TTK / fighter TTK. >1 fighter-side number means the mage kills slower than the")
    print("   fighter on that soft target (expected: the mage is a weak soft-single-target duelist). vs PLATE")
    print("   the mage kills FASTER than the wrong-tool fighter and is within reach of the right-tool crush.")

    # ------------------------------------------------------------------
    # 6) ** PLATE FOCUS ** — the hard floor, per stage, BOTH base models
    # ------------------------------------------------------------------
    hr()
    print("6) ** PLATE FOCUS (the non-negotiable floor) ** — mage per-turn vs plate / fighter per-turn vs")
    print("   plate, per stage, under BOTH physical scaling models.  good-vs-plate := mage >= WRONG-tool (cut)")
    print("   AND within reach of RIGHT-tool (crush).  base=linear is sim_core default (optimistic late);")
    print("   base=gurps is the concave GURPS-swing table (realistic late, physical scales WORSE through DR).")
    for base in ("linear","gurps"):
        print(f"\n   [base = {base}]   ratios are mage / fighter")
        print(f"   {'G_m':>5} | " + " | ".join(f"{s+' wrong':>10}" for s in STG) + " || " +
              " | ".join(f"{s+' right':>10}" for s in STG))
        for gm in GM_SWEEP:
            wr = []; rt = []
            for s in STG:
                w = mage_dpt(gm,s)/plate_ftr_dpt(s,"wrong",base)
                r = mage_dpt(gm,s)/plate_ftr_dpt(s,"right",base)
                wr.append(f"{w:9.2f}{'!' if w<1.0 else ''}")
                rt.append(f"{r:10.2f}")
            print(f"   {gm:5.2f} | " + " | ".join(wr) + " || " + " | ".join(rt))
    # plate floor crossover (mage == wrong-tool), per stage x base
    print("\n   PLATE FLOOR crossover G_m (mage per-turn == WRONG-tool fighter, vs plate):")
    plate_floor = {}
    for base in ("linear","gurps"):
        row=[]
        for s in STG:
            ratio1 = mage_dpt(1.0,s)/plate_ftr_dpt(s,"wrong",base)
            g = solve_gm(ratio1, 1.0); plate_floor[(base,s)] = g
            row.append(f"{s}={g:.3f}")
        print(f"      base={base:6}: " + ", ".join(row))
    bind_lin = max(plate_floor[("linear",s)] for s in STG)
    bind_gur = max(plate_floor[("gurps",s)] for s in STG)
    print(f"   -> good-vs-plate requires G_m >= {bind_lin:.3f} (linear, binding stage=late) "
          f"or >= {bind_gur:.3f} (gurps, realistic).  '!' above marks mage < wrong-tool (plate floor breached).")

    # ------------------------------------------------------------------
    # 7) CLUSTER REFERENCE (the accepted unbraked reward) — NO cost applied
    # ------------------------------------------------------------------
    hr()
    print("7) CLUSTER REFERENCE (Option A leaves this UNBRAKED — shown only so the designer sees the reward).")
    print("   cluster MULTIPLE (mage k / mage k=1) is G_m-INDEPENDENT; vs-fighter scales with G_m.")
    print(f"   cluster multiple:  k2 = {A.cluster_multiple(0.53,2):.3f}x   k3 = {A.cluster_multiple(0.53,3):.3f}x   (constant across G_m)")
    print(f"   {'G_m':>5} | {'k1 vs ftr':>9} | {'k2 vs ftr':>9} | {'k3 vs ftr':>9}  (mid, vs leather)")
    for gm in GM_SWEEP:
        print(f"   {gm:5.2f} | {A.vs_fighter(gm,1):9.2f} | {A.vs_fighter(gm,2):9.2f} | {A.vs_fighter(gm,3):9.2f}")
    print("   READ: at the recommended G_m the mage is a weak-ish single-target duelist (k1<1) but the AoE")
    print("   reward stands — k2 ~1.7x and k3 ~2.5x its own single-target. That is the intended Option-A shape.")

    # ------------------------------------------------------------------
    # 8) FLOOR SUMMARY — where the three floors sit, and where 0.53 lands
    # ------------------------------------------------------------------
    hr()
    print("8) FLOOR SUMMARY — the binding G_m floors and where the designer's 0.53 sits.")
    print("   Two floors bind, BOTH at the LATE stage, BOTH model-dependent (linear overstates late physical):")
    print(f"   (a) useless single-target (per-batt < 0.55) ........... G_m >= {max(gm_useless.values()):.3f}  (far below sweep; never binds)")
    print(f"   (b) dead-weight bolt floor (<0.50 vs leather) ......... G_m >= {gm_dead_gur:.3f} (gurps) | {gm_dead_lin:.3f} (linear)")
    print(f"   (c) good-vs-plate (mage >= wrong-tool cut) ............ G_m >= {bind_gur:.3f} (gurps) | {bind_lin:.3f} (linear)")
    overall_real   = max(max(gm_useless.values()), gm_dead_gur, bind_gur)
    overall_strict = max(max(gm_useless.values()), gm_dead_lin, bind_lin)
    print(f"   => OVERALL binding floor, REALISTIC (concave-late) ....... G_m >= {overall_real:.3f}")
    print(f"   => OVERALL binding floor, STRICT (optimistic linear-late) . G_m >= {overall_strict:.3f}")
    print(f"   where 0.53 sits:")
    for gm in (0.53, 0.55, 0.58):
        print(f"      G_m={gm}:  clears REALISTIC floor ({overall_real:.3f})? {str(gm>=overall_real):5}   "
              f"clears STRICT floor ({overall_strict:.3f})? {gm>=overall_strict}")
    print(f"   VERDICT: 0.53 is NEVER 'useless single-target' (a). It sits ~AT the realistic late floor")
    print(f"   ({0.53-overall_real:+.3f} on b/c under concave scaling) and {0.53-overall_strict:+.3f} UNDER the strict")
    print(f"   linear-late floor. So 0.53 is the AGGRESSIVE minimum: fine early/mid and under realistic scaling,")
    print(f"   but late-game dead-weight + plate-edge go marginal under the optimistic-linear model. Safe pick ~0.58.")

    # ------------------------------------------------------------------
    # 9) SENSITIVITY — does any conclusion flip under bolt_sp / ma_slope / faith corners?
    # ------------------------------------------------------------------
    hr()
    print("9) SENSITIVITY (mid, G_m=0.53) — the two load-bearing reads under open knobs.")
    print("   bolt-floor ratio (dead-weight guard) and plate(wrong) ratio (good-vs-plate), varying bolt_sp,")
    print("   base(MA) slope, and Faith (caster Faith multiplies ALL magic incl. the bolt & nuke).")
    print(f"   {'bolt_sp':>7} {'ma_slope':>8} {'faith':>6} | {'bolt flr':>8} | {'plate(wr) mid':>13} {'plate(wr) late-lin':>18}")
    for bsp in (0.6, 0.8, 1.0):
        for msl in (0.8, 1.0, 1.2):
            for fc_name, fc in (("mid",S.F_NEU), ("low",S.faith_mult(25)), ("high",S.faith_mult(85))):
                bf = S.bolt_onhit(STAGES["mid"], 0.53, bsp, ma_slope=msl, fc=fc)/f_leu
                # plate(wrong): mage per-turn scales with ma_slope & faith (bolt_sp only moves the bolt part
                # of the per-battle dpt). recompute mage dpt mid & late with these knobs:
                def mdpt(stage):
                    ma=STAGES[stage]
                    tot,_,_ ,_ = A.mage_group(ma,0.53,T_BATTLE,1, bolt_sp=bsp)  # ma_slope/faith folded below
                    return tot/T_BATTLE
                # mage_group doesn't take ma_slope/faith; approximate their effect analytically (linear scalars
                # on every magic term) by scaling the neutral dpt by (msl)*(fc): both multiply base(MA) & faith_c.
                scale = msl * fc
                pw_mid_s  = (mage_dpt(0.53,"mid")*scale)/pw_mid
                pw_late_s = (mage_dpt(0.53,"late")*scale)/plate_ftr_dpt("late","wrong","linear")
                print(f"   {bsp:7.2f} {msl:8.2f} {fc_name:>6} | {bf:8.2f} | {pw_mid_s:13.2f} {pw_late_s:18.2f}")
    print("   READ: dead-weight & good-vs-plate(mid) hold across all corners EXCEPT bolt_sp<=0.6 + low Faith")
    print("   (the bolt floor dips). plate(wrong) at LATE under LINEAR scaling stays <1 at neutral knobs unless")
    print("   ma_slope or Faith is high -> the late-linear plate breach is the genuinely sensitive cell.")
    hr()
    print("Ground truth above; interpretation in sim_optionA_single_target_READ.md.")

# Option A — single-target & plate guard-rail (READ)

Interpretation of `sim_optionA_single_target.py`. **The script's printed output is ground truth;**
this prose only reads it. Run: `python3 sim_optionA_single_target.py`.

## What was tested (and what was NOT re-litigated)

The caster-supremacy fix is **Option A: a pure global `G_m` reduction, no per-target MP cost
(`λ=0`)** — decided, not re-opened. The mage's signature spells are AoE with realistic cluster
`E[k]≈1.3`, so `G_m` is re-anchored **down** from the single-target value `0.652` (decision 11.49)
toward the `E[k]=1.3` parity (`~0.53`). The cluster (k≥2) is a deliberately **unbraked reward** — no
AoE cost is applied anywhere in this sim.

The only question here is the designer's guard-rail: **lowering `G_m` lowers single-target output too —
does Option A make the mage useless vs one target, and does it still do GOOD DAMAGE VS PLATE?**
(`"no máximo o mago tem que dar um bom dano em plates"` — good-vs-plate is the non-negotiable floor.)

All machinery is reused unchanged: `sim_core` (physical baseline), `sim_confront_supremacy` (bolt /
Fira / Firaga burst economy, `GM_STAR`), `sim_confront_aoe.mage_group` (with `pt_mp=0` ⇒ `λ=0`).
Core measurement: **single target (k=1), `λ=0`**, swept `G_m ∈ {0.48, 0.50, 0.53, 0.55, 0.58, 0.60,
0.65}`, across early/mid/late, vs leather / robe / plate / monk / thief.

**One model fact drives everything:** magic is DR-blind and (vs uninvested foes) auto-lands, so the
mage's per-turn / per-battle damage is **identical across all archetypes**. The archetype only moves
the **fighter's** number (DR, dodge, right-vs-wrong tool) and the target **HP** (for TTK). So
"vs soft" vs "vs plate" is entirely a statement about what the *fighter* does to that target.

## Thresholds (stated, then tested)

- **Dead weight** = bolt floor (MP-0, DR-ignoring) `< 0.50` of a fighter's per-turn damage.
- **Useless single-target** = per-battle single-target total `< 0.55` of a fighter's per-battle total.
  (Heroic-floor pick: a mage may be a *weak* duelist but must be a real contributor; 0.55 is the low
  end of the task's 0.55–0.60 band — I use the lenient end because the mage's job is bursts/AoE/anti-
  armor, not soft-single-target dueling.)
- **Good vs plate** = mage per-turn/per-battle vs plate `≥` a **wrong-tool (cut)** fighter's, AND
  within reach of the **right-tool (crush)** specialist's.

---

## (1) The pick-by-eye table (MID stage; all ratios are mage / fighter)

| `G_m` | bolt-floor | nuke spike /swing | per-batt ST /soft | vs-plate (wrong-tool) | vs-plate (right-tool) | k=2 cluster /fighter |
|------:|:----------:|:-----------------:|:-----------------:|:---------------------:|:---------------------:|:--------------------:|
| 0.48  | **0.48** ✗ | 1.81 | 0.74 | 1.25 | 0.79 | 1.28 |
| 0.50  | 0.50 | 1.88 | 0.77 | 1.30 | 0.83 | 1.33 |
| **0.53** | **0.53** | 2.00 | 0.81 | **1.38** | 0.88 | 1.41 |
| 0.55  | 0.55 | 2.07 | 0.84 | 1.43 | 0.91 | 1.46 |
| 0.58  | 0.58 | 2.19 | 0.89 | 1.51 | 0.96 | 1.54 |
| 0.60  | 0.60 | 2.26 | 0.92 | 1.56 | 0.99 | 1.60 |
| 0.65  | 0.65 | 2.45 | 1.00 | 1.69 | 1.08 | 1.73 |

- **bolt-floor** = bolt / leather-fighter per-turn (`✗` = `<0.50`). At MID it ≈ `G_m` (the leather
  fighter ≈ the mage's own scale here). Only `0.48` trips dead-weight at mid.
- **per-batt ST /soft** is the headline "is the mage useful 1v1" number. At `0.53` the mage does
  **81% of a fighter's per-battle damage vs a soft target** — a weak-but-real duelist, never useless.
- **vs-plate (wrong-tool) = 1.38 at 0.53**: the mage out-damages a cut fighter bouncing off plate by
  38%. **vs-plate (right-tool) = 0.88**: ~88% of the crush specialist — competitive, not dominant.
- **k=2 cluster** is the accepted unbraked reward (mage AoE on 2 vs a fighter clearing 1). The cluster
  **multiple** (mage k=2 / mage k=1) is `G_m`-independent: **k2 = 1.74×, k3 = 2.48×** the mage's own
  single-target output, at every `G_m`.

The **full nuke** is never the weak link: the Firaga spike is **2.00× a fighter swing at `G_m=0.53`**
(mid), and even amortized over its 2-turn charge it is ≥ a fighter's turn down to ~`0.53`.

---

## (2) The lower floor on `G_m`, and where 0.53 sits

The single-target *per-battle total* is **not** the binding constraint — it stays `0.64–1.00` of a
fighter vs soft across the whole sweep, and `≥1.0` vs the evasive thief at every `G_m` (the auto-
landing mage punishes evasion). The "useless single-target" line is only crossed at `G_m ≈ 0.41`
(binding archetype = robe), far below the sweep.

The two constraints that actually bind are **(b) the depleted bolt floor** and **(c) the plate edge** —
and **both bind at the LATE stage**, for the same structural reason: the fixed armor DR and the fixed
MP economy don't scale, so a late-game *fighter* (higher PA, skill 15, +50% p_land, ×1.5 cut wound)
out-scales the *linear* late-game bolt/mage. Both are therefore **sensitive to the physical-scaling
model**:

| binding floor (LATE stage) | realistic (GURPS-concave) | optimistic (sim_core linear) |
|---|:---:|:---:|
| (a) useless single-target | 0.41 (never binds) | 0.41 |
| (b) dead-weight bolt floor | **0.518** | **0.575** |
| (c) good-vs-plate (≥ wrong-tool) | 0.486 | 0.574 |
| **OVERALL binding floor** | **≈ 0.52** | **≈ 0.575** |

**Where 0.53 sits:** it **clears the realistic floor (0.518) by a hair (+0.012)** and **misses the
strict linear-late floor (0.575) by −0.045**. It is **never** "useless single-target" anywhere.

Concretely, at **`G_m=0.53` the only cell that fails** in the entire sweep is the LATE stage under
LINEAR scaling: depleted bolt vs leather = `0.46` (`<0.50`), and mage-vs-plate = `0.92×` the wrong-
tool cut fighter (`<1.0`). Under the more-realistic **concave** model the same late cells read `≥0.50`
and **`1.09×`** — i.e. the late breach is largely a **linear-scaling artifact**, not a robust break.
Two further modeling choices *inflate* that late floor against the mage and are conservative:
**linear physical scaling** (real GURPS swing is concave) and a **fixed MP pool across stages** (a real
endgame mage has a larger pool and floors to the bare bolt less often).

At **early and mid** stages `0.53` is comfortable everywhere: vs-plate wrong-tool = **3.35× (early)**
and **1.38× (mid)**; vs-plate right-tool = **1.05× (early)** and **0.88× (mid)**. The mage's anti-
armor identity is strongest exactly where it should be — vs heavy armor, a cut fighter barely scratches
plate (early plate cut ≈ 1.5 dmg/turn) while the DR-ignoring mage lands full.

---

## (3) Recommended `G_m` range for Option A

**Recommended band: `G_m ∈ [0.55, 0.60]`, safe pick ≈ 0.58.**

- **0.58** clears **both** scaling models at **all** stages (≥ the 0.575 strict floor): dead-weight and
  good-vs-plate hold even under the pessimistic linear-late assumption. This is the no-asterisks choice.
- **0.55** clears the realistic floor with margin and is marginal-but-defensible under linear-late
  (bolt 0.48, plate 0.96 at late-linear — within rounding of the line).
- **0.53** (the designer's `E[k]=1.3` anchor) is the **aggressive minimum**: fine early/mid and under
  realistic concave scaling, never useless single-target, still good-vs-plate at early/mid — but it
  goes **marginal late-game under the optimistic-linear model** (depleted bolt and plate-edge dip just
  under their floors). It is the leanest single-target mage that still satisfies the guard-rail, at the
  cost of the smallest late-game safety margin.

**Cluster reward at the recommended `G_m`** (the accepted unbraked upside, `λ=0`): the AoE **multiple is
`G_m`-independent — k=2 → 1.74×, k=3 → 2.48×** the mage's own single-target output. Measured against a
*fighter* clearing the cluster (mid, vs leather): k=2 → `1.41× (0.53)` / `1.46× (0.55)` / `1.54×
(0.58)`; k=3 → `2.01× / 2.09× / 2.20×`. So even at the safe `0.58` the mage is a slightly-sub-par
single-target duelist (k=1 ≈ `0.89×` a fighter) that pays off hard on clusters — the intended shape.

**Trade-off in one line:** lower `G_m` = more cluster restraint + leaner single-target + thinner late
margin; higher `G_m` = stronger single-target/anti-armor edge + safer late + a hotter (but still
unbraked) cluster. `0.53→0.58` moves the single-target-vs-soft from `0.81×→0.89×` and plate-wrong from
`1.38×→1.51×`, while the cluster multiple is unchanged.

---

## (4) Sensitivity & named skipped axes

**Sensitivity (mid, `G_m=0.53`, §9 of the output):** the dead-weight bolt floor and good-vs-plate(mid)
hold across the full `bolt_sp × ma_slope × Faith` grid **except** `bolt_sp ≤ 0.6` **combined with low
Faith** (bolt floor dips to 0.22–0.32) — but low caster Faith is a self-inflicted stat choice, not a
balance property, and `bolt_sp` is a design knob the designer sets. The genuinely sensitive cell is
**plate-wrong at LATE under LINEAR scaling**, which stays `<1` at neutral knobs unless `ma_slope` or
Faith is high — i.e. the late-linear plate breach is real but model-fragile, exactly as §6/§8 show.

**Honest bottom line on 0.53:** *not* useless single-target (the per-battle floor and the nuke spike
are comfortable), and good-vs-plate at the stages that matter most (early/mid). It is **on the edge,
not in the clear**: it just clears the realistic binding floor (~0.52) and sits just under the strict
linear floor (~0.575). If the designer wants zero asterisks on the late-game anti-armor identity, nudge
to **0.58**; if the `E[k]=1.3` parity is the priority and the (conservative) late-game corners are
acceptable, **0.53 is the viable minimum**.

**Skipped axes (named, with bias sign on *this* guard-rail):**
- **AoE cost / per-target MP** — none, by design (`λ=0`). Adding any would only lower *cluster* output,
  never single-target ⇒ irrelevant here.
- **Variable MP pool by stage** — fixed (`pool 80`) across early/mid/late. A real endgame mage has a
  larger pool ⇒ floors to the bare bolt less often ⇒ the late dead-weight floor is **overstated**
  (conservative against the mage).
- **Physical scaling** — both linear (sim_core default) and GURPS-concave shown; concave is the more
  realistic late-game and relaxes both binding floors. The headline linear numbers are the
  pessimistic-for-the-mage bound.
- **magic-evade slot** — 0 for all targets (uninvested). A bought slot only *hurts* the mage ⇒ the
  evade-0 headline is the generous read; covered already in the supremacy/aoe sims.
- **Zodiac off-neutral, Faith off-mid** — headline at neutral/mid; corners in §9. A resisted element
  hurts the mage on a *specific* foe, not the general floor.
- **Healing / status / CC / reactions / interrupts** — out of scope (separate breaks). Counter punishes
  the meleeing fighter, never the ranged bolt ⇒ omitting it is conservative for the mage's standing.
- **Live FFT AI / ENTD map geometry / actual `E[k]`** — Windows-only; `E[k]≈1.3` is the designer's
  assumption, taken as given. This sim answers only the single-target/plate guard-rail, not whether the
  AI clusters.
- **Multi-mage stacking** — per-mage analysis only; an all-caster party scales like N fighters and is a
  separate encounter axis.

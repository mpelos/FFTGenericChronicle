#!/usr/bin/env python3
"""
sim_skill_scaling.py — find skill(grade, jobLevel, charLevel) for the DCL (A5 / doc 10).

Design intent (Marcelo, 2026-06-26):
  - weapon skill scales with BOTH Job Level (1..8) and character level (1..99);
  - Job Level is the MORE impactful lever ("playing the job" = mastery), char level secondary;
  - a LOW-weapon-skill unit (low job GRADE) stays BAD even at character level 99 — leveling must
    NOT rescue the wrong tool;
  - skill feeds the doc-10 cap: <=16 governs the 3d6 hit roll; the EXCESS over 16 converts to
    damage/penetration (this is what makes the skill-primary Crossbow/Gun scale to 99 without going
    obsolete — A5).

Built to FALSIFY a candidate formula against explicit targets, then sweep params for robustness.

Formula shape under test (grade-weighted, char-level gated by job level so dabblers get nothing):
    skill = grade_base[g] + grade_rate[g] * ( J*(jobLevel-1) + K*(jobLevel/8)*(charLevel-1) )
  - grade_base: doc-10 base skills (A13 B11 C9 D7 F5).
  - grade_rate: how fast this grade converts investment into skill (low grade barely improves).
  - J: job-level coefficient (the big lever).
  - K: char-level coefficient, GATED by (jobLevel/8) so a job-level-1 dabbler at clvl99 stays unskilled.
"""
CAP = 16  # doc 04/10: hit uses min(skill,CAP); excess -> damage/penetration

GRADE_BASE = {"A": 13, "B": 11, "C": 9, "D": 7, "F": 5}

def skill(g, jl, cl, J, K, grade_rate):
    invest = J * (jl - 1) + K * (jl / 8.0) * (cl - 1)
    return GRADE_BASE[g] + grade_rate[g] * invest

def overcap(s):
    return max(0.0, s - CAP)   # the part that becomes damage/penetration

# ---- design targets (explicit, checked numerically) ----
def targets(J, K, grade_rate):
    s = lambda g, jl, cl: skill(g, jl, cl, J, K, grade_rate)
    checks = {}
    # T1  Job Level dominates char level: a maxed-job low-level specialist beats a
    #     job-level-1 character-level-99 dabbler, same grade.
    checks["T1 job8/clvl10 > job1/clvl99 (A)"] = (s("A",8,10) > s("A",1,99), s("A",8,10), s("A",1,99))
    checks["T1 (C)"]                            = (s("C",8,10) > s("C",1,99), s("C",8,10), s("C",1,99))
    # T2  Low GRADE stays bad even fully invested at clvl99: a maxed grade-F at 99 is still
    #     ~at the cap (≈no over-cap damage) and far below a maxed grade-A.
    checks["T2 F job8/clvl99 <= 18 (≈cap)"]     = (s("F",8,99) <= 18, s("F",8,99), None)
    checks["T2 A/F gap >= 3x (job8/clvl99)"]    = (s("A",8,99) >= 3*s("F",8,99), s("A",8,99), s("F",8,99))
    # T3  Mastery scales to 99: a maxed grade-A at 99 has big over-cap, and clvl matters for masters.
    checks["T3 A job8/clvl99 over-cap >= 18"]   = (overcap(s("A",8,99)) >= 18, overcap(s("A",8,99)), None)
    checks["T3 clvl matters: A8/99 > A8/20"]    = (s("A",8,99) > s("A",8,20) + 8, s("A",8,99), s("A",8,20))
    # T4  Early/mid game lives in the 9–16 hit band for on-grade units.
    checks["T4 A job1/clvl8 in [9,16]"]         = (9 <= s("A",1,8) <= 16, s("A",1,8), None)
    checks["T4 C job4/clvl15 in [9,17]"]        = (9 <= s("C",4,15) <= 17, s("C",4,15), None)
    # T5  Off-grade stays clumsy even at clvl99 (wrong-tool penalty survives leveling).
    checks["T5 F job1/clvl99 < 9 (clumsy)"]     = (s("F",1,99) < 9, s("F",1,99), None)
    checks["T5 D job2/clvl99 < 13"]             = (s("D",2,99) < 13, s("D",2,99), None)
    return checks

def score(J, K, grade_rate):
    chk = targets(J, K, grade_rate)
    passed = sum(1 for ok, *_ in chk.values() if ok)
    return passed, len(chk), chk

def dump_table(J, K, grade_rate, label):
    print(f"\n{'='*78}\n{label}:  J={J}  K={K}  grade_rate={grade_rate}\n{'='*78}")
    print(f"  skill(grade, jobLevel, charLevel)   [hit uses min(skill,{CAP}); excess→dmg/pen]")
    cols = [(1,5),(1,50),(1,99),(4,30),(8,10),(8,50),(8,99)]
    hdr = "  grade | " + " | ".join(f"jl{jl}/cl{cl}" for jl,cl in cols)
    print(hdr); print("  " + "-"*(len(hdr)-2))
    for g in ("A","B","C","D","F"):
        row = [f"{skill(g,jl,cl,J,K,grade_rate):5.1f}" for jl,cl in cols]
        oc99 = overcap(skill(g,8,99,J,K,grade_rate))
        print(f"   {g}    | " + " | ".join(row) + f"   (A8/99 over-cap={oc99:.0f})")

if __name__ == "__main__":
    RATE_PROFILES = {
        "steep":  {"A":1.00,"B":0.72,"C":0.50,"D":0.32,"F":0.20},
        "medium": {"A":1.00,"B":0.78,"C":0.58,"D":0.40,"F":0.26},
        "gentle": {"A":1.00,"B":0.85,"C":0.70,"D":0.55,"F":0.42},
    }
    print("SKILL-SCALING formula search — pass design targets, then keep the most robust params")

    # ---- sweep ----
    best = None
    results = []
    for prof_name, gr in RATE_PROFILES.items():
        for J in (1.5, 2.0, 2.5, 3.0):
            for K in (0.2, 0.25, 0.3, 0.4):
                passed, total, chk = score(J, K, gr)
                # robustness = min margin across the boolean targets (how comfortably they pass)
                margins = []
                for ok, a, b in chk.values():
                    if b is not None:
                        margins.append((a-b) if ok else -abs(a-b))
                results.append((passed, prof_name, J, K))
                if passed == total:
                    if best is None or (passed, ) > (best[0],):
                        best = (passed, prof_name, J, K, gr)
    # report all-pass combos
    allpass = sorted([r for r in results if r[0]==max(r0[0] for r0 in results)], reverse=True)
    maxp = max(r[0] for r in results)
    print(f"\nbest target-pass count = {maxp}/{len(targets(2.0,0.3,RATE_PROFILES['medium']))}")
    print("combos hitting that max:")
    seen=set()
    for p, prof, J, K in sorted(results, reverse=True):
        if p==maxp and (prof,J,K) not in seen:
            seen.add((prof,J,K)); print(f"   {prof:6}  J={J}  K={K}")

    # detailed read on a chosen central candidate
    for prof, J, K in [("medium",2.0,0.3),("steep",2.5,0.3),("medium",2.5,0.3)]:
        gr = RATE_PROFILES[prof]
        dump_table(J,K,gr, f"CANDIDATE {prof} J={J} K={K}")
        passed,total,chk = score(J,K,gr)
        print(f"\n  TARGETS {passed}/{total}:")
        for name,(ok,a,b) in chk.items():
            bs = f" vs {b:.1f}" if b is not None else ""
            print(f"    [{'PASS' if ok else 'FAIL'}] {name:38} = {a:.1f}{bs}")

    # ===================== FINAL LOCK =====================
    # Chosen for the cleanest legible statement of "Job Level dominates":
    #   J=2.5, K=0.25  ->  one job level is worth exactly J/K = 10 character levels
    #   of weapon skill for an on-grade unit. 'steep' rate profile so low grades barely move.
    PROF, J, K = "steep", 2.5, 0.25
    gr = RATE_PROFILES[PROF]
    dump_table(J, K, gr, f"*** FINAL LOCK *** {PROF} J={J} K={K}")
    passed, total, chk = score(J, K, gr)
    print(f"\n  TARGETS {passed}/{total}:")
    for name,(ok,a,b) in chk.items():
        bs = f" vs {b:.1f}" if b is not None else ""
        print(f"    [{'PASS' if ok else 'FAIL'}] {name:38} = {a:.1f}{bs}")

    # --- legibility: 1 job level = how many character levels, per grade ---
    print(f"\n  EQUIVALENCE — skill gained per +1 job level vs per +1 char level (at job 8):")
    print(f"    grade | +1 jobLvl | +1 charLvl(@jl8) | 1 jobLvl = N charLvls")
    print(f"    " + "-"*60)
    for g in ("A","B","C","D","F"):
        per_job  = J * gr[g]                 # d(skill)/d(jobLevel)
        per_char = K * (8/8.0) * gr[g]       # d(skill)/d(charLevel) at job 8
        ratio = per_job / per_char           # = J/K, grade-independent (both carry grade_rate)
        print(f"      {g}   |   {per_job:5.2f}   |      {per_char:5.2f}       |      {ratio:4.1f}")
    print(f"    -> ratio is J/K = {J/K:.0f} for EVERY grade: one job level always buys"
          f" {J/K:.0f} char levels of skill.")
    print(f"    -> AND char scaling is gated by (jobLevel/8): a job-1 dabbler gets ~1/8 the")
    print(f"       per-char skill of a job-8 master, so leveling can't rescue an undeveloped job.")

    # --- A5 obsolescence proof: crossbow/gun damage INPUT = skill, so it must keep climbing ---
    # (base(skill) is the calibration table; relative skill growth == relative damage-input growth)
    print(f"\n  A5 CROSSBOW/GUN OBSOLESCENCE CHECK (damage input = skill, not PA):")
    print(f"    a marksman (grade A) vs a wrong-job holder (grade F), early -> level 99:")
    for g in ("A","F"):
        early = skill(g, 1, 8,  J, K, gr)    # fresh recruit, main weapon
        maxed = skill(g, 8, 99, J, K, gr)    # job-mastered, level 99
        print(f"      grade {g}: skill {early:4.1f}  ->  {maxed:4.1f}   "
              f"(x{maxed/early:.2f} growth in damage input; over-cap {overcap(maxed):.0f})")
    a99 = skill("A",8,99,J,K,gr); f99 = skill("F",8,99,J,K,gr)
    print(f"    -> grade-A input climbs to {a99:.0f} (never obsolete); grade-F stalls at {f99:.0f}")
    print(f"       (< cap {CAP}: a non-marksman's crossbow stays weak even maxed at 99 — wrong tool).")

    # --- robustness: the chosen profile is not a knife-edge ---
    steep_pass = sum(1 for p,prof,jj,kk in results if prof=="steep" and p==total)
    steep_total = sum(1 for prof in [PROF] for jj in (1.5,2.0,2.5,3.0) for kk in (0.2,0.25,0.3,0.4))
    print(f"\n  ROBUSTNESS: {steep_pass}/{steep_total} of the swept 'steep' J/K combos pass all"
          f" {total} targets — the pick sits inside a wide passing plateau, not a knife-edge.")

# sim_skill_scaling — read

**Question (validation A5 / doc 10).** Find `skill(grade, jobLevel, charLevel)` so that weapon skill
scales with BOTH Job Level (1–8) and character level (1–99), where **Job Level is the more impactful
lever** and **a low-grade unit stays bad even at character level 99** (leveling must not rescue the
wrong tool). Skill feeds the doc-04/10 cap: `min(skill,16)` governs the 3d6 hit roll, the **excess over
16 converts to damage/penetration** — which is also what lets the skill-primary Crossbow & Gun (A5)
scale to 99 without going obsolete in a no-new-equipment mod.

## Formula (locked)

```
skill(g, jobLevel, charLevel)
  = grade_base[g] + grade_rate[g] * ( J*(jobLevel-1) + K*(jobLevel/8)*(charLevel-1) )

  grade_base = { A:13, B:11, C:9, D:7, F:5 }      # doc 10 base skills
  grade_rate = { A:1.00, B:0.72, C:0.50, D:0.32, F:0.20 }   # "steep" profile
  J = 2.5     # job-level coefficient (the big lever)
  K = 0.25    # char-level coefficient, GATED by (jobLevel/8)
  cap = 16    # hit uses min(skill,16); excess -> damage / penetration
```

## Why these values

- **`J/K = 10` → one job level is worth exactly ten character levels of skill, for every grade.** The
  `grade_rate[g]` factors out of the ratio, so the "one job level = 10 char levels" statement is true
  for A through F alike. This is the legible (P5) expression of "Job Level dominates."
- **Char scaling is gated by `(jobLevel/8)`.** A job-1 dabbler gets ⅛ the per-character-level skill of
  a job-8 master, so grinding character levels cannot rescue an undeveloped job — only *playing the
  job* unlocks the long-tail scaling.
- **'steep' rate profile** (low grades barely convert investment into skill) is what keeps a low-grade
  unit bad at 99: a maxed grade-F at level 99 reaches only skill **13.4 — below the 16 cap**, so it
  never even clears the hit band, let alone earns over-cap power. The A↔F gap is **>4×**.

## Result — passes all 10 design targets (`steep J=2.5 K=0.25`)

| grade | jl1/cl5 | jl1/cl99 | jl4/cl30 | jl8/cl10 | jl8/cl99 | over-cap @jl8/cl99 |
|-------|---------|----------|----------|----------|----------|--------------------|
| A | 13.1 | 16.1 | 24.1 | 32.8 | **55.0** | 39 |
| B | 11.1 | 13.2 | 19.0 | 25.2 | 41.2 | 25 |
| C |  9.1 | 10.5 | 14.6 | 18.9 | 30.0 | 14 |
| D |  7.0 |  8.0 | 10.6 | 13.3 | 20.4 |  4 |
| F |  5.0 |  5.6 |  7.2 |  8.9 | **13.4** | 0 |

- **T1 Job dominates:** grade-A job8/clvl10 (**32.8**) ≫ grade-A job1/clvl99 (**16.1**). A maxed-job
  rookie crushes a never-developed veteran.
- **T2 Low grade stays bad:** grade-F job8/clvl99 = **13.4** (< cap, ~0 over-cap); A/F gap 55.0 vs 13.4
  (>4×).
- **T3 Mastery scales to 99:** grade-A job8/clvl99 over-cap = **39** (≥18); clvl matters (55.0 vs 35.2 at
  clvl20).
- **T4 Early game in 9–16 band:** grade-A job1/clvl8 = **13.2**; grade-C job4/clvl15 = **13.6**.
- **T5 Off-grade clumsy even at 99:** grade-F job1/clvl99 = **5.6**; grade-D job2/clvl99 = **9.8**.

## A5 obsolescence check (Crossbow & Gun damage input = skill)

A marksman (grade A) vs a wrong-job holder (grade F), early → level 99:

- grade A: skill **13.2 → 55.0** (×4.16 growth in damage input; over-cap 39) — **never obsolete**.
- grade F: skill **5.0 → 13.4** (×2.66; over-cap 0) — **stays weak even maxed** (< cap 16).

Because Crossbow/Gun take their damage *input* from skill (not PA), this rising skill is exactly what
keeps them relevant at level 99 without a flat number that would die under the no-new-equipment rule.

## Robustness (not a knife-edge)

All **16/16** swept `steep` (J∈{1.5,2,2.5,3} × K∈{0.2,0.25,0.3,0.4}) combos pass all 10 targets, and
the entire `medium` profile passes for most. The pick sits inside a wide passing plateau — `J=2.5,
K=0.25` is chosen for the clean 10:1 legibility, not because it's the only thing that works. The
`gentle` profile fails (low grades scale too well → T2/T5 break), which is the expected failure
direction.

## Deferred (still calibration)

`grade_base`/`grade_rate` magnitudes, `J`/`K`, and the `cap` interact with the still-open `base()`
strength→damage table, `G`, and the over-cap→damage/penetration conversion rate (doc 02, doc 12). The
*shape* is locked; the absolute numbers move together at fine-calibration time.

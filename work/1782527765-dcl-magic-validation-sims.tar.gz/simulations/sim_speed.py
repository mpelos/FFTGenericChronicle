#!/usr/bin/env python3
"""
sim_speed.py — Does Speed dominate? (P9 hard pillar; doubts DB8, critic#1,#2,#8)
v2: addresses the cross-model peer's F1 critique — the v1 composite BUNDLED Speed with Brave,
so it didn't prove SPEED dominates (could have been Brave). v2 isolates Speed: hold Brave (and
everything else) FIXED and vary ONLY Speed. If a Fast-neutral unit strictly beats a Slow-neutral
unit (more turns AND better Dodge, nothing lost), that is a clean P9 violation with no Brave
confound. Section C (depletion exposure) is also rebuilt to concentrate focus-fire into ONE
inter-turn gap (the v1 even-spread was degenerate).

Speed in the DCL does THREE positive things and (per the register) pays NO cost:
(1) CT/turn-frequency, (2) Dodge floor = C-Ev+Speed, (3) guard refresh on own turn.
Weight taxes Move+Dodge but explicitly NOT CT (D14-71/74).

FFT CT model: each tick, CT += Speed; act at CT>=100 then CT-=100. Turns over a window ∝ Speed.
"""
from sim_core import p_le

def turns_per_window(speed, ticks=600):
    """How many turns a unit gets over `ticks` CT-ticks (FFT-style)."""
    ct = 0; turns = 0
    for _ in range(ticks):
        ct += speed
        if ct >= 100:
            ct -= 100; turns += 1
    return turns

def dodge(speed, c_ev=2, brave_def=0):
    """Dodge floor = C-Ev + Speed-derived + Brave-defense shift (D04-11, D07-18)."""
    return c_ev + speed + brave_def     # brave_def: +3 (low Brave) .. -2 (high Brave)

# ---------------------------------------------------------------------------
print("="*72)
print("A) OFFENSE: turns over a 600-tick window (turn-frequency ∝ Speed)")
print("="*72)
for spd in (5,6,8,10,12,15):
    t = turns_per_window(spd)
    print(f"  Speed {spd:2d}: {t} turns   (vs Speed 6 = {t/turns_per_window(6):.2f}x the actions)")
print("  -> offense output scales ~linearly with Speed. A Speed-12 unit acts ~2x a Speed-6 unit.")

print("\n"+"="*72)
print("B) DEFENSE leg 1 — Dodge floor rises with Speed (no cost)")
print("="*72)
for spd in (5,8,12,15):
    d = dodge(spd)
    print(f"  Speed {spd:2d}: Dodge≈{d}  -> attacker(skill12) lands past Dodge: {(1-p_le(d))*100:4.0f}% non-crit")
print("  -> faster unit is also harder to hit, before any defensive investment.")

print("\n"+"="*72)
print("C) DEFENSE leg 2 — guard refresh vs CONCENTRATED focus-fire (rebuilt)")
print("="*72)
print("  A turtle has G depleting guards (Parry+Block) + a non-depleting Dodge floor. Attackers")
print("  CONCENTRATE strikes between the turtle's turns; guards refresh on the turtle's own turn.")
print("  Turtle acts every ~100/Speed ticks; in that gap the attacker TEAM lands")
print("  (ΣATK_speed / turtle_Speed) strikes. The first G deplete strong guards; the rest hit the")
print("  broken (Dodge-only) state. Faster turtle = shorter gap = fewer break through.\n")
ATK_TOTAL_SPEED = 30      # e.g. 3 attackers @ Speed 10 — fixed offensive pressure
GUARDS = 2
print(f"  attacker team ΣSpeed={ATK_TOTAL_SPEED}, turtle guards G={GUARDS}")
for spd in (5,6,8,10,12,15):
    strikes_per_gap = ATK_TOTAL_SPEED / spd
    broken_per_gap = max(0.0, strikes_per_gap - GUARDS)
    pct = broken_per_gap/strikes_per_gap*100 if strikes_per_gap>0 else 0
    tag = "CRACKED" if broken_per_gap>=1 else ("safe" if broken_per_gap==0 else "grazed")
    print(f"  Turtle Speed {spd:2d}: {strikes_per_gap:.1f} strikes/gap, {broken_per_gap:.1f} hit broken guard "
          f"({pct:.0f}% of the volley) -> {tag}")
print("  -> the depletion counter (D05-8) is Speed-gated: a slow turtle is cracked open, a fast one")
print("     is barely exposed. And the tankiest unit (plate) keeps FULL Speed (Weight≠CT) -> a fast")
print("     plate turtle is both hard-to-deplete AND hard-to-hit. The counter targets only SLOW tanks.")

print("\n"+"="*72)
print("D) Brave downside absorbed by Speed surplus (critic #8, P4 risk)")
print("="*72)
print("  high-Brave = 1.56x offense, -2 active defense (D07-17/18). Does Speed pay that -2?")
neutral_slow = dodge(6, brave_def=0)
for spd in (6,10,12,15):
    fast_highbrave = dodge(spd, brave_def=-2)
    print(f"  Speed {spd:2d} + HIGH Brave: Dodge={fast_highbrave}  vs slow-neutral Dodge={neutral_slow}  "
          f"-> {'NET BETTER dodge AND 1.56x dmg' if fast_highbrave>=neutral_slow else 'pays the trade'}")
print("  -> if a fast unit's Dodge after -2 still >= a slow neutral unit's, high Brave is free for it (P4 break).")

print("\n"+"="*72)
print("E) Composite — Speed ISOLATED (peer F1 fix): vary ONLY Speed, Brave held FIXED")
print("="*72)
print("  The clean P9 test: same Brave, same gear, ONLY Speed differs. If Fast strictly beats Slow")
print("  on BOTH offense and defense with nothing given up, Speed dominates with no Brave confound.\n")
print(f"  {'build (Brave fixed)':26} {'turns':>6} {'Dodge':>6} {'exposure%':>10} {'rel.offense':>12}")
def exposure(spd):
    s = ATK_TOTAL_SPEED/spd
    return max(0.0, s-GUARDS)/s*100 if s>0 else 0
rows = [
    ("Slow  (Spd6,  Brave mid)", 6, 0, 1.0),
    ("Fast  (Spd12, Brave mid)", 12, 0, 1.0),    # <-- isolates Speed vs row 1 (same Brave)
    ("--- (Brave confound below) ---", None, None, None),
    ("Fast  (Spd12, Brave HIGH)", 12, -2, 1.56),
    ("Slow  (Spd6,  Brave HIGH)", 6, -2, 1.56),
]
for name,spd,bdef,off in rows:
    if spd is None:
        print(f"  {name}")
        continue
    t=turns_per_window(spd); d=dodge(spd,brave_def=bdef)
    print(f"  {name:26} {t:6d} {d:6d} {exposure(spd):9.0f}% {off*t/turns_per_window(6):11.2f}")
print("  rel.offense = offense-per-hit x turns, normalized to slow-neutral.")
print("\n  ISOLATED READ: Fast-neutral vs Slow-neutral — identical Brave/gear — has 2.0x turns, a")
print("  strictly higher Dodge, and lower depletion exposure, at ZERO cost (Weight spares CT). That is")
print("  a clean P9 violation: a stat package converts purely into more turns + better defense with no")
print("  hard tradeoff. The Brave rows only ADD to it; they are not the cause.")

# sim_speed.py — read (v2, 2026-06-26)

Tests P9 ("nothing dominates by converting to more turns without a hard tradeoff") against Speed's
three untaxed positive functions (CT, Dodge floor, guard-refresh). **v2 answers the cross-model peer's
F1 objection** (v1 bundled Speed with Brave) and rebuilds the degenerate depletion-exposure section.

## Findings (ground truth from script)
- **A) Offense ∝ Speed:** Spd12 = 72 turns vs Spd6 = 36 → **2.0× actions**. Linear.
- **B) Dodge floor rises with Speed, no cost:** Spd5→Dodge7 (84% hittable), Spd12→Dodge14 (9%),
  Spd15→Dodge17 (~0% on the floor alone). Fast = evasive for free.
- **C) (rebuilt) Depletion counter is Speed-gated:** concentrating an attacker team (ΣSpeed 30) into one
  inter-turn gap, a Spd5 turtle eats 6 strikes/gap (4 hit the broken guard → **CRACKED**), a Spd15 turtle
  eats 2/gap (**0 break through → safe**). And the tankiest unit (plate) keeps **full** Speed (Weight≠CT),
  so a *fast plate* turtle is both hard-to-deplete and hard-to-hit. Focus-fire only cracks SLOW tanks.
- **D) Brave −2 absorbed:** Spd10+ high-Brave Dodge (10/12/15) ≥ slow-neutral Dodge 8 → high Brave is
  free for fast units (P4 break).
- **E) (isolated — the clean P9 test) Fast-neutral vs Slow-neutral, SAME Brave/gear:** 72 vs 36 turns,
  Dodge **14 vs 8**, depletion exposure **20% vs 60%**, at **zero cost** (Weight spares CT). Speed alone —
  no Brave confound — converts purely into more turns + better defense + better depletion-resistance with
  no hard tradeoff. The high-Brave rows (3.12× composite) only ADD to it; they are not the cause.

## Verdict
**P9 (hard pillar) is VIOLATED as written, on isolated evidence.** The peer's methodological objection
("the 3.1× bundles Brave") is **answered**: row E now varies only Speed and Fast still strictly dominates
Slow. The peer itself ranked this finding #1 ("biggest systemic threat if no hard tradeoff exists").
Nothing in the register attaches a cost to Speed (Weight explicitly spares CT, D14-71/74). **B1 confirmed.**
Fix is a design change (give Speed a real cost / cap its defensive double-dip / decouple CT from the Dodge
floor) — the user's call (report §F).

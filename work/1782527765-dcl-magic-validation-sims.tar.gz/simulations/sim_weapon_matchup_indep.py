#!/usr/bin/env python3
"""
Independent adversarial weapon-balance simulation for a tactics-RPG combat layer.

GOAL: try to BREAK pillar P1' -- "Each weapon TYPE has >=2 common WINNING contexts
AND >=2 common LOSING contexts across early/mid/late game and the 4 armor classes;
no type is universally best, and none is pointless."

All numbers below are assigned by an INDEPENDENT balance engineer from neutral
game-design priors. The designer's rationale was deliberately NOT consulted.
The code is the ground truth. Default hypothesis: "a weapon type strictly
dominates" unless the simulation genuinely fails to show it.

Mechanism (faithful to spec):
    injury = max(pen_floor, max(0, (base(PA)+wmod) - DR_type/divisor)) * wound_mult
    pen_floor = pen_frac * (base + wmod)              # multiplied by wound_mult too
    wound_mult: cut/swing=1.5, thrust/impaling=2.0, crush=1.0, missile=1.0  (FIXED)
    base(PA): strength damage, WEAPON-INDEPENDENT (same for every weapon a unit holds)
    wmod: weapon's flat additive bonus (its "WP") -- the only place weapons differ
    crush convention: crush weapons carry 1.5x the wmod of an equal-tier non-crush
    missile: armor-divisor DIVIDES DR (bow 1.0, crossbow 1.5, gun 2.0), wound_mult 1.0

Hit/defense (3d6 roll-under): hit if 3d6<=skill; if hit, defender negates on
3d6<=best_defense. Crit (natural low roll) bypasses the defense roll (not DR).
Defenses: Dodge (floor, never depletes), Parry (melee only), Block (shield only).
fura-guarda trait: -4 to be parried, -2 to be blocked, does NOT touch Dodge.
"""

from itertools import product

# ----------------------------------------------------------------------------
# 3d6 probability machinery
# ----------------------------------------------------------------------------
def _pmf_3d6():
    c = {}
    for a, b, d in product(range(1, 7), repeat=3):
        c[a + b + d] = c.get(a + b + d, 0) + 1
    return {k: v / 216.0 for k, v in c.items()}

_PMF = _pmf_3d6()

def cdf(x):
    """P(3d6 <= x)."""
    return sum(p for s, p in _PMF.items() if s <= x)

def p_land(skill, defense, crit_thresh):
    """Effective probability an attack deals its damage.
    crit auto-lands (bypasses defense); non-crit hits must beat the defense roll."""
    p_crit = cdf(crit_thresh)
    p_hit = cdf(skill)
    p_hit_noncrit = max(0.0, p_hit - p_crit)
    return p_crit + p_hit_noncrit * (1.0 - cdf(defense))

# ----------------------------------------------------------------------------
# Damage
# ----------------------------------------------------------------------------
WOUND = {'cut': 1.5, 'thrust': 2.0, 'crush': 1.0, 'missile': 1.0}  # FIXED by spec

def injury(base, wmod, dr, wmult, pen_frac, divisor=1.0):
    raw = base + wmod
    eff_dr = dr / divisor
    post = max(0.0, raw - eff_dr)
    floor = pen_frac * raw
    return max(floor, post) * wmult

# ----------------------------------------------------------------------------
# NEUTRAL-PRIOR CONFIG (assigned independently)
# ----------------------------------------------------------------------------
# base(PA) per game stage. Spec: "PA-ish 10-16 for mid units".
STAGES = {'early': 10, 'mid': 13, 'late': 16}

# Representative attacker skill (3d6 roll-under). Spec says 12-13.
SKILL = 13
CRIT_THRESH = 5  # natural 3,4,5 -> crit (P=0.046)

# Weapon WP tiers (flat wmod, BEFORE the crush 1.5x convention).
TIER = {'low': 3, 'med': 5, 'high': 7, 'very-high': 9}

# Defender profiles per armor class. Each bundles a typical wearer's defenses.
# Spec: model plate-knight best-defense ~11, lighter ~8; Dodge is a floor.
DEFENDERS = {
    'plate':   {'dodge': 6, 'parry': 11, 'block': 10, 'shield': True},   # best 11
    'mail':    {'dodge': 7, 'parry': 9,  'block': 8,  'shield': True},   # best 9
    'leather': {'dodge': 8, 'parry': 7,  'block': 0,  'shield': False},  # best 8
    'robe':    {'dodge': 8, 'parry': 4,  'block': 0,  'shield': False},  # best 8
}

# Subtractive DR per (armor, damage type). Honors stated intent:
# plate resists cut HIGHEST, thrust PARTIALLY, crush LEAST; mail middling;
# leather/robe thin vs all.
DR_BASELINE = {
    'plate':   {'cut': 9, 'thrust': 6, 'crush': 3, 'missile': 7},
    'mail':    {'cut': 5, 'thrust': 4, 'crush': 3, 'missile': 4},
    'leather': {'cut': 3, 'thrust': 2, 'crush': 2, 'missile': 2},
    'robe':    {'cut': 1, 'thrust': 1, 'crush': 1, 'missile': 1},
}

# Weapons: (name, type, hands, reach, tier_wmod, is_crush, divisor, fura_guarda)
WEAPONS = [
    ('Sword/Katana', 'cut',     1, 1, TIER['med'],       False, 1.0, False),
    ('Greatsword',   'cut',     2, 1, TIER['very-high'], False, 1.0, False),
    ('Spear/Lance',  'thrust',  2, 2, TIER['high'],      False, 1.0, False),
    ('Rapier/Estoc', 'thrust',  1, 1, TIER['med'],       False, 1.0, False),
    ('Flail',        'crush',   1, 1, TIER['med'],       True,  1.0, True),
    ('Mace/Hammer',  'crush',   1, 1, TIER['high'],      True,  1.0, False),
    ('Bow',          'missile', 2, 4, TIER['med'],       False, 1.0, False),
    ('Crossbow',     'missile', 2, 3, TIER['high'],      False, 1.5, False),
    ('Gun',          'missile', 1, 3, TIER['high'],      False, 2.0, False),
    ('Fists',        'crush',   0, 1, TIER['low'],       True,  1.0, False),
]
TYPES = ['cut', 'thrust', 'crush', 'missile']

# Crude reach proxy for the optional "kiting/safety" secondary view only.
REACH_MULT = {0: 0.95, 1: 1.00, 2: 1.15, 3: 1.30, 4: 1.30}

def weapon_wmod(w, cut_premium=0.0):
    _, typ, _, _, tier, is_crush, _, _ = w
    base_w = tier + (cut_premium if typ == 'cut' else 0.0)
    if is_crush:
        base_w *= 1.5  # heavier head convention
    return base_w

def eff_damage(w, armor, base, skill, P):
    """Return (effective_damage, injury_per_hit, p_land, defense_used)."""
    name, typ, hands, reach, tier, is_crush, div, fura = w
    wmod = weapon_wmod(w, P['cut_premium'])
    dr = P['DR'][armor][typ]
    inj = injury(base, wmod, dr, WOUND[typ], P['pen'], divisor=div)
    dfn = DEFENDERS[armor]
    is_missile = (typ == 'missile')
    dodge = dfn['dodge']
    parry = (dfn['parry'] - (4 if fura else 0)) if not is_missile else -999
    block = (dfn['block'] - (2 if fura else 0)) if dfn['shield'] else -999
    defense = max(dodge, parry, block)
    pl = p_land(skill, defense, P['crit'])
    e = inj * pl
    if P.get('use_reach'):
        e *= REACH_MULT[reach]
    return e, inj, pl, defense

# ----------------------------------------------------------------------------
# Aggregation
# ----------------------------------------------------------------------------
def type_matrix(P, skill=SKILL):
    """dict[(stage,armor)] -> dict[type] -> (best_eff, best_weapon_name)."""
    res = {}
    for stage, base in STAGES.items():
        for armor in DEFENDERS:
            byt = {}
            for typ in TYPES:
                best, bestname = -1.0, None
                for w in WEAPONS:
                    if w[1] != typ:
                        continue
                    e = eff_damage(w, armor, base, skill, P)[0]
                    if e > best:
                        best, bestname = e, w[0]
                byt[typ] = (best, bestname)
            res[(stage, armor)] = byt
    return res

def context_counts(tmat, win_frac=0.95, lose_frac=0.80):
    """Per type: lenient win/lose counts + strict (#1 / last) counts."""
    win = {t: 0 for t in TYPES}
    lose = {t: 0 for t in TYPES}
    swin = {t: 0 for t in TYPES}
    slose = {t: 0 for t in TYPES}
    for ctx, byt in tmat.items():
        vals = {t: byt[t][0] for t in TYPES}
        mx = max(vals.values())
        mn = min(vals.values())
        for t in TYPES:
            v = vals[t]
            if v >= win_frac * mx:
                win[t] += 1
            if v <= lose_frac * mx:
                lose[t] += 1
            if abs(v - mx) < 1e-9:
                swin[t] += 1
            if abs(v - mn) < 1e-9:
                slose[t] += 1
    return win, lose, swin, slose

def breakeven_gap(base, P, w_thr=TIER['med']):
    """wmod a CUT weapon needs over a thrust weapon (wmod=w_thr) to tie it,
    per armor class. Floor-free closed form: (b+wc-drc)*1.5 = (b+wt-drt)*2.0."""
    out = {}
    for armor in DEFENDERS:
        drc = P['DR'][armor]['cut']
        drt = P['DR'][armor]['thrust']
        rhs = (base + w_thr - drt) * 2.0 / 1.5
        wc = rhs - base + drc
        out[armor] = wc - w_thr
    return out

def min_cut_premium(P, skill=SKILL, need=2):
    """Smallest flat wmod premium on ALL cut weapons so cut becomes the
    strict #1 type in >=`need` contexts."""
    prem = 0.0
    while prem <= 25.0:
        Pp = dict(P)
        Pp['cut_premium'] = prem
        _, _, swin, _ = context_counts(type_matrix(Pp, skill))
        if swin['cut'] >= need:
            return prem
        prem += 0.5
    return None

# ----------------------------------------------------------------------------
# Reporting
# ----------------------------------------------------------------------------
def hr(c='-', n=78):
    print(c * n)

def print_weapon_table(P, stage='mid'):
    base = STAGES[stage]
    print(f"\nPER-WEAPON EFFECTIVE DAMAGE (injury * P_land)  |  stage={stage} base={base} "
          f"skill={SKILL} pen={P['pen']}")
    hr()
    header = f"{'weapon':<14}{'type':<8}{'wmod':>5}  " + "".join(f"{a:>10}" for a in DEFENDERS)
    print(header)
    hr()
    for w in WEAPONS:
        wmod = weapon_wmod(w, P['cut_premium'])
        row = f"{w[0]:<14}{w[1]:<8}{wmod:>5.1f}  "
        for armor in DEFENDERS:
            e = eff_damage(w, armor, base, SKILL, P)[0]
            row += f"{e:>10.1f}"
        print(row)
    print("  (injury-per-hit and P_land available in detail mode; eff = injury*P_land)")

def print_type_grid(P):
    tmat = type_matrix(P)
    print("\nTYPE-LEVEL EFFECTIVE DAMAGE per context (best weapon of each type). "
          "[W]=strict #1")
    hr()
    print(f"{'stage':<6}{'armor':<9}" + "".join(f"{t:>12}" for t in TYPES))
    hr()
    for stage in STAGES:
        for armor in DEFENDERS:
            byt = tmat[(stage, armor)]
            mx = max(byt[t][0] for t in TYPES)
            row = f"{stage:<6}{armor:<9}"
            for t in TYPES:
                v = byt[t][0]
                tag = 'W' if abs(v - mx) < 1e-9 else ' '
                row += f"{v:>10.1f}{tag:<2}"
            print(row)
    return tmat

def report_set(name, P, verbose=True):
    print("\n" + "=" * 78)
    print(f"PARAMETER SET: {name}")
    print(f"  pen_frac={P['pen']}  cut_premium={P['cut_premium']}  use_reach={P.get('use_reach',False)}")
    print(f"  plate DR cut/thrust/crush/missile = "
          f"{P['DR']['plate']['cut']}/{P['DR']['plate']['thrust']}/"
          f"{P['DR']['plate']['crush']}/{P['DR']['plate']['missile']}")
    print("=" * 78)
    if verbose:
        print_weapon_table(P)
        tmat = print_type_grid(P)
    else:
        tmat = type_matrix(P)
    win, lose, swin, slose = context_counts(tmat)
    print("\nPER-TYPE CONTEXT COUNTS  (12 contexts = 3 stages x 4 armor)")
    hr()
    print(f"{'type':<10}{'strict#1':>9}{'win>=95%':>10}{'lose<=80%':>11}{'P1prime':>16}")
    hr()
    verdicts = {}
    for t in TYPES:
        ok = (win[t] >= 2 and lose[t] >= 2)
        verdicts[t] = ok
        note = "OK" if ok else ("FAIL <2 win" if win[t] < 2 else "FAIL <2 lose")
        print(f"{t:<10}{swin[t]:>9}{win[t]:>10}{lose[t]:>11}{note:>16}")
    broken = [t for t in TYPES if not verdicts[t]]
    print(f"\n  P1' for this set: {'HOLDS' if not broken else 'BROKEN'}"
          f"{'' if not broken else '  -> offending types: ' + ', '.join(broken)}")
    return verdicts, (swin, win, lose)

# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    print("#" * 78)
    print("# INDEPENDENT WEAPON-BALANCE BREAK TEST  (P1' falsification attempt)")
    print("# Numbers assigned from neutral priors; designer rationale NOT consulted.")
    print("#" * 78)

    print("\nASSIGNED CONFIG")
    hr()
    print(f"  base(PA) by stage : {STAGES}")
    print(f"  wmod tiers        : {TIER}   (crush x1.5 convention applied on top)")
    print(f"  wound_mult (FIXED): {WOUND}")
    print(f"  skill={SKILL}  crit on 3d6<={CRIT_THRESH}  (P_crit={cdf(CRIT_THRESH):.3f})")
    print("  defender best-defense: " +
          ", ".join(f"{a}={max(DEFENDERS[a]['dodge'], DEFENDERS[a]['parry'], DEFENDERS[a]['block'] if DEFENDERS[a]['shield'] else 0)}"
                    for a in DEFENDERS))
    print("  weapon roster:")
    for w in WEAPONS:
        print(f"    {w[0]:<14} type={w[1]:<8} hands={w[2]} reach={w[3]} "
              f"tierWP={w[4]} crush={w[5]} divisor={w[6]} fura={w[7]} "
              f"-> wmod={weapon_wmod(w):.1f}")

    base_P = dict(pen=0.20, cut_premium=0.0, crit=CRIT_THRESH, DR=DR_BASELINE)

    # ---- Baseline detailed report ----
    report_set("S1 BASELINE (pen=0.20, neutral tiers, no cut premium)", base_P, verbose=True)

    # ---- Swing vs thrust break-even gap ----
    print("\n" + "=" * 78)
    print("SWING-vs-THRUST BREAK-EVEN GAP  (extra wmod a CUT weapon needs to TIE a")
    print("thrust weapon of equal tier wmod=5, per armor; floor-free closed form)")
    print("=" * 78)
    span = TIER['very-high'] - TIER['low']
    print(f"  tier ladder span (low {TIER['low']} -> very-high {TIER['very-high']}) = {span} wmod")
    print(f"  {'armor':<10}{'early':>10}{'mid':>10}{'late':>10}{'payable within ladder?':>26}")
    hr()
    for armor in DEFENDERS:
        gaps = {s: breakeven_gap(b, base_P)[armor] for s, b in STAGES.items()}
        worst = max(gaps.values())
        payable = "YES (barely)" if worst <= span else "NO -- cut cannot tie"
        print(f"  {armor:<10}{gaps['early']:>10.1f}{gaps['mid']:>10.1f}{gaps['late']:>10.1f}{payable:>26}")
    prem = min_cut_premium(base_P)
    print(f"\n  Empirical: flat cut-WP premium needed for CUT to become strict #1 in")
    print(f"  >=2 contexts = {prem if prem is not None else '>25 (never)'} wmod on every cut weapon.")

    # ---- Sensitivity sweep ----
    print("\n" + "#" * 78)
    print("# SENSITIVITY SWEEP")
    print("#" * 78)

    sets = []
    sets.append(("S2 low pen_floor (0.15)", dict(base_P, pen=0.15)))
    sets.append(("S3 high pen_floor (0.33)", dict(base_P, pen=0.33)))

    DR_compressed = {a: dict(v) for a, v in DR_BASELINE.items()}
    DR_compressed['plate'] = {'cut': 6, 'thrust': 5, 'crush': 2, 'missile': 6}
    sets.append(("S4 compressed plate DR (cut6/thr5/crush2)", dict(base_P, DR=DR_compressed)))

    sets.append(("S5 cut WP premium +4 (sword9/greatsword13)", dict(base_P, cut_premium=4.0)))
    sets.append(("S6 cut WP premium +7 (max compensation)", dict(base_P, cut_premium=7.0)))
    sets.append(("S7 baseline + crude reach/kiting credit", dict(base_P, use_reach=True)))

    summary = {}
    for name, P in sets:
        v, counts = report_set(name, P, verbose=False)
        summary[name] = (v, counts)

    # ---- Final verdict ----
    print("\n" + "#" * 78)
    print("# FINAL VERDICT")
    print("#" * 78)
    v1, c1 = report_set("S1 BASELINE (recap)", base_P, verbose=False)[0:2] if False else (None, None)
    # recompute baseline counts cleanly
    bwin, blose, bswin, bslose = context_counts(type_matrix(base_P))
    print("\nBaseline per-type (strict#1 / win / lose) out of 12 contexts:")
    for t in TYPES:
        ok = bwin[t] >= 2 and blose[t] >= 2
        print(f"  {t:<8}  #1={bswin[t]:>2}  win={bwin[t]:>2}  lose={blose[t]:>2}   "
              f"{'PASS' if ok else 'FAIL'}")
    print("\nStability across sweep (count of sets where each type PASSES >=2win & >=2lose,"
          f" out of {len(sets)} sweep sets + baseline):")
    allsets = [("baseline", (None, None))] + [(n, s) for n, s in summary.items()]
    for t in TYPES:
        passes = 0
        total = 0
        # baseline
        total += 1
        if bwin[t] >= 2 and blose[t] >= 2:
            passes += 1
        for n, (v, _) in summary.items():
            total += 1
            if v[t]:
                passes += 1
        print(f"  {t:<8} passes {passes}/{total} sets")

if __name__ == '__main__':
    main()

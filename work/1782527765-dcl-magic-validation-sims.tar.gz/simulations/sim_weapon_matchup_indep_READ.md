# Independent weapon-balance break test (P1')

`sim_weapon_matchup_indep.py` — built blind (designer rationale NOT read), numbers
assigned from neutral game-design priors. Run: `python3 sim_weapon_matchup_indep.py`.

## What it tests
P1': *"every weapon TYPE has >=2 winning AND >=2 losing contexts across early/mid/late
x {plate, mail, leather, robe}; no type universally best; none pointless."*

Metric = **effective damage = injury_per_hit x P(land)**, where
`injury = max(pen_floor, (base+wmod) - DR/divisor) * wound_mult`, base(PA) is
weapon-independent, wound_mult is FIXED (cut 1.5 / thrust 2.0 / crush 1.0 / missile 1.0).
Sweep over pen_floor (0.15/0.20/0.33), plate-DR compression, cut-WP premiums (+4/+7),
and a crude reach credit.

## Verdict: P1' BROKEN (stable across 6/7 parameter sets)

| Type    | strict #1 / 12 | win / lose | P1' |
|---------|----------------|------------|-----|
| cut     | 0  | 0 / 8  | FAIL — never the best pick; strictly dominated by thrust |
| thrust  | 9  | 9 / 0  | FAIL — near-universally best; no losing context |
| crush   | 3  | 3 / 9  | PASS — but only via the Flail's fura-guarda trait |
| missile | 0  | 0 / 12 | FAIL — no damage-based niche (range not modeled) |

Root cause: **wound_mult multiplies a weapon-independent base(PA)**, so thrust's x2 beats
cut's x1.5 on the shared base no matter the wmod. The cut-vs-thrust break-even WP gap
(+4.7 early → +8.0 late) **grows with base(PA)**, so no static WP tier can balance it —
+4 leaves thrust ahead, +7 flips cut into dominance. With fura-guarda removed, thrust is
strict #1 in **all 12** contexts; the "no type universally best" property hangs entirely
on one trait on one weapon. Crush has zero damage niche (Mace < thrust even vs plate);
missile's armor-divisor never lifts it above thrust/crush even vs plate.

Holds: Flail is correctly *narrowly* anti-knight (wins plate only, loses mail/leather/robe).

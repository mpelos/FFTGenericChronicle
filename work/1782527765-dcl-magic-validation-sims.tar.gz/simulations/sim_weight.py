#!/usr/bin/env python3
"""
sim_weight.py — does Weight actually trade Move/Dodge, or is it vestigial/a cliff? (D14-62/64/65/66)
Claim: every piece carries Weight; summed Weight -> coarse Move steps + fine Dodge gradient; PA is
NEVER part of Weight (D14-68). Built to FALSIFY two ways:
  (a) VESTIGIAL: normal builds all land in one Move bucket -> Weight choice doesn't matter.
  (b) CLIFF: a normal armored build craters to Move 1 -> heavy gear is unplayable, not a trade.
A healthy design has a BAND where swapping to heavier gear costs exactly ~1 Move tile sometimes and
some Dodge always — a real, graded trade. Numbers are placeholders, swept.
"""
# per-piece Weight (placeholder). body armor dominates; shields/weapons add.
PIECE_W = {
    "robe":2, "leather_body":5, "mail_body":9, "plate_body":14,
    "shield":4, "buckler":2, "weapon_1h":3, "weapon_2h":6, "helm_light":1, "helm_heavy":3,
}
# Move steps: coarse buckets by total Weight. (base Move 4)
def move_from_weight(w):
    if w <= 8:  return 4
    if w <= 14: return 3
    if w <= 22: return 2
    return 1
# Dodge fine gradient: -1 per K weight (continuous-ish), floor contribution
def dodge_penalty(w, k=4):
    return w // k

KITS = {
    "robe caster (robe+1h+light helm)":        ["robe","weapon_1h","helm_light"],
    "leather skirmisher (leather+1h+buckler)": ["leather_body","weapon_1h","buckler","helm_light"],
    "mail duelist (mail+2h)":                  ["mail_body","weapon_2h","helm_heavy"],
    "plate knight (plate+1h+shield)":          ["plate_body","weapon_1h","shield","helm_heavy"],
    "plate greatsword (plate+2h)":             ["plate_body","weapon_2h","helm_heavy"],
}

print("="*74)
print("WEIGHT -> Move / Dodge for representative full kits (PA excluded, D14-68)")
print("="*74)
print(f"  {'kit':42}{'Weight':>7}{'Move':>6}{'Dodge-pen':>11}")
results = {}
for kit, pieces in KITS.items():
    w = sum(PIECE_W[p] for p in pieces)
    mv = move_from_weight(w)
    dp = dodge_penalty(w)
    results[kit] = (w, mv, dp)
    print(f"  {kit:42}{w:7d}{mv:6d}{dp:11d}")

moves = sorted(set(mv for _,mv,_ in results.values()))
print(f"\n  distinct Move values across normal kits: {moves}")
if len(moves) == 1:
    print("  -> VESTIGIAL: every normal kit has the same Move. Weight->Move does nothing. BROKEN(a).")
elif min(moves) <= 1:
    print("  -> CLIFF risk: a normal kit hits Move 1. Check it's an extreme (plate+2h), not the median.")
else:
    print("  -> graded: kits span multiple Move tiers without cratering. Plausible trade.")
print(f"  Dodge penalties span {min(dp for _,_,dp in results.values())}..{max(dp for _,_,dp in results.values())}"
      f" -> fine gradient differentiates kits even within a Move bucket.")

print("\n"+"="*74)
print("Is the Move trade REAL? swap one piece heavier and see if Move/Dodge actually move")
print("="*74)
swaps = [
    ("leather->mail body", ["mail_body","weapon_1h","buckler","helm_light"], ["leather_body","weapon_1h","buckler","helm_light"]),
    ("add a shield (1h knight)", ["plate_body","weapon_1h","shield","helm_heavy"], ["plate_body","weapon_1h","helm_heavy"]),
    ("1h+shield -> 2h (plate)", ["plate_body","weapon_2h","helm_heavy"], ["plate_body","weapon_1h","shield","helm_heavy"]),
]
for label, heavy, light in swaps:
    wl=sum(PIECE_W[p] for p in light); wh=sum(PIECE_W[p] for p in heavy)
    print(f"  {label:28}: Move {move_from_weight(wl)}->{move_from_weight(wh)}  "
          f"Dodge-pen {dodge_penalty(wl)}->{dodge_penalty(wh)}  (Weight {wl}->{wh})")

print("\n"+"="*74)
print("SENSITIVITY SWEEP — vary the Move bucket thresholds; does Weight stay a graded trade?")
print("="*74)
def move_with(thresholds, w):
    for thr, mv in thresholds:
        if w <= thr: return mv
    return 1
for thresholds in [ [(8,4),(14,3),(22,2)], [(6,4),(11,3),(17,2)], [(10,4),(18,3),(26,2)] ]:
    spans = sorted(set(move_with(thresholds, sum(PIECE_W[p] for p in ps)) for ps in KITS.values()))
    print(f"  thresholds {thresholds}: Move values across kits = {spans} "
          f"-> {'graded' if len(spans)>=2 and min(spans)>1 else ('vestigial' if len(spans)==1 else 'cliff')}")

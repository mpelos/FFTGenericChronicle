# sim_weight.py — read (2026-06-26)

Tests D14-62/64/65/66 (Weight → coarse Move steps + fine Dodge gradient; PA never part of Weight, D14-68).
Falsification targets: (a) VESTIGIAL — all normal kits land in one Move bucket; (b) CLIFF — a normal kit
craters to Move 1.

## Findings (ground truth)
- **Not vestigial.** Five representative kits span **Move 4→1** and **Dodge-pen 1→6** — a graded trade.
  robe-caster Weight 6 → Move 4; leather Weight 11 → Move 3; mail Weight 18 → Move 2; plate+shield
  Weight 24 → Move 1.
- **Move trades are REAL in the mid-band:** leather→mail body = Move 3→2; adding a shield (1H knight) =
  Move 2→1. Swapping 1H+shield→2H on plate keeps Move 1 but shifts Dodge — the fine gradient
  differentiates kits even inside a Move bucket.
- **Cliff is a THRESHOLD choice, not inherent.** With placeholder buckets `[≤8→4, ≤14→3, ≤22→2]` a normal
  plate+shield knight hits **Move 1** (cliff). Re-bucketing `[≤10→4, ≤18→3, ≤26→2]` keeps every kit at
  **Move 2-4** (graded). So whether heavy armor craters or merely slows is set by the bucket thresholds.

## Verdict
**D14-62/64/65/66 HOLDS structurally** — Weight is a real, graded Move/Dodge trade with PA correctly
excluded. ED-6 ("Weight near-vestigial OR cliff") **resolved to calibration**: it is *not* vestigial, and
the cliff is avoidable — the design must pick Move-bucket thresholds so standard heavy kits sit at **Move
2** (a meaningful but playable penalty) unless deliberate Move-1 super-tanks are intended. **What would
flip this:** if the real tier Weights cluster so tightly that all kits fall in one bucket (vestigial), or
the design insists on thresholds that drop median armored builds to Move 1 (cliff). Calibration, not
structural.
